#coding:utf-8

"""

"""

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2015.01.29"

import sys
sys.path.append("..")
reload(sys)

from TaveenUtil.Util import OSUtil
from TaveenUtil.SpiderConfig import SpiderConfig

import datetime
import os
import re


if __name__ == "__main__":
    print u"-"*100
    print u"Start to reduce log files @%s ..." % datetime.datetime.now()
    print u"-"*100
    os_name = OSUtil.get_os_name().lower()
    date_now = datetime.datetime.now().date()

    base_dir = u"%s/" % SpiderConfig.get_config("LogsOutputDir")
    folders = os.listdir(base_dir)
    for folder_name in folders:
        if folder_name in ["youku", "tudou", "qiyi", "qq", "letv", "sohu", "pps", "pptv", "v56"]:
            sub_folders = os.listdir(u"%s/%s" % (base_dir, folder_name))
            for sub_folder_name in sub_folders:
                matcher = re.compile(ur"\[.+?\] (\d{4}-\d{2}-\d{2} \d{2}.\d{2}.\d{2}).\d+").search(sub_folder_name)
                if matcher:
                    log_date_str = matcher.group(1).replace(".", ":")
                    log_date = datetime.datetime.strptime(log_date_str, "%Y-%m-%d %H:%M:%S").date()
                    timedelta_days = (date_now - log_date).days
                    if timedelta_days >= 3:  # 删除大于2天的日志.
                        path_for_del = os.path.abspath(u"%s/%s/%s" % (base_dir, folder_name, sub_folder_name))
                        print u"delete %s" % path_for_del
                        try:
                            if os_name == u"windows":
                                os.system(u"rmdir /s/q \"%s\"" % path_for_del)
                            else:
                                os.system(u"rm -rf \"%s\"" % path_for_del)
                        except Exception, err:
                            print err

    print u"-"*100
    print u"Program End @%s ..." % datetime.datetime.now()
    print u"-"*100