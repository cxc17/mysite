#coding:utf-8

"""
该文件会启动一次指定website的视频爬虫(包括种子爬虫和页面爬虫).

"""
__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.09.26"

from os import path
import sys
reload(sys)
sys.setdefaultencoding("utf-8")
sys.path.append(path.abspath("../"))


from TaveenUtil.Util import DatetimeUtil

import os


if __name__ == "__main__":

    # 解析命令行启动参数.
    website = sys.argv[1]

    # 执行种子爬虫.
    command = u"python starter.py %s %s" % (website, u"SeedsSpider")
    print u"Start \"%s\" @ %s" % (command, DatetimeUtil.get_datetime_now_str())
    os.system(command)

    # 执行页面爬虫.
    command = u"python starter.py %s %s" % (website, u"PageSpider")
    print u"Start \"%s\" @ %s" % (command, DatetimeUtil.get_datetime_now_str())
    os.system(command)
