#coding:utf-8

"""
该文件为爬虫程序的入口，会接收控制台参数并启动相应的爬虫.

"""

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.08.18"

from os import path
import sys
reload(sys)
sys.setdefaultencoding("utf-8")
sys.path.append(path.abspath("../"))

from scrapy.utils.project import get_project_settings
from twisted.internet import reactor
from scrapy.crawler import Crawler
from scrapy.spider import log
from scrapy import signals

from TaveenUtil.SpiderConfig import SpiderConfig
from TaveenUtil.FileOperator import FileOperator
from TaveenUtil.Global import Global
from TaveenUtil.Constants import *
from TaveenUtil.Util import *

from VideoSpider.seeds_spiders.SeedsSpider import SeedsSpider
from VideoSpider.page_spiders.PageSpider import PageSpider
from VideoSpider import settings


if __name__ == "__main__":

    # 解析命令行启动参数.
    website = sys.argv[1]
    spider_type = sys.argv[2]
    SpiderConfig.set_config("Website", website)
    SpiderConfig.set_config("SpiderType", spider_type)

    # 重定向输出流.
    log_path = ""
    _f_handler = None
    if not SpiderConfig.get_is_debug():
        if spider_type == SeedsSpiderName:
            log_path = "%s%s_seeds.log" % (SpiderConfig.get_log_output_dir(), SpiderConfig.get_website())
        elif spider_type == PageSpiderName:
            log_path = "%s%s_spider.log" % (SpiderConfig.get_log_output_dir(), SpiderConfig.get_website())
        else:
            raise NotImplementedError()
        FileOperator.create_file(file_path=os.path.abspath(log_path), override_if_exists=True)
        _f_handler = open(log_path, "w")
        # "LogsOutputDir": "/home/TaveenSpider_log/logs/",
        # "SeedsFilesDir": "/home/TaveenSpider_log/output/seeds_output/",
        # sys.stdout = _f_handler
        # sys.stderr = _f_handler
        print u"★STEP INFO★: LOG_FILE = %s" % os.path.abspath(log_path)

    print u"★STEP INFO★: 启动 starter.py @ %s" % Global.ProgramStartTimeStr
    print u"★STEP INFO★: 解析命令行启动参数..."
    print u"★STEP INFO★: Website = %s" % website
    print u"★STEP INFO★: SpiderType = %s" % spider_type

    # 根据不同的命令行参数启动不同的爬虫.
    if spider_type == SeedsSpiderName:
        spider = SeedsSpider()
    elif spider_type == PageSpiderName:
        spider = PageSpider()
    else:
        raise ValueError(u"Invalid Spider Type.")

    # 初始化Global中的全局对象.
    Global.initialize()

    # 配置log.
    settings.LOG_LEVEL = SpiderConfig.get_log_level()
    print u"★STEP INFO★: LOG_LEVEL = %s" % settings.LOG_LEVEL

    # 配置DOWNLOAD_DELAY.
    settings.DOWNLOAD_DELAY = SpiderConfig.get_download_delay()
    print u"★STEP INFO★: DOWNLOAD_DELAY = %s" % settings.DOWNLOAD_DELAY

    # 启动scrapy.
    print u"★STEP INFO★: 启动scrapy @ %s" % DatetimeUtil.get_datetime_now_str()
    sets = get_project_settings()
    crawler = Crawler(sets)
    crawler.signals.connect(reactor.stop, signal=signals.spider_closed)
    crawler.configure()
    crawler.crawl(spider)
    crawler.start()

    # 启动log.
    log.scrapy_info(sets)
    log.start_from_settings(sets, crawler)

    reactor.run()  # the script will block here until the spider_closed signal was sent.

    print u"★STEP INFO★: 还原被重定向的输出流，关闭LOG文件，并启动LOG文件分析程序."
    # 还原被重定向的输出流，并关闭LOG文件.
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__
    if _f_handler is not None:
        _f_handler.flush()
        _f_handler.close()

    # 爬虫执行完之后，启动日志分析模块.
    website = SpiderConfig.get_website()
    ip = OSUtil.get_localhost_ip()
    start_time = Global.ProgramStartTimeStr
    log_dir = u"%s/" % os.path.abspath(SpiderConfig.get_log_output_dir())
    if spider_type == SeedsSpiderName:
        seeds_output_dir = SpiderConfig.get_seeds_output_dir()
        from VideoSpider.log_analyzer.SeedsLogAnalyzer import SeedsLogAnalyzer
        analyzer = SeedsLogAnalyzer(spider_type, start_time, website, ip, log_dir, seeds_output_dir)
        analyzer.analyze()
    elif spider_type == PageSpiderName:
        output_dir = ""
        from VideoSpider.log_analyzer.PageLogAnalyzer import PageLogAnalyzer
        analyzer = PageLogAnalyzer(spider_type, start_time, website, ip, log_dir, output_dir)
        analyzer.analyze()
