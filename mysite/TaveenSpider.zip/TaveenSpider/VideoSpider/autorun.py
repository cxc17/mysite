#coding:utf-8

"""
该文件会循环执行指定website的视频爬虫.

"""
__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.09.26"

import sys
import os


if __name__ == "__main__":

    # 解析命令行启动参数.
    website = sys.argv[1]

    while True:
        print u"-"*100
        command = u"python autorun_once.py %s" % website
        os.system(command)
