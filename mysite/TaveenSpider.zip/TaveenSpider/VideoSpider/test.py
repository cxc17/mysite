# coding=utf-8

from os import path
import sys
reload(sys)
sys.setdefaultencoding("utf-8")
sys.path.append(path.abspath("../"))

from TaveenUtil.FileOperator import FileOperator
import datetime
import re
import json


def abc():
    print datetime.datetime.now()
    data_dict = {}

    path = u"E:\\Hgk Work Space\\Python Projects\\Python Projects ChangU" \
           u"\\TaveenSpider\\logs\\youku\\[PageSpider] 2014-10-01 21.04.45." \
           u"705000\\page_extract_stat.txt"
    _f = open(path, "r")
    line_num = 1
    for line in _f:
        data = json.loads(line)
        txt = json.dumps(data, encoding=False, indent=4)
        data_dict[data["response_url"]] = data

        line_num += 1
    _f.close()
    print datetime.datetime.now()

def aaa():
    from TaveenUtil.Global import Global
    Global.initialize()
    import json
    sql = u"select * from stat_v_change_log"
    result = Global.DbOperator_VideoStat.query(sql)
    for r in result:
        data = json.loads(r["change_stat"])
        for key in data.keys():
            if data[key]["new"] == u"" or data[key]["new"] == 0:
                print r["url"]
                print json.dumps(data, ensure_ascii=False, indent=4)


if __name__ == u"__main__":
    #aaa()
    from VideoSpider.util.VideoInfoUtil import VideoInfoUtil
    print VideoInfoUtil.format_length(u"更新至126集")
    print VideoInfoUtil.format_length(u"200 ")
    print VideoInfoUtil.format_length(u"200a")
    value = u"快乐大本营 20130309 组合PK战 SUPER131迷晕粉丝一片-视频在线观看-快乐大本营-综艺-爱奇艺"
    print VideoInfoUtil.format_no(value, u"variety", False)

    title = u"爸爸去哪儿第二季-综艺频道-爱奇艺2014年全网独播-爱奇艺"
    title = re.sub(ur"-爱奇艺\d+年全网独播", u"", title)
    title = re.sub(ur"-(?:综艺|动漫|电视剧|电影)频道", u"", title)
    title = re.sub(ur"-(?:高清)*视频在线观看", u"", title)
    title = re.sub(ur"-爱奇艺", u"", title)
    print title

    #curEpisode = u"共   53   集全 "
    #print VideoInfoUtil.format_curEpisode(curEpisode, u"电视剧")
    pass