#coding:utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.09.21"

from scrapy.item import Item, Field


class VideoInfoItem(Item):
    """VideoInfo的item类.

    """
    video_url = Field()    # 视频的链接.
    video_info = Field()   # 视频的VideoInfo对象.