# coding=utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.08.18"

from scrapy import signals

from TaveenUtil.SpiderConfig import SpiderConfig
from TaveenUtil.Global import Global
from TaveenUtil.Constants import *

from ..util.SQLGenerator import VideoInfoSqlGenerator
from ..page_spiders.PageSpider import PageSpider

from scrapy.spider import log
import traceback


class StartupExt(object):
    """爬虫启动时的extension组件."""
    def __init__(self):
        pass

    @classmethod
    def from_crawler(cls, crawler):
        ext = cls()
        crawler.signals.connect(ext.spider_opened, signal=signals.spider_opened)
        return ext

    def spider_opened(self, spider):
        print "*"*50 + "Spider Opened Extension" + "*"*50

        spider_type = SpiderConfig.get_spider_type()
        if spider_type == SeedsSpiderName:
            pass
        elif spider_type == PageSpiderName:
            StartupExt.when_page_spider_opened()
        pass

    @staticmethod
    def when_page_spider_opened():
        """完成当页面爬虫启动时需要做的一系列操作."""
        try:
            website = SpiderConfig.get_website()
            # 加载所有album视频的Md5值(idc).
            print u"★STEP INFO★: 加载所有album视频的Md5值(idc)..."
            sql = VideoInfoSqlGenerator.sql_query_all_album_idc(website)
            print sql
            result = Global.DbOperator_VideoBasic.query(sql)
            PageSpider.AlbumAllMd5 = set()
            for row in result:
                PageSpider.AlbumAllMd5.add(row["idc"])
            print u"★STEP INFO★: album idc count = %s." % len(PageSpider.AlbumAllMd5)

            # 加载所有episode视频的Md5值(idc).
            print u"★STEP INFO★: 加载所有episode视频的Md5值(idc)..."
            sql = VideoInfoSqlGenerator.sql_query_all_episode_idc(website)
            print sql
            result = Global.DbOperator_VideoBasic.query(sql)
            PageSpider.EpisodeAllMd5 = set()
            for row in result:
                PageSpider.EpisodeAllMd5.add(row["idc"])
            print u"★STEP INFO★: episode idc count = %s." % len(PageSpider.EpisodeAllMd5)
            pass
        except Exception, err:
            log.msg(err.message, level=log.ERROR)
            log.msg(traceback.format_exc())
            import sys
            sys.exit(-1)
