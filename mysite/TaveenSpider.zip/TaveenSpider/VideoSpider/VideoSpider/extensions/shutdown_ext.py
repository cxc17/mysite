# coding=utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.08.18"

from scrapy.spider import log
from scrapy import signals
from math import ceil
import traceback
import datetime

from TaveenUtil.SpiderConfig import SpiderConfig
from TaveenUtil.Global import Global
from TaveenUtil.Constants import *

from ..statistics.PageSpiderStatistics import PageSpiderStatistics
from ..seeds_spiders.SeedsSpider import SeedsSpider
from ..page_spiders.PageSpider import PageSpider


class ShutdownExt(object):
    """爬虫关闭时的extension组件."""

    # scrapy_stats数据(即爬虫结束时dump到日志最后的那段键值对结构).
    stats = None

    def __init__(self):
        pass

    @classmethod
    def from_crawler(cls, crawler):
        ext = cls()
        ext.stats = crawler.stats
        crawler.signals.connect(ext.spider_closed, signal=signals.spider_closed)
        return ext

    def spider_closed(self, spider):
        print "*"*50 + "Spider Closed Extension" + "*"*50
        Global.ProgramFinishTime = datetime.datetime.now()
        Global.ProgramFinishTimeStr = u"%s" % Global.ProgramFinishTime
        Global.ProgramUsedTime = int(ceil((Global.ProgramFinishTime - Global.ProgramStartTime).seconds))

        # ==========================SeedsSpider============================
        if SpiderConfig.get_spider_type() == SeedsSpiderName:
            self.when_seeds_spider_shutdown(spider)
        # ==========================PageSpider=============================
        elif SpiderConfig.get_spider_type() == PageSpiderName:
            self.when_page_spider_shutdown(spider)
        else:
            raise ValueError(u"未预期的spider type!")
        pass

    def when_page_spider_shutdown(self, spider):
        """完成当页面爬虫执行结束时需要做的一系列操作."""

        # 将VideoData中的album数据和episode数据写入数据库中.
        from ..pipelines.pipelines import VideoInfoPipeline
        from ..util.VideoData import VideoData
        Global.DbOperator_VideoBasic.auto_close = False
        try:
            for key in VideoData.video_data_dict:
                v_info = VideoData.video_data_dict[key]["album"]
                if v_info is not None:
                    VideoInfoPipeline.write_video_info_to_db(v_info)
                else:
                    log.msg(u"album is None! -->>> key in video_data_dict = %s" % key, level=log.WARNING)
                v_info_list = VideoData.video_data_dict[key]["episode"]
                for v_info in v_info_list:
                    VideoInfoPipeline.write_video_info_to_db(v_info)
        except Exception, err:
            log.msg(traceback.format_stack(), level=log.ERROR)
            print err
        Global.DbOperator_VideoBasic.auto_close = True
        Global.DbOperator_VideoBasic.close()

        # 统计页面爬虫执行信息.
        #print self.stats.get_stats()
        PageSpider.statistics.scrapy_stat = self.stats.get_stats()
        PageSpider.statistics.calculate_statistics()
        PageSpider.statistics.write_statistics_to_db()
        pass

    def when_seeds_spider_shutdown(self, spider):
        """完成当种子爬虫执行结束时需要做的一系列操作."""
        SeedsSpider.write_seeds_file(SeedsSpider.seeds)
        SeedsSpider.seeds_statistics.calculate_statistics(SeedsSpider.seeds)
        SeedsSpider.seeds_statistics.check_revision()
        SeedsSpider.seeds_statistics.write_statistics_to_db()

        print "extract_stat = %s" % SeedsSpider.seeds_statistics.extract_stat
        print "video_stat = %s" % SeedsSpider.seeds_statistics.video_stat
        print "response_stat = %s" % SeedsSpider.seeds_statistics.response_stat