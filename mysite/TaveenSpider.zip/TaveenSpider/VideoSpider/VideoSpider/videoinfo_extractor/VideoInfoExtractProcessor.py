#coding:utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.09.14"

from scrapy.selector.unified import SelectorList
from scrapy.selector.unified import Selector
from scrapy.spider import log
import json
import re

from .VideoInfoExtractTemplate import VideoInfoExtractTemplate
from ..util.VideoInfoUtil import VideoInfoUtil
from ..util.VideoInfo import VideoInfo
from TaveenUtil.Constants import *

import chardet


class VideoInfoExtractProcessor(object):
    """视频信息(VideoInfo)抽取处理器类.

    该类主要是解释视频信息抽取的XML模板，并对信息进行抽取.

    """

    # 当前处理器对应的website.
    website = ""
    # 当前处理器对应的模板对象.
    template = None

    # 变量的正则表达式(use as static var).
    var_name_pattern = re.compile(ur"\$\{(.+?)\}")

    # 以下为处理器工作时用到的变量，仅在内部使用.
    __objects = {}  # key为对象名，value为对象.
    __url_regex = []
    __result = []
    __category = ""
    __url = ""
    __body = ""
    __meta = {}

    # 标记当前website的网页文本的编码.
    # 这样就不用每次都检测网页文本的编码了，因为每次检测都需要较长时间.
    web_page_encoding = None

    def __init__(self, website, template):
        """初始化视频信息抽取处理器类的实例.

        @param website: 当前处理的网站名.
        @param template: 处理器抽取视频信息时依照的XML模板对象.
        """
        assert website != u""
        assert isinstance(template, VideoInfoExtractTemplate)

        self.website = website
        self.template = template

    def extract(self, url, body, meta):
        """实现从指定的页面抽取视频信息.

        @param url: response的url.
        @param body: response的body.
        @param meta: response的meta信息.
        @return: 返回抽取到的视频信息(VideoInfo)列表(因为有可能从一个页面中抽取出多个VideoInfo，故为列表).
        """
        results = self.extract_raw(url, body, meta)
        # print results
        video_info_list = []

        for result in results:
            video_info = VideoInfo()
            # website.
            video_info.website = self.website
            # url.
            video_info.url = u""
            url_name = ""
            if "url" in result:
                url_name = "url"
            elif "albumuri" in result:
                url_name = "albumuri"
            for url in result[url_name]:
                url = VideoInfoUtil.string_denoising(url)
                if url != u"":
                    video_info.url = url
                    break
            # page_type.
            video_info.page_type = u""
            if "page_type" in result:
                for page_type in result["page_type"]:
                    page_type = VideoInfoUtil.string_denoising(page_type)
                    if page_type != u"":
                        video_info.page_type = page_type
                        break
            # category.
            video_info.category = u""
            if "category" in result:
                for category in result["category"]:
                    category = VideoInfoUtil.format_category(category)
                    if category != u"":
                        video_info.category = category
                        break
            # title.
            video_info.title = u""
            if "title" in result:
                for title in result["title"]:
                    title = VideoInfoUtil.format_title(title)
                    if title != u"":
                        video_info.title = title
                        break
            # other_name.
            video_info.othername = u""
            if "othername" in result:
                for other_name in result["othername"]:
                    other_name = VideoInfoUtil.format_othername(other_name)
                    if other_name != u"":
                        video_info.othername = other_name
                        break
            # video_name.
            video_info.video_name = (u"%s   %s" % (video_info.title, video_info.othername)).strip()
            # image.
            video_info.image = u""
            if "image" in result:
                for image in result["image"]:
                    image = VideoInfoUtil.string_denoising(image)
                    if image != u"":
                        video_info.image = image
                        break
            # album_id.
            video_info.album_id = u""
            if video_info.page_type == PageType.EPISODE_PAGE:
                if "album_id" in result:
                    for album_id in result["album_id"]:
                        album_id = VideoInfoUtil.string_denoising(album_id)
                        if album_id != u"":
                            video_info.album_id = album_id
                            break
            elif video_info.page_type == PageType.ALBUM_PAGE:
                video_info.album_id = video_info.url
            if video_info.album_id == u"":
                if meta.get("album_id", None) is not None:
                    video_info.album_id = meta["album_id"]
                elif meta.get("album_url", None) is not None:
                    video_info.album_id = meta["album_url"]
            # actor.
            video_info.actor = u""
            if "actor" in result:
                for actor in result["actor"]:
                    actor = VideoInfoUtil.format_actor(actor)
                    if actor != u"":
                        video_info.actor = actor
                        break
            # director.
            video_info.director = u""
            if "director" in result:
                for director in result["director"]:
                    director = VideoInfoUtil.format_actor(director)
                    if director != u"":
                        video_info.director = director
                        break
            # screenwriter.
            video_info.screenwriter = u""
            if "screenwriter" in result:
                for screenwriter in result["screenwriter"]:
                    screenwriter = VideoInfoUtil.format_actor(screenwriter)
                    if screenwriter != u"":
                        video_info.screenwriter = screenwriter
                        break
            # guests.
            video_info.guests = u""
            if "guests" in result:
                for guests in result["guests"]:
                    guests = VideoInfoUtil.format_actor(guests)
                    if guests != u"":
                        video_info.guests = guests
                        break
            # drama.
            video_info.drama = u""
            if "drama" in result:
                for drama in result["drama"]:
                    drama = VideoInfoUtil.format_drama(drama)
                    if len(drama) > 0:
                        video_info.drama = drama
                        break
            # type.
            video_info.type = u""
            if "type" in result:
                for type_str in result["type"]:
                    type_str = VideoInfoUtil.string_denoising(type_str)
                    if type_str != u"":
                        video_info.type = type_str
                        break
            # region.
            video_info.region = u""
            if "region" in result:
                for region in result["region"]:
                    region = VideoInfoUtil.string_denoising(region)
                    if region != u"":
                        video_info.region = region
                        break
            # year.
            video_info.year = 0
            if "year" in result:
                for year in result["year"]:
                    year = VideoInfoUtil.format_year(year)
                    if year > 0:
                        video_info.year = year
                        break
            # pubdate.
            video_info.pubdate = u""
            if "pubdate" in result:
                for pubdate in result["pubdate"]:
                    pubdate = VideoInfoUtil.format_pubdate(pubdate)
                    if pubdate != u"":
                        video_info.pubdate = pubdate
                        break
            # length.
            video_info.length = 0
            if "length" in result:
                for length in result["length"]:
                    #print u"before-->>> %s -->>>%s" % (url, length)
                    length = VideoInfoUtil.format_length(length, video_info.category)
                    #print u"after -->>> %s -->>>%s" % (url, length)
                    if length > video_info.length:
                        video_info.length = length
                        #break
            # curEpisode.
            video_info.curEpisode = 0
            if "curEpisode" in result:
                for cur_episode in result["curEpisode"]:
                    cur_episode = VideoInfoUtil.format_curEpisode(cur_episode, video_info.category)
                    if cur_episode > video_info.curEpisode:
                        video_info.curEpisode = cur_episode
                        #break
            # no.
            video_info.no = 0
            if "no" in result:
                for no in result["no"]:
                    if category == u"movie" or category == u"电影":
                        no = VideoInfoUtil.format_no(no, category, False)
                    else:
                        no = VideoInfoUtil.format_no(no, category, True)
                    if category == u"variety" or category == u"综艺":
                        if no > video_info.no:
                            video_info.no = no
                    elif no > 0:
                        video_info.no = no
                        break
            if video_info.no == 0 and video_info.category == u"电影":
                video_info.no = 1
            # rate.
            video_info.rate = 0.0
            if "rate" in result:
                for rate in result["rate"]:
                    rate = VideoInfoUtil.format_rate(rate)
                    if rate > 0:
                        video_info.rate = rate
                        break
            # quality.
            video_info.quality = u""
            if "quality" in result:
                for quality in result["quality"]:
                    quality = VideoInfoUtil.format_quality(quality)
                    if quality != u"":
                        video_info.quality = quality
                        break
            # publish_area.
            video_info.publish_area = u""
            if "publish_area" in result:
                for publish_area in result["publish_area"]:
                    publish_area = VideoInfoUtil.string_denoising(publish_area)
                    if publish_area != u"":
                        video_info.publish_area = publish_area
                        break
            # pay.
            video_info.pay = 0
            if "pay" in result:
                for pay in result["pay"]:
                    pay = VideoInfoUtil.format_pay(pay)
                    if pay == 0 or pay == 1:
                        video_info.pay = pay
                        if video_info.pay == 1:
                            break
            # idc.
            video_info.idc = video_info.generate_md5()
            # isEnd.
            video_info.isEnd = (video_info.length == video_info.curEpisode and
                                video_info.length != 0 and video_info.length != u"") and 1 or 0
            video_info_list.append(video_info)

        # on extractor finished.
        if "actions" in self.template:
            path = self.template["actions"].get("on_extractor_finished", u"").strip()
            if path != u"":
                class_name = path[path.rindex(u".")+1:]
                class_path = path[:path.rindex(u".")]
                import_cmd = u"from %s import %s" % (class_path, class_name)
                call_cmd = u"%s.on_extractor_finished(video_info_list, url, body, meta)" % class_name
                try:
                    exec import_cmd
                    r = eval(call_cmd)
                    if r is not None:
                        video_info_list = r
                except Exception, err:
                    print import_cmd
                    print call_cmd
                    raise err
        return video_info_list

    def extract_raw(self, url, body, meta):
        """实现从指定的页面抽取视频信息(抽取到的信息为原始信息，并没有筛选并封装成VideoInfo对象).

        @param url: response的url.
        @param body: response的body.
        @param meta: response的meta信息.
        @return: 返回抽取到的信息(原始信息)列表(因为有可能从一个页面中抽取出多套信息，故为列表).
        """
        # check encoding.
        # Modified by HuangGK, 2014.11.21.
        # 为了提高性能，只检测一次文本的编码，并保存起来后面直接用.
        # 但是需要注意的是，如果一个网站的不同网页分别采用了不同的编码，那么这种方法就存在隐患.
        # 好在目前并没有发现使用多种文本编码的网站，如果后续发现再想办法解决.
        # body = body.decode("utf-8", 'ignore')
        # body = body.decode(chardet.detect(body)['encoding'], 'ignore')
        # 1.-----------------------------------------------------------
        # if self.web_page_encoding is None:
        #    encoding = u""
        #    matcher = re.compile(ur"<meta[^>]+?charset *= *(?:\"|')(.+?)(?:\"|')").search(body)
        #    if matcher:
        #        encoding = matcher.group(1)
        #    matcher = re.compile(ur"<meta[^>]+?content *= *(?:\"|')[^>]+?charset *= *(.+)(?:\"|')").search(body)
        #    if matcher:
        #        encoding = matcher.group(1)
        #    encoding = encoding.lower()
        #    if encoding in [u"utf8", u"utf-8", u"gbk", u"gb2312"]:
        #        self.web_page_encoding = encoding
        #    else:
        #        self.web_page_encoding = chardet.detect(body)['encoding']
        # 2.-----------------------------------------------------------
        # if self.web_page_encoding is None:
        #    self.web_page_encoding = chardet.detect(body)['encoding']
        # body = body.decode(self.web_page_encoding, 'ignore')
        # 3.-----------------------------------------------------------
        encoding = meta.get("page_encoding", u"")
        if encoding == u"":
            if self.web_page_encoding is None:
                self.web_page_encoding = chardet.detect(body)['encoding']
            body = body.decode(self.web_page_encoding, 'ignore')
        else:
            body = body.decode(encoding, 'ignore')
        # encoding = chardet.detect(body)['encoding']
        # body = body.decode(encoding, 'ignore')
        # body = body.decode(self.web_page_encoding, 'ignore')
        # End modify, 2014.11.21.

        # check parameters.
        assert url != u""
        assert body != u""
        assert isinstance(meta, dict)

        self.__url = url
        self.__body = body
        self.__meta = meta

        # 重置对象.
        self.__objects = {}
        self.__result = []
        self.__url_regex = []
        self.__category = ""

        # extract album.
        self.__do_extract("album")

        # 重置对象.
        self.__objects = {}
        self.__url_regex = []
        self.__category = ""
        # extract episode.
        self.__do_extract("episode")

        # for item in self.__result:
        #    print json.dumps(item, ensure_ascii=False)
        return self.__result

    def __do_extract(self, base_node_name="album"):
        """[内部调用]实现解析模板并抽取信息的操作.

        @param base_node_name: 处理的节点名称(专辑节点或者分集节点).
        """
        # 判断是否满足url_regex中的某一个正则表达式.
        if not self.__if_match_url_regex(self.__url, self.template[base_node_name]["url_regex"]):
            return
        # 初始化object节点中的对象.
        self.__objects = {}
        for key in self.template[base_node_name]["object"].keys():
            self.__objects[key] = self.__process_node_value(self.template[base_node_name]["object"][key])
        # print u"objects = %s" % self.__objects
        # 进行抽取.
        base_dict = self.template[base_node_name]["extractor"]
        result = dict()
        result["category"] = list()
        # 先计算category, 因为其他节点的解析需要根据cagegory判断是否进行抽取.
        for item in base_dict["category"]:
            category = self.__process_node_value(item)
            result["category"].append(category)
        if self.__meta.get("category", None) is not None:
            result["category"].append(self.__meta["category"])
        for category in result["category"]:
            category = VideoInfoUtil.category_ch_to_en(category)
            if category in CategoryNames:
                self.__category = category
                break

        for key in base_dict.keys():
            if key == u"category":
                continue
            result[key] = []
            for item in base_dict[key]:
                if not self.__category in item["category"]:
                    # print u"跳过节点%s!" % item
                    continue
                value = self.__process_node_value(item)
                result[key].append(value)
            # 用response中meta里的数据补充VideoInfo.
            #                 注意：title字段不作信息补充(要求title字段自行抽取，
            #                 如果抽取不到title，要么是模板失效了，要么是业务原因导致).
            if self.__meta.get(key, None) is not None:  # and key != "title"
                result[key].append(self.__meta[key])

        if "page_type" not in result:
            result["page_type"] = []
        if base_node_name == u"album":
            result["page_type"].append(PageType.ALBUM_PAGE)
        elif base_node_name == u"episode":
            result["page_type"].append(PageType.EPISODE_PAGE)
        if len(result["page_type"]) == 0 and "page_type" in self.__meta:
            result["page_type"].append(self.__meta["page_type"])

        self.__result.append(result)

    def __if_match_url_regex(self, url, url_regex_list):
        """[内部调用]判断给定的url是否满足url_regex_list中的某一个正则表达式.

        @param url:
        @param url_regex_list:
        @return: 返回给定的url是否满足url_regex_list中的某一个正则表达式(True or False).
        """
        flag = False
        for regex in url_regex_list:
            matcher = re.compile(regex.strip()).search(url)
            if matcher:
                flag = True
                break
        if flag:
            return True
        return False

    def __process_node_value(self, node):
        """解析一个给定的节点node并获取值.

        @param node: 待解析的节点对象.
        @return: 返回解析后取到的值.
        """
        extract_type = node["extract_type"]
        concat = node["concat"]
        if extract_type == u"text":
            result = self.__process_extract_type_is_text(node)
        elif extract_type == u"xpath":
            result = self.__process_extract_type_is_xpath(node)
        elif extract_type == u"json":
            result = self.__process_extract_type_is_json(node)
        elif extract_type == u"regex":
            result = self.__process_extract_type_is_regex(node)
        else:
            raise NotImplementedError()
        if concat != u"":
            result = concat.replace(u"${_VALUE_}", u"%s" % result)
        return result

    def __process_extract_type_is_xpath(self, node):
        """解析节点node的extract_type为xpath时的情况.

        @param node: 待解析的节点对象.
        @return: 返回解析后取到的值.
        """
        result_type = node["result_type"]
        text = node["text"]
        selector = self.__get_source(node)

        if not isinstance(selector, SelectorList) and not isinstance(selector, Selector):
            selector = Selector(text=u"%s" % selector)

        value = selector.xpath(text)
        return self.__process_result_type(value, result_type)

    def __process_extract_type_is_json(self, node):
        """解析节点node的extract_type为json时的情况.

        @param node: 待解析的节点对象.
        @return: 返回解析后取到的值.
        """
        # TODO 尚未完成.
        return ""

    def __process_extract_type_is_regex(self, node):
        """解析节点node的extract_type为regex时的情况.

        @param node: 待解析的节点对象.
        @return: 返回解析后取到的值.
        """
        result_type = node["result_type"]
        text = node["text"]
        group = node["group"].strip()
        match_type = node["match_type"]

        # 根据不同的source进行不同的处理.
        source = u"%s" % self.__get_source(node)
        pattern = re.compile(text)
        if match_type == u"search":
            matcher = pattern.search(source)
            if matcher:
                value = matcher.group(int(group))
                return self.__process_result_type(value, result_type)
        else:
            raise NotImplementedError(u"未实现的match type: %s" % match_type)
        return self.__process_result_type("", result_type)

    def __process_extract_type_is_text(self, node):
        """解析节点node的extract_type为text(简单文本)时的情况.

        @param node: 待解析的节点对象.
        @return: 返回解析后取到的值.
        """
        result_type = node["result_type"]
        # 获得source的真正内容.
        source = self.__get_source(node)
        # process value.
        return self.__process_result_type(source, result_type)

    def __process_result_type(self, value, result_type):
        """根据result_type属性对给定的value进行数据类型的转换.

        @param value: 待处理的值.
        @param result_type: 转换的目标数据类型.本函数会将value的值转换为result_type所要求的类型.
        @return: 返回转换后的值.
        """
        if result_type == u"text":
            if value is None:
                return u""
            if isinstance(value, SelectorList) or isinstance(value, Selector):
                value = value.extract()
                return u"   ".join(value).strip()
            elif isinstance(value, list):
                result = u""
                for l in value:
                    result += u"%s" % l
                return result.strip()
            return u"%s" % value
        elif result_type == u"dict":
            if value is None:
                return dict()
            if isinstance(value, str) or isinstance(value, unicode):
                value = value.strip()
                if value == u"":
                    value = dict()
                elif value.startswith(u"{") and value.endswith(u"}"):
                    try:
                        value = json.loads(value)
                    except Exception, err:
                        log.msg(u"解析失败的result_type! result_type=%s, value=%s\n%s"
                                % (result_type, value, err.message), level=log.WARNING)
            return value
        elif result_type == u"selector":
            if isinstance(value, str) or isinstance(value, unicode):
                value = Selector(text=u"%s" % value)
            return value
        else:
            raise NotImplementedError()

    def __get_var(self, name):
        """根据变量名获取模板解析过程中生成的变量.

        @param name: 待获取的变量名.
        @return: 返回获取到的变量对象，当不存在时返回None.
        """
        if name in self.__objects:
            return self.__objects[name]
        return None

    def __get_source(self, node):
        """解析给定节点node的source属性，并获取到source指向的真实的内容.

        @param node: 待处理的节点node.
        @return: 返回解析后得到的真实的source内容.
        """
        if node["source"] == u"TEXT":
            return node["text"]
        elif node["source"] == u"response.url":
            return self.__url
        elif node["source"] == u"response.body":
            return self.__body
        elif node["source"] == u"response.meta":
            return self.__meta
        elif self.var_name_pattern.match(node["source"]):
            matcher = self.var_name_pattern.search(node["source"])
            if matcher:
                return self.__get_var(matcher.group(1))
        else:
            return None