#coding:utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.09.13"

from scrapy.spider import log

from TaveenUtil.Constants import PageType
from ..util.VideoInfo import VideoInfo


class VideoInfoExtractor(object):
    """这个类貌似没有用！！！！！！！！！！！！

    """

    def __init__(self):
        self.template = None
        pass

    def extract(self, response, video_info=None):
        if video_info is None:
            video_info = VideoInfo()
        url = response.url.strip()
        meta = response.meta

        video_info.url = url
        if video_info.page_type == PageType.ALBUM_PAGE:
            pass
        elif video_info.page_type == PageType.EPISODE_PAGE:
            pass
        elif video_info.page_type == u"":
            pass
        else:
            log.msg(u"错误的page_type!", level=log.ERROR)

        # 对抽取出的视频信息的各字段进行格式化.
        # 对特殊视频进行过滤，如预告(片)、特辑、片花、花絮等.

        return video_info