#coding:utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.09.14"


from TaveenUtil.FileOperator import FileOperator

from lxml import etree as tree
import json


class VideoInfoExtractTemplate(dict):
    """视频信息(VideoInfo)抽取模板类.

    每一个本类的对象表示一个视频抽取的模板.

    """

    # 当前模板对象对应的website.
    website = ""

    def __init__(self, template_path):
        """初始化模板类并加载XML模板.

        @param template_path: XML模板的路径.
        """
        self["album"] = {}
        self["episode"] = {}
        self.load_template(template_path)
        pass

    def load_template(self, template_path):
        """加载视频抽取的XMl模板.

        @param template_path: XML模板的路径.
        """
        if not FileOperator.exist_file(template_path):
            raise ValueError(u"File \"%s\" not found!" % template_path)
        text = FileOperator.read_all_text(template_path)
        selector = tree.fromstring(text)

        self.website = u"".join(selector.xpath(u"//template/@website")).strip()
        # 1.处理专辑页模板部分.
        self.__init_template(selector, "album")
        # 2.处理分集页模板部分.
        self.__init_template(selector, "episode")
        # 3.处理actions部分.
        self.__init_actions(selector)
        # 检查模板的合法性.
        self.check_template_validity()
        print json.dumps(self, ensure_ascii=False)

    def __init_actions(self, selector):
        self["actions"] = {"on_extractor_opened": u"",
                           "on_extractor_finished": u""}
        nodes = selector.xpath(u"//video_info//actions//action")
        for node in nodes:
            event = u"".join(node.xpath(u"./@event")).strip()
            path = u"".join(node.xpath(u"./@path")).strip()
            if event == u"on_extractor_opened":
                self["actions"]["on_extractor_opened"] = path
            elif event == u"on_extractor_finished":
                self["actions"]["on_extractor_finished"] = path

    def __init_template(self, selector, base_node_name):
        """[内部调用]初始化和解析XML模板.

        @param selector: XML模板对应的selector.
        @param base_node_name: 指定的需要被解析的节点名称(专辑页节点或分集页节点)
        """
        # 1.url_regex.
        self[base_node_name]["url_regex"] = list()
        nodes = selector.xpath(u"//video_info//%s/url_regex//regex/text()" % base_node_name)
        for node in nodes:
            self[base_node_name]["url_regex"].append(u"".join(node).strip())
        # 2.object.
        self[base_node_name]["object"] = {}
        nodes = selector.xpath(u"//video_info//%s/object/source" % base_node_name)
        for node in nodes:
            name = u"".join(node.xpath(u"./@name")).strip()
            source = u"".join(node.xpath(u"./@source")).strip()
            extract_type = u"".join(node.xpath(u"./@extract_type")).strip()
            result_type = u"".join(node.xpath(u"./@result_type")).strip()
            category = u"".join(node.xpath(u"./@category")).strip()
            text = u"".join(node.xpath(u"./text()")).strip()
            concat = u"".join(node.xpath(u"./@concat")).strip()
            if result_type == u"":
                result_type = u"text"
            if category == u"":
                category = u"tv|movie|variety|animation"
            self[base_node_name]["object"][name] = {"source": source,
                                                    "extract_type": extract_type,
                                                    "result_type": result_type,
                                                    "category": category,
                                                    "text": text,
                                                    "concat": concat}
            if extract_type == u"regex":
                group = u"".join(node.xpath(u"./@group")).strip()
                match_type = u"".join(node.xpath(u"./@match_type")).strip()
                if group == u"":
                    group = u"0"
                if match_type == u"":
                    match_type = u"search"
                self[base_node_name]["object"][name]["group"] = group
                self[base_node_name]["object"][name]["match_type"] = match_type
        # 3.extract.
        self[base_node_name]["extractor"] = {}
        nodes = selector.xpath(u"//video_info//%s/extractor/*" % base_node_name)
        for node in nodes:
            tag = node.tag
            self[base_node_name]["extractor"][tag] = []
            _nodes = node.xpath(u".//path")
            for _node in _nodes:
                source = u"".join(_node.xpath(u"./@source")).strip()
                extract_type = u"".join(_node.xpath(u"./@extract_type")).strip()
                concat = u"".join(_node.xpath(u"./@concat")).strip()
                result_type = u"".join(_node.xpath(u"./@result_type")).strip()
                category = u"".join(_node.xpath(u"./@category")).strip()
                text = u"".join(_node.xpath(u"./text()")).strip()
                if result_type == u"":
                    result_type = u"text"
                if category == u"":
                    category = u"tv|movie|variety|animation"
                item = {"source": source,
                        "extract_type": extract_type,
                        "concat": concat,
                        "result_type": result_type,
                        "category": category,
                        "text": text}
                if extract_type == u"regex":
                    group = u"".join(_node.xpath(u"./@group")).strip()
                    match_type = u"".join(_node.xpath(u"./@match_type"))
                    item["group"] = group
                    item["match_type"] = match_type
                self[base_node_name]["extractor"][tag].append(item)

    def check_template_validity(self):
        """检查XML模板的结构是否合法.

        @return: 当发现不合法结构时，以异常的形式抛出.
        """
        if self.get("album", None) is None:
            raise ValueError(u"视频信息抽取模板必须包含album节点!")
        if self.get("episode", None) is None:
            raise ValueError(u"视频信息抽取模板必须包含album节点!")

        if self["album"].get("url_regex", None) is None:
            raise ValueError(u"视频信息抽取模板的album节点下必须包含url_regex节点，"
                             u"符合url_regex下的正则表达式的url为专辑页链接!")
        if len(self["album"]["url_regex"]) == 0:
            raise ValueError(u"url_regex节点下必须有至少一个regex节点，其内容为一个url的正则表达式!")
        if self["album"].get("object", None) is None:
            raise ValueError(u"视频信息抽取模板的album节点下必须包含object节点!object节点下的source"
                             u"节点表示抽取前所需的变量/对象/数据.")
        if self["album"].get("extractor", None) is None:
            raise ValueError(u"视频信息抽取模板的album节点下必须包含extractor节点!extractor节点下的"
                             u"所有节点表示一个抽取项.")
        if self["album"]["extractor"].get("category", None) is None:
            raise ValueError(u"视频信息抽取模板的album.extractor节点下必须包含category节点，因为"
                             u"category节点是判断视频类型并进行相应处理的重要依据.")
        if len(self["album"]["extractor"]["category"]) == 0:
            raise ValueError(u"category节点下必须有至少一个path节点，其内容为一个category的抽取路径!")

        if self["episode"].get("url_regex", None) is None:
            raise ValueError(u"视频信息抽取模板的episode节点下必须包含url_regex节点，"
                             u"符合url_regex下的正则表达式的url为专辑页链接!")
        if len(self["episode"]["url_regex"]) == 0:
            raise ValueError(u"url_regex节点下必须有至少一个regex节点，其内容为url的正则表达式!")
        if self["episode"].get("object", None) is None:
            raise ValueError(u"视频信息抽取模板的episode节点下必须包含object节点!object节点下的source"
                             u"节点表示抽取前所需的变量/对象/数据.")
        if self["episode"].get("extractor", None) is None:
            raise ValueError(u"视频信息抽取模板的episode节点下必须包含extractor节点!extractor节点下的"
                             u"所有节点表示一个抽取项.")
        if self["episode"]["extractor"].get("category", None) is None:
            raise ValueError(u"视频信息抽取模板的episode.extractor节点下必须包含category节点，因为"
                             u"category节点是判断视频类型并进行相应处理的重要依据.")
        if len(self["episode"]["extractor"]["category"]) == 0:
            raise ValueError(u"category节点下必须有至少一个path节点，其内容为category的抽取路径!")
        pass