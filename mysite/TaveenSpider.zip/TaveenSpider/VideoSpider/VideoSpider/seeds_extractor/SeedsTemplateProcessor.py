#coding:utf-8
__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.08.18"

from scrapy.selector import Selector
from scrapy.spider import log
from lxml import etree
import traceback
import time
import json
import re

from TaveenUtil.FileOperator import FileOperator
from TaveenUtil.jsonpath import jsonpath
from TaveenUtil.Constants import *


class SeedsTemplateProcessor(object):
    """种子爬虫用于从索引页抽取出种子的XML模板解释器.

    """

    page_type = "html"                 # 当前网站的所有索引页的页面类型: html/json/xml.
    tv = {}                            # 存放电视剧的种子的容器.
    movie = {}                         # 存放电影的种子的容器.
    variety = {}                       # 存放综艺的种子的容器.
    animation = {}                     # 存放动漫的种子的容器.

    def __init__(self, website):
        """初始化XML模板解释器."""
        self.website = website
        pass

    def load_template(self, template_file_path):
        """加载XML模板.

        @param template_file_path: XML模板的文件路径.
        """
        print u"★STEP INFO★: 加载种子爬虫模板(%s_seeds.tmplt)..." % self.website
        # read xml template.
        xml_text = FileOperator.read_all_text(template_file_path)
        selector = Selector(text=xml_text, type="xml")
        # extract type.
        self.page_type = "".join(selector.xpath("//seeds/@page_type").extract())
        # common node.
        common_node = selector.xpath("//seeds/common")
        # loop through the four categorys.
        for category in CategoryNames:
            category_node = selector.xpath("//seeds/%s" % category)
            # process page_count node.
            if len(category_node.xpath("page_count")) > 0:
                node = category_node.xpath("page_count")
            else:
                if len(common_node.xpath("page_count")) > 0:
                    node = common_node.xpath("page_count")
                else:
                    log.msg("%s 缺少节点:%s" % (category, "page_count"))
                    raise ValueError("%s 缺少节点:%s" % (category, "page_count"))
            d = getattr(self, category)
            d["page_count"] = \
                {"extract_type": "".join(node.xpath("@extract_type").extract()),
                 "pattern": "".join(node.xpath("pattern/text()").extract()),
                 "start_page_count": int("".join(node.xpath("start_page_count/text()").extract()))}
            # process video_url_regex node.
            d["video_url_regex"] = []
            if len(category_node.xpath("./video_url_regex")) > 0:
                for regex in category_node.xpath("./video_url_regex/regex/text()").extract():
                    if regex != u"":
                        d["video_url_regex"].append(regex)
            else:
                if len(common_node.xpath("./video_url_regex")) > 0:
                    for regex in common_node.xpath("./video_url_regex/regex/text()").extract():
                        if regex != u"":
                            d["video_url_regex"].append(regex)
                else:
                    log.msg("%s 缺少节点:%s" % (category, "video_url_regex"))
                    raise ValueError("%s 缺少节点:%s" % (category, "video_url_regex"))
            # process video_info node.
            if len(category_node.xpath("video_info")) > 0:
                node = category_node.xpath("video_info")
            else:
                if len(common_node.xpath("video_info")) > 0:
                    node = common_node.xpath("video_info")
                else:
                    log.msg(message="%s 缺少节点:%s" % (category, "video_info"), level=log.CRITICAL)
                    raise ValueError("%s 缺少节点:%s" % (category, "video_info"))
            d = getattr(self, category)
            d["video_info"] = {"extract_type": "".join(node.xpath("@extract_type").extract()),
                               "base_tag": "".join(node.xpath("./base_tag/text()").extract())}
            xml_text = "".join(node.extract())
            e = etree.fromstring(xml_text)
            for target in e.xpath("./*"):
                if target.tag == "base_tag":
                    continue
                if len(node.xpath("./%s" % target.tag)) > 0:
                    d["video_info"][target.tag] = {"path": "".join(node.xpath("./%s/text()" % target.tag).extract()),
                                                   "concat": "".join(node.xpath("./%s/@concat" % target.tag).extract())}
            # process base_url node.
            if len(category_node.xpath("base_url")) > 0:
                node = category_node.xpath("base_url")
            else:
                if len(common_node.xpath("base_url")) > 0:
                    node = common_node.xpath("base_url")
                else:
                    log.msg(message="%s 缺少节点:%s" % (category, "base_url"), level=log.CRITICAL)
                    raise ValueError("%s 缺少节点:%s" % (category, "base_url"))
            d = getattr(self, category)
            d["base_url"] = "".join(node.xpath("text()").extract())
            # process filter_url_pattern.
            if len(category_node.xpath("filter_url_pattern")) > 0:
                node = category_node.xpath("filter_url_pattern")
            else:
                if len(common_node.xpath("filter_url_pattern")) > 0:
                    node = common_node.xpath("filter_url_pattern")
                else:
                    log.msg(message="%s 缺少节点:%s" % (category, "filter_url_pattern"), level=log.CRITICAL)
                    raise ValueError("%s 缺少节点:%s" % (category, "filter_url_pattern"))
            d = getattr(self, category)
            d["filter_url_pattern"] = "".join(node.xpath("text()").extract())
            # process filter node.
            if len(category_node.xpath("filter")) > 0:
                node = category_node.xpath("filter")
            else:
                if len(common_node.xpath("filter")) > 0:
                    node = common_node.xpath("filter")
                else:
                    log.msg(message=u"%s 缺少节点:%s" % (category, "filter"), level=log.CRITICAL)
                    raise ValueError(u"%s 缺少节点:%s" % (category, "filter"))
            d = getattr(self, category)
            d["filter"] = {}
            for sub_node in node.xpath("item"):
                name = "".join(sub_node.xpath("@name").extract())
                extract_type = "".join(sub_node.xpath("@extract_type").extract())
                no_filter_value = "".join(sub_node.xpath("@dont_filter_value").extract())
                data = "".join(sub_node.xpath("data/text()").extract())
                d["filter"][name] = {}
                d["filter"][name]["extract_type"] = extract_type
                d["filter"][name]["dont_filter_value"] = no_filter_value
                d["filter"][name]["data"] = data
            print u"★TEMPLATE ★: > %s = %s" % (category, json.dumps(d, ensure_ascii=False))
            log.msg(message=json.dumps(d, ensure_ascii=False), level=log.INFO)
        # check if template valid.
        self.check_template_validity()

    def get_base_urls(self):
        """获取基础链接(对应XML模板中的base_url节点)."""
        base_urls = {}
        for category in CategoryNames:
            base_urls[category] = getattr(self, category)["base_url"]
        return base_urls

    def generate_basic_urls(self, is_quick_update, is_apply_seeds_filter):
        """该函数用于返回所有基础链接以及所有应用筛选器后组合出的链接(如果对索引页应用了筛选器).

        @param is_quick_update: 是否为快速更新模式(小循环).
        @param is_apply_seeds_filter: 是否对索引页应用筛选器.
        @return: 返回所有的基础链接(是一个列表)的第一页.
        """
        print u"★STEP INFO★: generator basic seeds urls(page 1)..."
        result = {}
        for category in CategoryNames:
            category_dict = getattr(self, category)
            # 不管是大循环还是小循环，也不论是否为"爬全"模式，下面这句都是有的，因为这是基础链接.
            result[category] = [category_dict["base_url"]]
            # 如果不是小循环且使用filter时.
            if is_quick_update is False and is_apply_seeds_filter is True:
                print u"★STEP INFO★: Processing %s..." % category
                filter_url_pattern = category_dict["filter_url_pattern"]
                keys = category_dict["filter"].keys()
                count = 1
                d = {}
                for key in keys:  # 遍历所有filter/item，得到所有filter值列表.
                    item = category_dict["filter"][key]
                    if item["extract_type"] == "enum":
                        data_set = set(item["data"].split("|"))
                        if "" in data_set:
                            data_set.remove("")
                        data_set.add(item["dont_filter_value"])
                        count *= len(data_set)
                        data = list(data_set)
                        if key == u"时间" or key == u"年份" or key == u"年代" or key == u"上映":
                            data = SeedsTemplateProcessor.make_up_year(data)
                        d[key] = data
                        print u"★STEP INFO★: Filter item(%2s): %s -->>> %s" % (len(data), key, " ".join(data))
                    else:
                        raise ValueError(u"未预期的extract_type: %s" % item["extract_type"])
                print u"★STEP INFO★: Basic %s seeds(page 1) 预期的链接数 = %s" % (category, count)
                # 将所有的filter/item/data进行排列组合，产生basic_url列表.
                if len(keys) == 0:
                    return result
                urls = list()
                for data in d[keys[0]]:
                    urls.append(filter_url_pattern.replace("[#%s#]" % keys[0], data.strip()))
                for i in xrange(1, len(keys)):
                    tmp_urls1 = list()
                    for j in xrange(0, len(urls)):
                        tmp_urls2 = list()
                        for data in d[keys[i]]:
                            tmp_urls2.append(urls[j].replace("[#%s#]" % keys[i], data.strip()))
                        tmp_urls1 += tmp_urls2
                    urls = tmp_urls1

                result[category] += urls
                print u"★STEP INFO★: basic %s seeds(page 1) 去重前的链接数 = %s" % (category, len(urls))
                urls = set(urls)
                print u"★STEP INFO★: basic %s seeds(page 1) 去重后的链接数 = %s" % (category, len(urls))
        return result

    def extract_page_count(self, category, response):
        """解析XML模板，并从当前索引页抽取出总页数.

        @param category: 当前正在处理的页面所属的category.
        @param response: 当前正在处理的页面的response对象.
        @return: 返回抽取到的页数.
        """
        try:
            page_count = 0
            d = getattr(self, category)
            extract_type = d["page_count"]["extract_type"]
            if extract_type == "xpath":
                pattern = d["page_count"]["pattern"]
                selector = Selector(response=response, type="html")
                page_count = "".join(selector.xpath(pattern).extract()).strip()
                if page_count != u"" and not re.match(ur"\d+", page_count):
                    log.msg(u"抽取到的page_count不是一个数字！", level=log.ERROR)
                    raise ValueError(u"抽取到的page_count不是一个数字, 其值为:\"%s\"！请检查page_count的模板是否正确."
                                     % page_count)
                if page_count == u"":
                    page_count = -1
                else:
                    page_count = int(page_count)
            elif extract_type == "text" or extract_type == "json":
                pattern = (d["page_count"]["pattern"]).strip()
                if not re.match(ur"\d+", pattern):
                    log.msg(u"page_count/pattern的值必须是自然数，请确保配置文件的正确性.", level=log.ERROR)
                    raise ValueError(u"page_count/pattern的值必须是自然数，请确保配置文件的正确性.")
                page_count = int(pattern)

            return page_count
        except Exception, err:
            log.msg(traceback.format_exc(), level=log.ERROR)
            raise err
        return -1

    def extract_video_info(self, category, response):
        """解析XML模板，并从当前索引页抽取出所有视频链接(种子列表).

        @param category: 当前正在处理的页面所属的category.
        @param response: 当前正在处理的页面的response对象.
        @return: 返回抽取到的所有视频链接(种子列表).
        """
        result_list = []
        try:
            template_dict = getattr(self, category)["video_info"]
            if template_dict["extract_type"] == "xpath":
                selector = Selector(response=response, type="html")
                # locate base tag.
                nodes = selector.xpath(template_dict["base_tag"])
                for node in nodes:
                    # extract data.
                    video_dict = {}
                    for field in template_dict.keys():
                        if field == "base_tag" or field == "extract_type":  # 特别注意，此处需要排除不该有的标签.
                            continue
                        value = u"   ".join(node.xpath(unicode(template_dict[field]["path"])).extract()).strip()
                        if template_dict[field]["concat"] != u"":
                            value = (u"%s" % unicode(template_dict[field]["concat"])).replace("${DATA}", value)
                        video_dict[field] = value
                    result_list.append(video_dict)
                pass
            elif template_dict["extract_type"] == "json":
                text = response.body.strip()
                if not text.startswith(u"{"):
                    matcher = re.compile(ur"\{.+\}").search(text)
                    if matcher:
                        text = matcher.group()
                if not text.startswith(u"{"):
                    log.msg(u"当前待处理的页面是按照一个json页面处理的，但它并不是一个json页面!", level=log.ERROR)
                    return result_list
                target = json.loads(text)
                target = jsonpath(target, template_dict["base_tag"])
                # 当base_tag为空list时，jsonpath函数在path为$.XXX.*的形式下会找不到空list下的子元素，所以会返回False.
                if isinstance(target, bool):
                    target = []
                if not isinstance(target, list):
                    raise ValueError(u"通过path:%s 应该获取到一个列表(list), 而当前类型为: %s!"
                                     % (template_dict["base_tag"], type(target)))
                # 遍历所有视频.
                for node in target:
                    # extract data.
                    video_dict = {}
                    for field in template_dict.keys():
                        if field == "base_tag" or field == "extract_type":  # 特别注意，此处需要排除不该有的标签.
                            continue
                        value = jsonpath(node, unicode(template_dict[field]["path"]), "VALUE")
                        if isinstance(value, bool) and value is False:
                            value = []
                        if value is None:
                            value = u""
                        if isinstance(value, list):
                            for i in xrange(0, len(value)):
                                if value[i] is None:
                                    value[i] = u""
                                elif isinstance(value[i], bool) \
                                    or isinstance(value[i], int) \
                                        or isinstance(value[i], float):
                                    value[i] = u"%s" % value[i]
                        value = u"   ".join(value).strip()
                        if unicode(template_dict[field]["concat"]) != u"":
                            value = (u"%s" % unicode(template_dict[field]["concat"])).replace("${DATA}", value)
                        video_dict[field] = value

                    result_list.append(video_dict)
            else:
                raise ValueError(u"不识别的extrace_type: %s" % template_dict["extract_type"])
            # TODO check video info validity(each field).
            # 去掉video_url链接里的垃圾字符串.
            for result in result_list:
                if "video_url" not in result:
                    log.msg(u"video_url tag not found!", level=log.ERROR)
                    continue
                for regex in getattr(self, category)["video_url_regex"]:
                    matcher = re.compile(ur"%s" % regex).search(result["video_url"])
                    if matcher:
                        result["video_url"] = matcher.group()
        except Exception, err:
            log.msg(traceback.format_exc(), level=log.ERROR)
            raise err
        return result_list

    @staticmethod
    def make_up_year(year_list):
        """对筛选器中的年份字段进行年份的补充.
        例如：写youku的种子模板时时2014年，所以筛选器最多只到2014年，
        但是当过了一年(2015年)后扔使用该种子模板就会缺失2015年的筛选，
        本函数就是用来补充年份到当前的年份.

        @param year_list: 筛选器中的year列表.
        @return 返回新的补充了year的year列表.
        """
        try:
            num_pattern = re.compile(ur"\d+")
            max_num = -1000
            for year in year_list:
                matcher = num_pattern.match(year.strip())
                if matcher and int(matcher.group()) > max_num:
                    max_num = int(matcher.group())
            if len(str(max_num)) == 2:
                max_num = int("20%s" % max_num)
            if max_num < 2000:
                return year_list
            year_now = int(time.strftime('%Y', time.localtime(time.time())))
            if year_now > max_num and year_now - max_num <= 10:
                print u"★STEP INFO★: Make up year -->>> from [%s] to [%s]" % (max_num+1, year_now)
                log.msg(u"种子模板filter中的 时间/年份/年代 字段可能已经过期，请更新至最新年份！", level=log.WARNING)
                for i in xrange(max_num+1, year_now+1):
                    year_list.append(str(i))
        except Exception, err:
            log.msg(u"给filter补充年份时发生未预期的错误!", level=log.ERROR)
            raise err
        return year_list

    def check_template_validity(self):
        """检查种子XML模板的结构是否合法.
        出现不合法情况时以异常的形式抛出.
        """
        # check seeds/extract_type.
        if self.page_type.strip() not in ["html", "json", "xml"]:
            raise ValueError(u"page_type必须是html，json，xml中的一项.")
        for category in CategoryNames:
            category_node = getattr(self, category)
            if len(category_node) == 0:
                raise ValueError(u"未找到%s节点." % category)
            # check page_count.
            keys = category_node.keys()
            # check filter_url_pattern.
            if "filter_url_pattern" not in keys:
                raise ValueError(u"%s节点下或common节点下必须至少有一个拥有节点%s，且该节点值不能为空。" % (category, "filter_url_pattern"))
            # check filter.
            if "filter" not in keys:
                raise ValueError(u"%s节点下或common节点下必须至少有一个拥有节点%s" % (category, "filter"))
            if "page_count" not in keys:
                raise ValueError(u"%s节点下或common节点下必须至少有一个拥有节点%s" % (category, "page_count"))
            keys = category_node["page_count"].keys()
            # check page_count/extract_type.
            if "extract_type" not in keys or len(category_node["page_count"]["extract_type"].strip()) == 0:
                raise ValueError(u"%s节点必须拥有属性%s" % ("page_count", "extract_type"))
            # check page_count/pattern.
            if "pattern" not in keys or len(category_node["page_count"]["pattern"].strip()) == 0:
                raise ValueError(u"%s节点下必须至少拥有节点%s，且该节点值不能为空。" % ("page_count", "pattern"))
            # check page_count/start_page_count.
            if "start_page_count" not in keys or int(category_node["page_count"]["start_page_count"]) < 0:
                raise ValueError(u"%s节点下必须至少拥有节点%s，且该节点值必须为自然数。"
                                 % ("page_count", "start_page_count"))
            # check video_info.
            if "video_info" not in category_node.keys():
                raise ValueError(u"%s节点下或common节点下必须至少有一个拥有节点%s" % (category, "video_info"))
            keys = category_node["video_info"].keys()
            # check video_info/extract_type.
            if "extract_type" not in keys or len(category_node["video_info"]["extract_type"].strip()) == 0:
                raise ValueError(u"%s节点必须至少拥有属性%s" % ("video_info", "extract_type"))
            # check video_info/base_tag.
            if "base_tag" not in keys or len(category_node["video_info"]["base_tag"].strip()) == 0:
                raise ValueError(u"%s节点下必须至少拥有节点%s，且该节点值不能为空。" % ("video_info", "base_tag"))
            # check video_info/video_url.
            if "video_url" not in keys or len(category_node["video_info"]["video_url"]["path"]) == 0:
                raise ValueError(u"%s节点下必须至少拥有节点%s，且该节点值不能为空。" % ("video_info", "video_url"))
        pass