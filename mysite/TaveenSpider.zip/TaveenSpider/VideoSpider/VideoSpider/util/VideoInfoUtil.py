# coding=utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.08.22"


from TaveenUtil.Constants import *
from VideoInfo import VideoInfo

from scrapy.spider import log
import time
import re


class VideoInfoUtil(object):
    """[静态类]与视频信息(VideoInfo)有关的所有公共操作的封装类.
    """

    # use as static var.
    length_pattern_1 = re.compile(ur"(?:共|全)\s*(\d+)\s*(?:集|期|话)+|(\d+)\s*(?:集|期|话)+\s*全")
    length_pattern_2 = re.compile(ur"更新.+\d+.+?(?:共|全)+?(\d+)(?:集|期|话)+|更新.+\d+.+?(\d+)(?:集|期|话)+全")
    length_pattern_3 = re.compile(ur"更新.+\d+.+?/ *(\d+)(?:集|期|话)+")

    cur_ep_pattern_1 = re.compile(ur"更新(?:至|到)\s*(\d+) *(?:年|-) *(\d+) *(?:月|-) *(\d+) *(?:日|期)?")
    cur_ep_pattern_2 = re.compile(ur"更新(?:至|到)\s*(\d+) *(?:月|-)(\d+)")
    cur_ep_pattern_3 = re.compile(ur"更新(?:至|到)\s*(\d+) *(?:集|期|话)*")

    ep_no_pattern_1 = re.compile(ur"(\d{2,4})(?:年|-)(\d+)(?:月|-)(\d+)(?:日)?")
    ep_no_pattern_2 = re.compile(ur"(\d{1,2})(?:月|-)(\d+)")
    ep_no_pattern_3 = re.compile(ur"第*(\d+)(?:集|期|话)")

    rate_pattern = re.compile(ur"\d+(?:\.\d+)")

    year_pattern = re.compile(ur"19\d{2}|2\d{3}")

    #date_pattern_1 = re.compile(ur"((((19|20)?\d{2})(0[1-9]|1[012])(0[1-9]|[12]\d|30))|(((19|20)?\d{2})(0[13578]|1[02])"
    #                            ur"31)|(((19|20)?\d{2})02(0[1-9]|1\d|2[0-8]))|((((19|20)?([13579][26]|[2468][048]|0[48]"
    #                            ur"))|(2000))0229))")
    date_pattern_1 = re.compile(ur"((((19|20)?\d{2})(?:年|-)*(0[1-9]|1[012])(?:月|-)*(0[1-9]|[12]\d|30))|"
                                ur"(((19|20)?\d{2})(?:年|-)*(0[13578]|1[02])(?:月|-)*31)|(((19|20)?\d{2})"
                                ur"(?:年|-)*02(?:月|-)*(0[1-9]|1\d|2[0-8]))|((((19|20)?([13579][26]|[2468]"
                                ur"[048]|0[48]))|(2000))(?:年|-)*02(?:月|-)*29))")

    pubdate_pattern_1 = re.compile(u"(\d+)(?:年|-)(\d+)(?:月|-)(\d+)(?:日)?")
    pubdate_pattern_2 = re.compile(u"(\d+)(?:年|-)(\d+)(?:月|-)")
    pubdate_pattern_3 = re.compile(u"(\d+)(?:年)")

    int_pattern = re.compile(ur"\d+")
    simple_int_pattern = re.compile(ur"^\s*\d+\s*$")

    @staticmethod
    def is_rubbish(title):
        """根据给定的title返回这个VideoInfo是否为垃圾视频信息(如预告，花絮等).

        @param title: 视频信息的title字段.
        @return: 返回是否为垃圾视频信息.
        """
        title = VideoInfoUtil.full_width_to_half(title)
        title = VideoInfoUtil.string_denoising(title)
        # Modified by chjchen on 2015.04.23
        # 这里作了一些修改，增加了几种预告片的格式，见第3,4行
        rubbish_text = u"(.*预告$)|(.*预告片$)|(.*預告$)|(.*片段$)|(.*片花$)|(.*神剪$)|(.*花絮$)|(.*片头$)|(.*特辑$)|(.*片头曲 +.*)|" \
                       u"(.*片尾曲 +.*)|(.*片头曲$)|(.*片尾曲$)|" \
                       u"(^预告片.*)|(^预告.*)|(.*预告集$)|" \
                       u"(.*预告片)(\d+)|(.*片花集$)|(.*预告片)(\d+)(秒)|(.*宣传片$)|(.*预告片.*)|(.*片头MV$)"
        # End of th Modify on 2015.04.23
        if re.compile(rubbish_text).match(title):
            return True
        return False

    @staticmethod
    def check_necessary_field(video_info):
        """检查参数传入的VideoInfo对象的必要字段中的信息是否有效.

        当缺失信息时，该函数会将提示以LOG的形式输出，并在最后返回False.

        @param: 待检查的VideoInfo对象.
        @return: 返回是否所有必要的字段都有有效的信息.
        """
        assert isinstance(video_info, VideoInfo)

        flag = True

        if video_info.url == u"":
            log.msg(u"url字段不能为空(url字段对应album页面的albumuri，对应episode页面的url)!", level=log.ERROR)
            flag = False
        if video_info.website == u"":
            log.msg(u"website字段不能为空! URL = %s" % video_info.url, level=log.ERROR)
            flag = False
        if video_info.title == u"":
            log.msg(u"title字段不能为空! URL = %s" % video_info.url, level=log.ERROR)
            flag = False
        if video_info.category not in CategoryNames and video_info.category not in CategoryNames_CH:
            log.msg(u"非法的category: %s; URL = %s" % (video_info.category, video_info.url), level=log.ERROR)
            flag = False
        if video_info.page_type not in PageType.PageTypeNames:
            log.msg(u"非法的page_type: %s; URL = %s" % (video_info.page_type, video_info.url), level=log.ERROR)
            flag = False
        if video_info.page_type == PageType.EPISODE_PAGE:
            if video_info.album_id == u"":
                log.msg(u"album_id字段不能为空! URL = %s" % video_info.url, level=log.ERROR)
                flag = False
            if (video_info.no == u"" or video_info.no <= 0) and video_info.category != u"电影" \
                    and video_info.category != u"movie":
                log.msg(u"分集页没有抓取到no字段! URL = %s" % video_info.url, level=log.WARNING)
        if video_info.idc is None or video_info.idc == u"":
            video_info.generate_md5()
        return flag

    @staticmethod
    def format_title(title):
        """格式化title字段.

        @param title: 待格式化的文本.
        @return: 格式化后的文本.
        """
        title = VideoInfoUtil.full_width_to_half(title)
        title = VideoInfoUtil.string_denoising(title)

        special_chars = [u":"]
        for c in special_chars:
            title = title.strip(c)

        return title

    @staticmethod
    def format_othername(other_name):
        """格式化othername字段.

        @param other_name: 待格式化的文本.
        @return: 格式化后的文本.
        """
        #data = set()
        #names = other_name.split(u"/")
        #for name in names:
        #    n = name.split(u",")
        #    for _n in n:
        #        data.add(VideoInfoUtil.format_title(_n))
        #
        #result = u""
        #for d in data:
        #    result += u"   %s" % d
        other_name = VideoInfoUtil.format_title(other_name)

        result = other_name
        result = re.sub(ur"(?: |　)*(?:/|,)(?: |　)*", u"/", result)
        result = u"   ".join(result.split(u"/"))
        return result.strip()

    @staticmethod
    def format_category(value):
        """格式化category字段.

        @param value: 待格式化的文本.
        @return: 格式化后的文本，该函数将category格式化成汉字的形式(因为要存储数据库).
        """
        value = VideoInfoUtil.full_width_to_half(value)
        value = VideoInfoUtil.string_denoising(value)
        value = VideoInfoUtil.category_en_to_ch(value.strip())
        category = u""
        for c in [u"电视剧", u"电影", u"综艺", u"动漫"]:
            if c in value:
                category = c
        if u"动画片" in value:
            category = u"动漫"
        return category

    @staticmethod
    def category_en_to_ch(category_en):
        """将category转成中文表示.

        @param category_en: 英文表示的category.
        @return: 中文表示的category.
        """
        category_en = VideoInfoUtil.full_width_to_half(category_en)
        category_en = VideoInfoUtil.string_denoising(category_en)

        if u"tv" == category_en:
            return u"电视剧"
        elif u"movie" == category_en:
            return u"电影"
        elif u"variety" == category_en:
            return u"综艺"
        elif u"animation" == category_en:
            return u"动漫"
        if u"电视剧" == category_en:
            return u"电视剧"
        elif u"电影" == category_en:
            return u"电影"
        elif u"综艺" == category_en:
            return u"综艺"
        elif u"动漫" == category_en:
            return u"动漫"
        else:
            return u""

    @staticmethod
    def category_ch_to_en(category_ch):
        """将category转成英文表示.

        @param category_ch: 中文表示的category.
        @return: 英文表示的category.
        """
        category_ch = VideoInfoUtil.full_width_to_half(category_ch)
        category_ch = VideoInfoUtil.string_denoising(category_ch)

        if u"电视剧" in category_ch:
            return u"tv"
        elif u"电影" in category_ch:
            return u"movie"
        elif u"综艺" in category_ch:
            return u"variety"
        elif u"动漫" in category_ch or u"动画片" in category_ch or u"少儿" in category_ch:
            return u"animation"
        if u"tv" in category_ch:
            return u"tv"
        elif u"movie" in category_ch:
            return u"movie"
        elif u"variety" in category_ch:
            return u"variety"
        elif u"animation" in category_ch or u"动画片" in category_ch:
            return u"animation"
        else:
            return u""

    @staticmethod
    def format_year(year):
        """格式化year字段.

        @param year: 待格式化的文本.
        @return: 从文本中提取出的表示年份的数字.
        """
        #year_text = year
        year = VideoInfoUtil.full_width_to_half(year)
        year = VideoInfoUtil.string_denoising(year)

        if year == u"":
            return 0

        matcher = VideoInfoUtil.year_pattern.search(year)
        if matcher:
            year = matcher.group()
        else:
            matcher = VideoInfoUtil.int_pattern.search(year)
            if matcher:
                year = matcher.group()
            else:
                year = u"0"
            if len(u"%s" % year) != 4:
                #log.msg(u"抽取到一个可疑的year：%s; from = %s" % (year, year_text), level=log.WARNING)
                return 0
        return int(year)

    @staticmethod
    def format_pubdate(pubdate_str):
        """格式化pubdate字段.

        @param pubdate_str: 待格式化的文本.
        @return: 从文本中提取出的表示日期的文本.
        """
        pubdate_str = VideoInfoUtil.full_width_to_half(pubdate_str)
        pubdate_str = VideoInfoUtil.string_denoising(pubdate_str)

        if pubdate_str == u"":
            return None
        matcher = VideoInfoUtil.pubdate_pattern_1.search(pubdate_str)
        if matcher:
            return u"%s-%s-%s 00:00:00" % (matcher.group(1), matcher.group(2), matcher.group(3))
        matcher = VideoInfoUtil.pubdate_pattern_2.search(pubdate_str)
        if matcher:
            return u"%s-%s-01 00:00:00" % (matcher.group(1), matcher.group(2))
        matcher = VideoInfoUtil.pubdate_pattern_3.search(pubdate_str)
        if matcher:
            return u"%s-01-01 00:00:00" % matcher.group(1)
        return None

    @staticmethod
    def format_length(length, category=""):
        """格式化length字段.

        @param length: 待格式化的文本.
        @param category: 当前正在处理的视频信息的category(该参数用来给length字段的提取提供更多的参考信息).
        @return: 从文本中提取出的表示视频总集数或者总时长的数字.
        """
        category = VideoInfoUtil.category_ch_to_en(category)
        if category == u"movie" and length == u"":
            return 1
        if length == u"":
            return 0
        length = VideoInfoUtil.full_width_to_half(length)
        length = VideoInfoUtil.string_denoising(length)

        matcher = VideoInfoUtil.length_pattern_1.search(length)
        if matcher:
            for v in matcher.groups():
                if v is not None:
                    return int(v)
        else:
            matcher = VideoInfoUtil.length_pattern_2.search(length)
            if matcher:
                for v in matcher.groups():
                    if v is not None:
                        return int(v)
            else:
                matcher = VideoInfoUtil.length_pattern_3.search(length)
                if matcher:
                    return int(matcher.group(1))
        if category != u"variety" and VideoInfoUtil.simple_int_pattern.match(length):
            return int(length)

        if category == u"variety" or category == u"movie":
            return 1
        #log.msg("Can not extract value in field length: %s." % value, level=log.WARNING)
        return 0

    @staticmethod
    def format_curEpisode(cur_episode, category=""):
        """格式化curEpisdoe字段.

        @param cur_episode: 待格式化的文本.
        @param category: 当前正在处理的视频信息的category(该参数用来给curEpisode字段的提取提供更多的参考信息).
        @return: 从文本中提取出的表示当前更新到哪一集的数字.
        """
        category = VideoInfoUtil.category_ch_to_en(category)
        if category == u"movie" and cur_episode == u"":
            return 1
        if cur_episode == u"":
            return 0
        cur_episode = VideoInfoUtil.full_width_to_half(cur_episode)
        cur_episode = VideoInfoUtil.string_denoising(cur_episode)

        matcher = VideoInfoUtil.cur_ep_pattern_1.search(cur_episode)
        if matcher:
            year = matcher.group(1)
            month = matcher.group(2)
            day = matcher.group(3)
            if len(year) == 2:
                year = u"20%s" % year
            value = u"%s%s%s" % (year,
                                 VideoInfoUtil.__format_single_digit(int(month)),
                                 VideoInfoUtil.__format_single_digit(int(day)))
            return int(value)
        matcher = VideoInfoUtil.cur_ep_pattern_2.search(cur_episode)
        if matcher:
            month = matcher.group(1)
            day = matcher.group(2)
            year = time.strftime("%Y", time.localtime(time.time()))
            value = u"%s%s%s" % (year,
                                 VideoInfoUtil.__format_single_digit(int(month)),
                                 VideoInfoUtil.__format_single_digit(int(day)))
            return value
        matcher = VideoInfoUtil.cur_ep_pattern_3.search(cur_episode)
        if matcher:
            data = matcher.group(1)
            if len(data) == 6:
                if category == u"variety":
                    return int(u"20%s" % data)
                else:
                    matcher = VideoInfoUtil.date_pattern_1.search(data)
                    if matcher:
                        data = matcher.group(1)
                        return int(u"20%s" % data)
            return int(data)
        if VideoInfoUtil.simple_int_pattern.match(cur_episode):
            return int(cur_episode)
        # 如果上面的所有情况都没有抽取到curEpisode.
        matcher = VideoInfoUtil.length_pattern_1.search(cur_episode)
        if matcher:
            for v in matcher.groups():
                if v is not None:
                    return int(v)
        #log.msg("Can not extract value in field curEpisode: %s." % value, level=log.WARNING)
        if category == u"movie":
            return 1
        return 0

    @staticmethod
    def format_no(no, category="", is_return_last_int_in_the_text_if_no_not_found=True):
        """格式化no字段.

        @param no: 待格式化的文本.
        @param is_return_last_int_in_the_text_if_no_not_found: 如果从给定的文本中没有找到明显的表示集数的数字，
                                                               则是否返回文本中遇到的最后一个数字作为可能的no.
        @return: 从文本中提取出的表示当前分集是第几集的数字.
        """
        if no == u"":
            return 0
        no = VideoInfoUtil.full_width_to_half(no)
        no = VideoInfoUtil.string_denoising(no)
        category = VideoInfoUtil.category_ch_to_en(category)

        matcher = VideoInfoUtil.ep_no_pattern_1.search(no)
        if matcher:
            year = matcher.group(1)
            month = matcher.group(2)
            day = matcher.group(3)
            if len(year) == 2:
                year = u"20%s" % year
            return u"%s%s%s" % (year,
                                VideoInfoUtil.__format_single_digit(int(month)),
                                VideoInfoUtil.__format_single_digit(int(day)))
        matcher = VideoInfoUtil.ep_no_pattern_2.search(no)
        if matcher:
            month = matcher.group(1)
            day = matcher.group(2)
            year = time.strftime("%Y", time.localtime(time.time()))
            return u"%s%s%s" % (year,
                                VideoInfoUtil.__format_single_digit(int(month)),
                                VideoInfoUtil.__format_single_digit(int(day)))
        matcher = VideoInfoUtil.ep_no_pattern_3.search(no)
        if matcher:
            return int(matcher.group(1))
        matcher = VideoInfoUtil.int_pattern.search(no)
        if matcher and len(matcher.group()) == 6:
            return u"20%s" % matcher.group()
        if category == u"variety":
            matcher = VideoInfoUtil.date_pattern_1.search(no)
            if matcher:
                no = matcher.group().replace(u"年", u"").replace(u"月", u"").replace(u"-", u"")
                return int(no)
        if is_return_last_int_in_the_text_if_no_not_found:
            matcher = VideoInfoUtil.int_pattern.findall(no)
            data = 0
            for m in matcher:
                if m is not None:
                    data = m
            return int(data)
        #log.msg("Can not extract value in field no: %s." % value, level=log.WARNING)
        return 0

    @staticmethod
    def format_rate(value):
        """格式化rate字段.

        @param value: 待格式化的文本.
        @return: 返回从文本中提取到的表示评分的浮点型数字.
        """
        value = VideoInfoUtil.full_width_to_half(value)
        value = VideoInfoUtil.string_denoising(value)

        value = value.replace(u" ", u"")
        if value == u"":
            return 0
        matcher = VideoInfoUtil.rate_pattern.search(value)
        if matcher:
            return float(matcher.group(0))
        #log.msg("Rate value: %s can not be convert to type float." % value, level=log.WARNING)
        return 0

    @staticmethod
    def format_quality(quality_string):
        """格式化quality字段.

        @param quality_string: 待格式化的包含当前视频清晰度的文本.
        @return: 返回当前视频清晰度的文本.
        """
        quality_string = VideoInfoUtil.full_width_to_half(quality_string)
        quality_string = quality_string.upper()

        for q in [u"流畅", u"极速", u"标清", u"超清", u"720P", u"1080P"]:
            if q in quality_string:
                return q
        if u"SD" in quality_string:
            return u"超清"
        if u"HD" in quality_string:
            return u"高清"
        return u""

    @staticmethod
    def format_pay(is_pay):
        """格式化pay字段.

        @param is_pay: 待格式化的包含当前视频是否为付费视频的文本.
        @return: 返回当前视频是否为付费视频，1表示付费，0表示免费.
        """
        is_pay = VideoInfoUtil.full_width_to_half(is_pay)
        is_pay = VideoInfoUtil.string_denoising(is_pay)

        # TODO 这个函数貌似没有写完呢.

        return is_pay

    @staticmethod
    def format_actor(actor_str):
        """格式化actor.

        这个方法主要是将演员中的全角转半角，去除垃圾字符，去除未知、暂无等垃圾信息.

        @param actor_str: 待格式化的文本.
        @return: 格式化后的文本.
        """
        actor_str = VideoInfoUtil.full_width_to_half(actor_str)
        actor_str = VideoInfoUtil.string_denoising(actor_str)

        for text in [u"未知", u"暂无"]:
            if text in actor_str:
                actor_str = actor_str.replace(text, u"").replace(u"      ", u"   ")

        return actor_str.strip()

    @staticmethod
    def format_drama(drama):
        """格式化drama.

        @param 待格式化的文本.
        @return: 格式化后的drama文本.
        """
        drama = VideoInfoUtil.full_width_to_half(drama)
        drama = VideoInfoUtil.string_denoising(drama)

        # 排除一些表示"无简介"文字.
        for rubbish_text in [u"暂无"]:
            if drama == rubbish_text:
                return u""

        # 去掉drama中的类似"收起"、"展开"、"查看详情"之类的文字(注意，以后遇到更多的情况再补充).
        for end_with in [u"查看详情>>", u"查看全部>>", u"收起", u"展开"]:
            if drama.endswith(end_with):
                drama = drama[:drama.rindex(end_with)+1].strip()

        for start_with in [u"简介:"]:
            if drama.startswith(start_with):
                drama = drama[len(start_with):len(drama)-1].strip()

        return drama.strip()

    @staticmethod
    def full_width_to_half(string):
        """把字符串中的所有全角字符转换为半角字符.

        @param string: 待转换的字符串.
        @return: 转换后的字符串.
        """
        if not isinstance(string, str) and not isinstance(string, unicode):
            string = u"%s" % string
        result = u""
        for uchar in string:
            inside_code = ord(uchar)
            if inside_code == 12288:                               # 全角空格直接转换
                inside_code = 32
            elif 65281 <= inside_code <= 65374:  # 全角字符（除空格）根据关系转化
                inside_code -= 65248
            result += unichr(inside_code)
        return result

    @staticmethod
    def string_denoising(string):
        """对字符串中的垃圾字符进行清洗.

        @param string: 待清洗的字符串.
        @return: 清洗后的字符串.
        """
        string = VideoInfoUtil.full_width_to_half(string)
        string = string.replace(u"\t", u"").replace(u"\r", u"").replace(u"\n", u"")

        # 特殊字符替换.
        string = string.replace(u"・", u"·")

        return string.strip()

    @staticmethod
    def __format_single_digit(int_value):
        """格式化数字为字符串，主要是将个位数字转换成前面带有前缀0的字符串(如8-->>>08).

        @param 待格式化的数字.
        @return 格式化后的字符串.
        """
        if 0 <= int_value <= 9:
            return u"0%s" % int_value
        return int_value