# coding=utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.09.03"


from TaveenUtil.Util import SqlUtil, DatetimeUtil
from TaveenUtil.Constants import PageType
from ..util.VideoInfo import VideoInfo

import datetime
import json


class VideoInfoSqlGenerator(object):
    """与视频信息(VideoInfo)有关的SQL语句的生成器类.

    """

    @staticmethod
    def sql_insert(video_info):
        """生成插入视频信息的SQL语句(专辑页信息和分集页信息均适用).

        @param video_info: VideoInfo对象(其中包含一套完整的视频信息).
        """
        assert isinstance(video_info, VideoInfo)
        if video_info.pubdate == u"":
            video_info.pubdate = None
        video_info.idc = video_info.generate_md5()
        datetime_now = DatetimeUtil.get_datetime_now_str()
        sql = u""
        if video_info.page_type == PageType.ALBUM_PAGE:
            sql = u"INSERT INTO %s_album(title, video_name, othername, category, pay, " \
                  u"image, albumuri, actor, director, screenwriter, drama, type, region, year, pubdate, updateTime, " \
                  u"length, curEpisode, rate, valid, quality, isEnd, publish_area, idc, lastModified) VALUES(%s, %s, " \
                  u"%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) " \
                  % (video_info.website,
                     SqlUtil.format_field(video_info.title, "str"),
                     SqlUtil.format_field(video_info.video_name, "str"),
                     SqlUtil.format_field(video_info.othername, "str"),
                     SqlUtil.format_field(video_info.category, "str"),
                     SqlUtil.format_field(video_info.pay, "int"),
                     SqlUtil.format_field(video_info.image, "str"),
                     SqlUtil.format_field(video_info.url, "str"),
                     SqlUtil.format_field(video_info.actor, "str"),
                     SqlUtil.format_field(video_info.director, "str"),
                     SqlUtil.format_field(video_info.screenwriter, "str"),
                     SqlUtil.format_field(video_info.drama, "str"),
                     SqlUtil.format_field(video_info.type, "str"),
                     SqlUtil.format_field(video_info.region, "str"),
                     SqlUtil.format_field(video_info.year, "int"),
                     SqlUtil.format_field(video_info.pubdate, "str"),
                     SqlUtil.format_field(datetime_now, "str"),
                     SqlUtil.format_field(video_info.length, "int"),
                     SqlUtil.format_field(video_info.curEpisode, "int"),
                     SqlUtil.format_field(video_info.rate, "float"),
                     SqlUtil.format_field("1", "int"),
                     SqlUtil.format_field(video_info.quality, "str"),
                     SqlUtil.format_field(video_info.isEnd, "int"),
                     SqlUtil.format_field(video_info.publish_area, "str"),
                     SqlUtil.format_field(video_info.idc, "str"),
                     SqlUtil.format_field(datetime_now, "str"))
            sql += u"ON DUPLICATE KEY UPDATE title = %s, video_name = %s, othername = %s, category = %s, pay = %s, " \
                   u"image = %s, albumuri = %s, actor = %s, director = %s, screenwriter = %s, drama = %s, type = %s, " \
                   u"region = %s, year = %s, pubdate = %s, length = %s, curEpisode = %s, rate = %s, valid = %s, " \
                   u"quality = %s, isEnd = %s, publish_area = %s, idc = %s, lastModified = %s" \
                   % (SqlUtil.format_field(video_info.title, "str"),
                      SqlUtil.format_field(video_info.video_name, "str"),
                      SqlUtil.format_field(video_info.othername, "str"),
                      SqlUtil.format_field(video_info.category, "str"),
                      SqlUtil.format_field(video_info.pay, "int"),
                      SqlUtil.format_field(video_info.image, "str"),
                      SqlUtil.format_field(video_info.url, "str"),
                      SqlUtil.format_field(video_info.actor, "str"),
                      SqlUtil.format_field(video_info.director, "str"),
                      SqlUtil.format_field(video_info.screenwriter, "str"),
                      SqlUtil.format_field(video_info.drama, "str"),
                      SqlUtil.format_field(video_info.type, "str"),
                      SqlUtil.format_field(video_info.region, "str"),
                      SqlUtil.format_field(video_info.year, "int"),
                      SqlUtil.format_field(video_info.pubdate, "str"),
                      SqlUtil.format_field(video_info.length, "int"),
                      SqlUtil.format_field(video_info.curEpisode, "int"),
                      SqlUtil.format_field(video_info.rate, "float"),
                      SqlUtil.format_field("1", "int"),
                      SqlUtil.format_field(video_info.quality, "str"),
                      SqlUtil.format_field(video_info.isEnd, "int"),
                      SqlUtil.format_field(video_info.publish_area, "str"),
                      SqlUtil.format_field(video_info.idc, "str"),
                      SqlUtil.format_field(datetime_now, "str"))
        elif video_info.page_type == PageType.EPISODE_PAGE:
            sql = u"INSERT INTO %s_url(video_name, category, year, no, url, director, actor, isValidURL, guests, " \
                  u"album_id, idc,  last_modify) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)" \
                  % (video_info.website,
                     SqlUtil.format_field(video_info.title, "str"),
                     SqlUtil.format_field(video_info.category, "str"),
                     SqlUtil.format_field(video_info.year, "int"),
                     SqlUtil.format_field(video_info.no, "int"),
                     SqlUtil.format_field(video_info.url, "str"),
                     SqlUtil.format_field(video_info.director, "str"),
                     SqlUtil.format_field(video_info.actor, "str"),
                     SqlUtil.format_field("1", "int"),
                     SqlUtil.format_field(video_info.guests, "str"),
                     SqlUtil.format_field(video_info.album_id, "str"),
                     SqlUtil.format_field(video_info.idc, "str"),
                     SqlUtil.format_field(datetime_now, "str"))
            sql += u"ON DUPLICATE KEY UPDATE video_name = %s, category = %s, year = %s, no = %s, url = %s, " \
                   u"director = %s, actor = %s, isValidURL = %s, guests = %s, album_id = %s, idc = %s, last_modify = %s" \
                   % (SqlUtil.format_field(video_info.title, "str"),
                      SqlUtil.format_field(video_info.category, "str"),
                      SqlUtil.format_field(video_info.year, "int"),
                      SqlUtil.format_field(video_info.no, "int"),
                      SqlUtil.format_field(video_info.url, "str"),
                      SqlUtil.format_field(video_info.director, "str"),
                      SqlUtil.format_field(video_info.actor, "str"),
                      SqlUtil.format_field("1", "int"),
                      SqlUtil.format_field(video_info.guests, "str"),
                      SqlUtil.format_field(video_info.album_id, "str"),
                      SqlUtil.format_field(video_info.idc, "str"),
                      SqlUtil.format_field(datetime_now, "str"))
        return sql

    @staticmethod
    def sql_query_by_url(website, page_type, url):
        """生成根据指定参数查询视频信息的SQL语句(专辑页和分集页均适用).

        @param website: 当前网站.
        @param page_type: 页面类型.
        @param url: 视频URL.
        """
        sql = u""
        if page_type == PageType.ALBUM_PAGE:
            sql = u"SELECT * FROM %s_album WHERE albumuri = '%s'" % (website, url)
        elif page_type == PageType.EPISODE_PAGE:
            sql = u"SELECT * FROM %s_url WHERE url = '%s'" % (website, url)
        return sql

    @staticmethod
    def sql_query_all_album_idc(website):
        """生成查询 指定website下的 所有专辑页的idc字段 的SQL语句.

        @param website: 当前网站.
        """
        sql = u"SELECT idc FROM %s_album where valid = 1" % website
        return sql

    @staticmethod
    def sql_query_all_episode_idc(website):
        """生成查询 指定website下的 所有分集页的idc字段 的SQL语句.

        @param website: 当前网站.
        """
        sql = u"SELECT idc FROM %s_url where isValidURL = 1" % website
        return sql

    @staticmethod
    def sql_query_episode_urls_by_album(website, album_id):
        """生成查询 指定website下的album_id为指定值的 所有分集页的url链接 的SQL语句.

        @param website: 当前网站.
        @param album_id: 专辑页链接.
        """
        sql = u"SELECT url FROM %s_url where album_id = '%s' and isValidURL = 1" % (website, album_id)
        return sql

    @staticmethod
    def sql_query_top_2_episode_by_album(website, album_id):
        """生成查询指定website和album_id的所有分集页信息的前两条信息.

        @param website: 当前网站.
        @param album_id: 专辑页链接.
        """
        sql = u"SELECT * FROM %s_url WHERE album_id = '%s' ORDER BY last_modify DESC LIMIT 2" % (website, album_id)
        return sql


class PageSpiderSqlGenerator(object):
    """与页面爬虫有关的SQL语句的生成器类(主要是爬虫状态和统计信息的操作).

    """

    @staticmethod
    def sql_insert_exec_log(statistics):
        """生成 插入stat_page_exec表中的爬虫执行登记信息 的SQL语句.

        @param statistics: 存储和表示页面爬虫执行统计信息的PageSpiderStatistics类的对象.
        """
        from ..statistics.PageSpiderStatistics import PageSpiderStatistics
        assert isinstance(statistics, PageSpiderStatistics)
        datetime_now = datetime.datetime.now()
        sql = u"INSERT INTO stat_page_exec(start_time, website, ip, time_used, spider_mode, " \
              u"state, scrapy_stat, create_time, modify_time) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s)" \
              % (SqlUtil.format_field(statistics.start_time, "str"),
                 SqlUtil.format_field(statistics.website, "str"),
                 SqlUtil.format_field(statistics.ip, "str"),
                 SqlUtil.format_field(statistics.time_used, "int"),
                 SqlUtil.format_field(statistics.spider_mode, "str"),
                 SqlUtil.format_field(statistics.result_state, "str"),
                 SqlUtil.format_field(statistics.scrapy_stat, "str"),
                 SqlUtil.format_field(datetime_now, "str"),
                 SqlUtil.format_field(datetime_now, "str"))
        return sql

    @staticmethod
    def sql_insert_to_change_log(row_dict):
        """生成 插入stat_v_change_log表中的视频信息字段变更统计信息的SQL语句.

        @param row_dict: 以字典形式存储的表示视频信息字段变更数据.
        """
        page_type = row_dict["page_type"].lower()
        if "album" in page_type:
            page_type = "album"
        elif "episode" in page_type:
            page_type = "episode"
        sql = u"INSERT INTO stat_v_change_log (start_time, website, page_type, url, ip, change_stat, last_modified) " \
              u"VALUES (%s, %s, %s, %s, %s, %s, %s)" \
              % (SqlUtil.format_field(row_dict["start_time"]),
                 SqlUtil.format_field(row_dict["website"]),
                 SqlUtil.format_field(page_type),
                 SqlUtil.format_field(row_dict["url"]),
                 SqlUtil.format_field(row_dict["ip"]),
                 SqlUtil.format_field(json.dumps(row_dict["change_stat"], ensure_ascii=False)),
                 SqlUtil.format_field(datetime.datetime.now()))
        return sql


class SeedsSpiderSqlGenerator(object):
    """与种子爬虫有关的SQL语句的生成器类(主要是爬虫状态和统计信息的操作).

    """

    @staticmethod
    def sql_insert_stat_seeds_exec(seeds_statistics, write_seeds_data=False):
        """生成 插入stat_seeds_exec表的种子爬虫执行及其统计信息 的SQL语句.

        @param seeds_statistics: 存储和表示种子爬虫执行统计信息的SeedsSpiderStatistics类的对象.
        @param write_seeds_data: 是否将种子爬虫抽取到的所有种子数据也写入stat_seeds_exec表.
        """
        from ..statistics.SeedsSpiderStatistics import SeedsSpiderStatistics
        assert isinstance(seeds_statistics, SeedsSpiderStatistics)
        seeds_data = "'{}'"
        if write_seeds_data:
            seeds_data = SqlUtil.format_field(json.dumps(seeds_statistics.seeds, ensure_ascii=False), "str")
        sql = u"INSERT INTO stat_seeds_exec (start_time, time_used, website, spider_mode, state, ip, video_stat, " \
              u"response_stat, extract_stat, seeds_data, last_modified) VALUES(%s, %s, %s, %s, %s, %s, %s, " \
              u"%s, %s, %s, %s)" \
              % (SqlUtil.format_field(seeds_statistics.start_time, "str"),
                 SqlUtil.format_field(seeds_statistics.time_used, "int"),
                 SqlUtil.format_field(seeds_statistics.website, "str"),
                 SqlUtil.format_field(seeds_statistics.spider_mode, "str"),
                 SqlUtil.format_field(seeds_statistics.result_state, "str"),
                 SqlUtil.format_field(seeds_statistics.ip, "str"),
                 SqlUtil.format_field(json.dumps(seeds_statistics.video_stat, ensure_ascii=False), "str"),
                 SqlUtil.format_field(json.dumps(seeds_statistics.response_stat, ensure_ascii=False), "str"),
                 SqlUtil.format_field(json.dumps(seeds_statistics.extract_stat, ensure_ascii=False), "str"),
                 seeds_data,
                 SqlUtil.format_field(datetime.datetime.now()))
        #print sql
        return sql


class LogAnalyzerSqlGenerator(object):
    """与日志分析程序(模块)有关的SQL语句的生成器类.

    """

    @staticmethod
    def sql_insert_warning_info(start_time, website, spider_type, ip, description, log_dir):
        """生成 插入stat_spider_warning表中的记录爬虫执行后产生的警告和错误的信息 的SQL语句.

        @param start_time: 爬虫程序的启动时间.
        @param website: 爬虫程序处理的网站名.
        @param spider_type: 爬虫程序的类型(是种子爬虫还是页面爬虫等).
        @param ip: 爬虫程序所在的机器的IP地址.
        @param description: 发生警告或错误的爬虫的LOG文件的摘要文本信息.
        @param log_dir: 发生警告或错误的爬虫的LOG文件所在的目录.
        """
        sql = u"INSERT INTO stat_spider_warning (start_time, website, spider_type, ip, description, " \
              u"log_dir, last_modified) VALUES(%s, %s, %s, %s, %s, %s, %s)" \
              % (SqlUtil.format_field(start_time),
                 SqlUtil.format_field(website),
                 SqlUtil.format_field(spider_type),
                 SqlUtil.format_field(ip),
                 SqlUtil.format_field(description),
                 SqlUtil.format_field(log_dir),
                 SqlUtil.format_field(datetime.datetime.now()))
        return sql