#coding:utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.09.13"


from TaveenUtil.Constants import PageType

import hashlib
import json


class VideoInfo(object):
    """视频信息实体类，每个VideoInfo对象表示一个视频实体(专辑信息或分集信息).

    该类中的各个字段名称与数据库中表的字段一致，故不对各字段进行一一解释.
    """

    def __init__(self):
        self.website = ""
        self.url = ""
        self.page_type = ""
        self.category = ""

        self.title = ""
        self.video_name = ""
        self.othername = ""
        self.image = ""
        self.album_id = ""
        self.actor = ""
        self.director = ""
        self.screenwriter = ""
        self.guests = ""
        self.drama = ""
        self.type = ""
        self.region = ""
        self.year = 0
        self.pubdate = ""
        self.length = 0
        self.curEpisode = 0
        self.no = 0
        self.rate = 0
        self.valid = 1
        self.quality = ""
        self.isEnd = 0
        # self.updateTime = ""
        self.publish_area = ""
        self.idc = ""
        self.pay = 0

    def generate_md5(self):
        """生成当前VideoInfo的md5指纹，用于比对视频是否有字段发生了变化."""
        self.idc = ""
        if self.page_type == PageType.ALBUM_PAGE:
            value = u"%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s" \
                    % (self.title, self.othername, self.category, self.image, self.album_id,
                       self.actor, self.director, self.screenwriter, self.drama, self.type,
                       self.region, self.year, self.pubdate, self.length, self.curEpisode,
                       self.rate, self.quality, self.isEnd, self.publish_area)
        elif self.page_type == PageType.EPISODE_PAGE:
            value = u"%s%s%s%s%s%s%s%s%s%s" \
                    % (self.title, self.othername, self.category, self.year, self.no,
                       self.url, self.director, self.actor, self.album_id, self.guests)
        else:
            raise ValueError(u"Wrong page type!")
        self.idc = hashlib.md5(value).hexdigest()
        return self.idc

    def makeup_video_info(self, video_info):
        """将参数中的VideoInfo信息补充到当前的VideoInfo对象中.

        注意：只补充缺失的信息，对于抽取到的信息，
             即使数据不够完整也暂时不作补充(因为当两个数据都不为空时，无法判断哪个是对的或者说更完整的).

        @param video_info: VideoInfo对象，该对象中的字段用来补充self对应的VideoInfo对象的视频信息.
        """
        assert isinstance(video_info, VideoInfo)
        for key in self.__dict__:
            if self.__dict__[key] == u"" or self.__dict__[key] == 0 or self.__dict__[key] is None:
                if video_info.__dict__[key] != u"" and video_info.__dict__[key] != 0 and self.__dict__[key] is not None:
                    self.__dict__[key] = video_info.__dict__[key]
        pass

    def dump(self):
        """返回包含当前VideoInfo对象的信息的json串."""
        return json.dumps(self.__dict__, ensure_ascii=False)

    def dict(self):
        """返回当前VideoInfo对象的字典，该方法用来方便的对VideoInfo进行操作(比如循环操作等)."""
        return self.__dict__

    @staticmethod
    def dict_to_video_info(dict_data, website, page_type):
        """从一个字典初始化出一个VideoInfo对象.

        初始化过程会从字典中自动匹配字段名.

        @param dict_data: 被初始化的包含数据信息的字典.
        @param website: 当前的网站.
        @param page_type: 当前VideoInfo的页面类型.
        @return: 返回初始化好的VideoInfo对象.
        """
        video_info = VideoInfo()
        video_info.website = website
        video_info.page_type = page_type
        video_info_dict = video_info.dict()
        for field in video_info_dict.keys():
            if field not in dict_data:
                continue
            video_info_dict[field] = dict_data[field]
        return video_info