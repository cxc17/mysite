#coding:utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.09.21"

from TaveenUtil.Constants import PageType
from VideoInfo import VideoInfo


class VideoData(object):
    """[静态类]该类用来实现专辑页和分集页相互之间的信息补充(不知道叫什么名字好，就叫了VideoData).

    该类的设计思路：
        1. 该类旨在实现专辑页信息和分集页信息之间的信息交换，以弥补专辑页信息不全或分集页信息不全的问题.
        2. 该类维护着一个静态的字典，这个字典中的每个键为一个视频专辑页的链接，值为一个字典，其中key为album的节点对应的值存储专辑的VideoInfo，
           key为episode的节点对应的值存储分集的VideoInfo列表.大致如下:
           {专辑URL: {"album": 专辑的VideoInfo, "episode": [各个分集的VideoInfo]}}
        3. 当爬虫抽取出一个VideoInfo对象时，调用本类的get_video_info_list函数，该函数返回一个VideoInfo列表，
           该列表中的VideoInfo为交换信息后、信息完整了的视频信息对象，程序应将这个VideoInfo列表中的每个VideoInfo存储到数据库中.
        4. video_data_dict主要的用处和目标是，在内存中留存所有的专辑信息，用于与每次进来的分集信息进行信息互补；
           最终的效果是所有的分集页信息最先写入数据库，所有留存的所有专辑信息需要在程序的最后统一写入数据库中.
        5. get_video_info_list函数的逻辑大致如下：
           1) 如果当前VideoInfo是一个专辑页，则：
               1.1) 如果video_data_dict中没有该专辑的节点，则添加新节点，并将当前专辑的VideoInfo放在album节点下，返回空列表;
               1.2) 如果video_data_dict中已经有若干分集页，则与各个分集页交换和补充信息后，返回video_data_dict中的所有分集VideoInfo，
                    专辑页的VideoInfo留存在video_data_dict中.
           2). 如果当前VideoInfo是一个分集页，则
               1.1) 如果video_data_dict中已经有相应的专辑信息，则与专辑信息相互交换和补充信息后，将当前的VideoInfo;
               1.2) 如果video_data_dict中没有相应的专辑信息，则添加新节点，并将当前分集的VideoInfo放在episode节点下，返回空列表.
 """

    # use as static var.
    video_data_dict = {}

    @staticmethod
    def get_video_info_list(video_info):
        """传入一个VideoInfo对象，然后与现存的列表中的VideoInfo交换数据，返回新的需要写入数据库中的处理后的VideoInfo.

        信息交换只针对信息缺失的情况，假如分集的某字段有信息但是没有专辑对应字段的信息全，该分集是不会被交换信息的.

        @param video_info: 传入一个VideoInfo对象.
        @return: 返回信息交换后，信息相对完整了的VideoInfo列表(多为分集页的VideoInfo).
        """
        assert isinstance(video_info, VideoInfo)

        if video_info.page_type == PageType.ALBUM_PAGE:
            if video_info.url not in VideoData.video_data_dict:
                VideoData.video_data_dict[video_info.url] = {"album": video_info, "episode": []}
            elif video_info.url in VideoData.video_data_dict:
                VideoData.video_data_dict[video_info.url]["album"] = video_info
                result_list = []
                for v in VideoData.video_data_dict[video_info.url]["episode"]:
                    v.makeup_video_info(video_info)
                    video_info.makeup_video_info(v)
                    result_list.append(v)
                    VideoData.video_data_dict[video_info.url]["episode"].remove(v)
                return result_list
        elif video_info.page_type == PageType.EPISODE_PAGE:
            if video_info.album_id not in VideoData.video_data_dict:
                VideoData.video_data_dict[video_info.album_id] = {"album": None, "episode": [video_info]}
            elif video_info.album_id in VideoData.video_data_dict:
                if VideoData.video_data_dict[video_info.album_id]["album"] is None:
                    VideoData.video_data_dict[video_info.album_id]["episode"].append(video_info)
                else:
                    album_v_info = VideoData.video_data_dict[video_info.album_id]["album"]
                    album_v_info.makeup_video_info(video_info)
                    video_info.makeup_video_info(album_v_info)
                    return [video_info]
        else:
            raise ValueError(u"未预期的page_type: %s" % video_info.page_type)
        return []