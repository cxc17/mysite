#coding:utf-8
__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.09.22"

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html

from scrapy.spider import log
import traceback
import datetime

from TaveenUtil.SpiderConfig import SpiderConfig
from TaveenUtil.Constants import PageType
from TaveenUtil.Global import Global

from ..statistics.PageSpiderStatistics import PageSpiderStatistics
from ..util.VideoInfoUtil import VideoInfoUtil
from ..util.SQLGenerator import PageSpiderSqlGenerator
from ..util.SQLGenerator import VideoInfoSqlGenerator
from ..page_spiders.PageSpider import PageSpider
from ..util.VideoInfo import VideoInfo


class VideoInfoPipeline(object):
    """视频信息(VideoInfo)写入到数据库的管道类."""

    # Added by chjchen on 2015.04.21
    # 貌似process_item这一个函数没有多大的作用，下面的write_video_info_to_db函数在shutdown_ext文件里面已经会被直接调用
    # End of Add on 2015.04.21
    def process_item(self, item, spider):
        print u"VideoInfoPipeline = %s" % item["video_info"].dump()
        VideoInfoPipeline.write_video_info_to_db(item["video_info"])
        #return item
        pass

    @staticmethod
    def write_video_info_to_db(video_info):
        """将给定的video_info对象写入数据库.

        需要注意的是，正如VideoData中的注释说明，该函数并不会立即将video_info写入数据库，
        而是在专辑页和分集页相互交换信息之后才会写入数据库.
        这将表现为：专辑页的VideoInfo会在程序结束的时候写入数据库，分集页的VideoInfo会在与专辑页交换了信息后才会写入数据库.

        @param video_info: 待写入数据库的VideoInfo对象.
        """
        assert isinstance(video_info, VideoInfo)

        # 简单校验一下关键数据是否有缺失.
        VideoInfoUtil.check_necessary_field(video_info)

        video_info.generate_md5()

        if video_info.page_type == PageType.ALBUM_PAGE:
            # 如果发现idc不存在.
            if video_info.idc not in PageSpider.AlbumAllMd5:
                # 则先与数据库中最新的两条分集互补信息
                # 这么做是为了处理当本次爬虫只爬到专辑页而一个分集页都没爬取到的情况.
                ep_data_last2_sql = VideoInfoSqlGenerator.sql_query_top_2_episode_by_album(video_info.website,
                                                                                           video_info.url)
                ep_data_last2_data = Global.DbOperator_VideoBasic.query(ep_data_last2_sql)
                for ep_data in ep_data_last2_data:
                    video_info.makeup_video_info(VideoInfo.dict_to_video_info(ep_data,
                                                                              SpiderConfig.get_website(),
                                                                              PageType.EPISODE_PAGE))
                # 互补信息后，再次计算idc，如果idc在数据库中已存在，则直接返回，如果仍然不存在，则继续往下执行.
                video_info.generate_md5()
                if video_info.idc in PageSpider.AlbumAllMd5:
                    return

                # 代码执行到此处，说明当前idc在数据库中仍然不存在，那么就认为这条数据真的需要更新到数据库中了.
                sql_query = VideoInfoSqlGenerator.sql_query_by_url(video_info.website,
                                                                   video_info.page_type,
                                                                   video_info.url)
                print sql_query
                v_data_in_db = Global.DbOperator_VideoBasic.query(sql_query)
                # 更新前，先对比下哪些字段发生了变化，并记录下change log.
                if len(v_data_in_db) > 0:
                    v_data_in_db = v_data_in_db[0]
                    change_stat = VideoInfoPipeline.calculate_video_changes(video_info, v_data_in_db)
                    if len(change_stat) > 0:
                        # 将发生变化的字段登记到stat_change_log表中.
                        VideoInfoPipeline.write_change_log_to_db(video_info.url, video_info.page_type, change_stat)
                # 写入数据库前，处理几个特殊字段.
                try:
                    # 7天内不频繁更新image(由于image常常为cdn分发，故可能每次访问url都不同).
                    if video_info.image != u"" and "image" in v_data_in_db \
                            and v_data_in_db["image"] != u"" and v_data_in_db["image"] is not None:
                        datetime_now = datetime.datetime.now()
                        last_modify = v_data_in_db.get("lastModified", datetime_now)
                        interval = (datetime_now - last_modify).days
                        if interval < 7:
                            video_info.image = v_data_in_db["image"]
                finally:
                    pass
                # 专辑页数据更新到数据库中.
                sql_insert = VideoInfoSqlGenerator.sql_insert(video_info)
                print sql_insert
                Global.DbOperator_VideoBasic.update(sql_insert)
                # 在本地log中写入insert语句.
                PageSpiderStatistics.write_insert_sql_stat(sql_insert)
            pass
        elif video_info.page_type == PageType.EPISODE_PAGE:  # 写入所有抽取到的分集页信息.
            # 如果发现idc不存在.
            if video_info.idc not in PageSpider.EpisodeAllMd5:
                # 对比下哪些字段发生了变化，并记录下change log.
                sql_query = VideoInfoSqlGenerator.sql_query_by_url(video_info.website, video_info.page_type, video_info.url)
                v_data_in_db = Global.DbOperator_VideoBasic.query(sql_query)
                if len(v_data_in_db) > 0:
                    change_stat = VideoInfoPipeline.calculate_video_changes(video_info, v_data_in_db[0])
                    if len(change_stat) > 0:
                        # 将发生变化的字段登记到stat_chagne_log表中.
                        VideoInfoPipeline.write_change_log_to_db(video_info.url, video_info.page_type, change_stat)
                # 分集页数据更新到数据库中.
                sql_insert = VideoInfoSqlGenerator.sql_insert(video_info)
                print sql_insert
                Global.DbOperator_VideoBasic.update(sql_insert)
                # 在本地log中写入insert语句.
                PageSpiderStatistics.write_insert_sql_stat(sql_insert)
        else:
            log.msg(u"未预期的page_type: %s; stack: %s" % (video_info.page_type, traceback.format_stack()),
                    level=log.ERROR)
        pass

    @staticmethod
    def write_change_log_to_db(url, page_type, change_stat):
        """当某个视频信息与数据库中的视频信息对比发生变化时，
        将变化了的字段的信息写入数据库VideoStat的stat_v_change_log中.

        @param url: 当前视频信息的url.
        @param page_type: 当前视频信息的页面类型.
        @param change_stat: 发生变化的字段的统计信息.
        """
        sql = ""
        try:
            row = {"url": url,
                   "page_type": page_type,
                   "website": SpiderConfig.get_website(),
                   "change_stat": change_stat,
                   "start_time": Global.ProgramStartTimeStr,
                   "ip": Global.ip}
            sql = PageSpiderSqlGenerator.sql_insert_to_change_log(row)
            print sql
            Global.DbOperator_VideoSpider.update(sql)
        except Exception, err:
            log.msg(u"%s; SQL = %s" % (err.message, sql), level=log.ERROR)

    @staticmethod
    def calculate_video_changes(video_new, v_data_from_db):
        """计算和统计video_new中的字段和v_data_from_db中的字段对比，哪些字段发生了变化.

        @param video_new: 新抽取出的VIdeoInfo对象.
        @param v_data_from_db: 从数据库中查询出的与video_new为同一个视频的数据库记录.
        @return: 返回发生了变化的字段的统计信息(字典).
        """
        datetime_now = datetime.datetime.now()
        v_new_dict = video_new.dict()
        change_stat = {}
        for field in v_new_dict.keys():
            if field not in v_data_from_db:
                continue
            if v_new_dict["page_type"] == PageType.ALBUM_PAGE:
                if field in ["website", "valid"]:
                    continue
            elif v_new_dict["page_type"] == PageType.EPISODE_PAGE:
                if field in ["isValidURL"]:
                    continue

            if field in ["actor", "director", "screenwriter", "guests", "type"]:  # 例如:actor里的演员顺序不一样的处理.
                data_new = v_new_dict[field].split(u"   ")
                if v_data_from_db[field] is None:
                    data_old = u""
                else:
                    data_old = (u"%s" % v_data_from_db[field]).split(u"   ")
                flag = False
                for data in data_new:
                    if data not in data_old:
                        flag = True
                        break
                if not flag:
                    for data in data_old:
                        if data not in data_new:
                            flag = True
                            break
                if flag:
                    change_stat[field] = {"old": v_data_from_db[field], "new": v_new_dict[field]}
            elif field == "image":
                # 7天内不频繁更新image(由于image常常为cdn分发，故可能每次访问url都不同).
                if v_new_dict[field] != u"" and v_data_from_db[field] != u"" and v_data_from_db[field] is not None:
                    last_modify = v_data_from_db.get("lastModified", datetime_now)
                    interval = (datetime_now - last_modify).days
                    if interval >= 7 and (u"%s" % v_new_dict[field]) != (u"%s" % v_data_from_db[field]):
                            change_stat[field] = {"old": v_data_from_db[field], "new": v_new_dict[field]}
                else:
                    if (u"%s" % v_new_dict[field]) != (u"%s" % v_data_from_db[field]):
                        change_stat[field] = {"old": v_data_from_db[field], "new": v_new_dict[field]}
            elif field == "drama":
                if v_new_dict[field] == u"" and v_data_from_db[field] != u"":
                    last_modify = v_data_from_db.get("lastModified", datetime_now)
                    interval = (datetime_now - last_modify).days
                    if interval >= 7:
                        change_stat[field] = {"old": v_data_from_db[field], "new": v_new_dict[field]}
                else:
                    if (u"%s" % v_new_dict[field]) != (u"%s" % v_data_from_db[field]):
                        change_stat[field] = {"old": v_data_from_db[field], "new": v_new_dict[field]}
            elif field == "idc":
                continue
            elif (u"%s" % v_new_dict[field]) != (u"%s" % v_data_from_db[field]):
                change_stat[field] = {"old": v_data_from_db[field], "new": v_new_dict[field]}
        return change_stat

    @staticmethod
    def makeup_data_when_find_change(video_info, change_stat):
        """当发现视频信息与数据库中对比发生了变化时，对video_info中的视频信息字段进行补充.

        之所以有这个函数，是因为：
            专辑页中的视频信息是与分集页进行了数据互补之后得到的最终结果，也就是说，专辑页可能信息不全，需要分集页的信息进行补充;
            但是，在增量爬虫中，如果某一个专辑页的所有分集页都已经被爬取过，那么当这个专辑页的页面被获取到并抽取之后，
            其数据是不全的，并且没有分集页可能与它进行信息互补，这样导致的结果就是专辑页的字段会缺失信息，
            而缺失信息的专辑页与数据库中已存在的数据对比变化时，会出现某一个字段一会儿有值，一会儿又没有值的情况.
            例如：某专辑页中抽取不到导演，但是分集页中有导演，这是信息互补后专辑页就会有导演字段，但是在增量爬取时，
                 如果分集页全爬过了，这是专辑页又被爬到并抽取后，是没有导演字段的，这是专辑页的导演信息会被置空，
                 等该剧集又更新了一集时，信息互补又会让导演字段有值，如此反复就会出现stat_v_change_log表中当前
                 剧集的专辑页的导演字段一会儿有一会儿没有，不停的变化，影响统计的准确性.
        所以，在专辑页写入数据库前，从数据库中尝试取两条分集页信息与该专辑页进行互补，以规避上述的情况.

        @param video_info: 需要被补充的视频信息(一般为专辑页信息).
        @param change_stat: 发生了变化的字段的统计信息.当补充完后，change_stat中的信息也会被更新.
        """
        #try:
        #    if len(change_stat) == 0:
        #        return
        #    sql = VideoInfoSqlGenerator.sql_query_top_2_episode_by_album(video_info.website, video_info.url)
        #    result = Global.DbOperator_VideoBasic.query(sql)
        #    if len(result) == 0:
        #        return
        #    for key in change_stat.keys():
        #        item = change_stat[key]
        #        if (item["old"] != u"" and item["new"] == u"") or (item["old"] != 0 and item["new"] == 0):
        #            for r in result:
        #                if key not in r:
        #                    continue
        #                if r[key] != u"" and r[key] != 0:
        #                    video_info.dict()[key] = r[key]
        #                    change_stat.pop(key)
        #                    break
        #except Exception, err:
        #    log.msg(err, level=log.ERROR)
        #    log.msg(traceback.format_exc(), level=log.ERROR)
        pass