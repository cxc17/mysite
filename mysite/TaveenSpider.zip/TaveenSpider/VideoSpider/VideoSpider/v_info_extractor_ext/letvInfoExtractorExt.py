#coding:utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.11.21"

from ..util.VideoInfoUtil import VideoInfoUtil
from TaveenUtil.Constants import PageType

import re


class letvInfoExtractorExt(object):

    yuanxian_url_pattern = re.compile(ur"http://yuanxian\.letv\.com/detail/(\d+)\.html")

    @staticmethod
    def on_extractor_finished(video_info_list, url, body, meta, **kwargs):
        assert isinstance(video_info_list, list)
        # ----------------------------------------------------------------------
        # 处理乐视网电影的播放页无法直接指向专辑页的问题，而是指向了一个中间页面，该页面被访问时会跳转到真正的专辑页.
        # ----------------------------------------------------------------------
        if len(video_info_list) > 0 and video_info_list[0].category == u"电影":
            album_id = video_info_list[0].album_id
            matcher = letvInfoExtractorExt.yuanxian_url_pattern.search(album_id)
            if matcher:
                video_info_list[0].album_id = u"http://www.letv.com/movie/%s.html" % matcher.group(1)
        return video_info_list