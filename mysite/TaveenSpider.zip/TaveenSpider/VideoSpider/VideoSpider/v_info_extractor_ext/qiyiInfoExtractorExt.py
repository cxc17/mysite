#coding:utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.11.02"

from ..util.VideoInfoUtil import VideoInfoUtil
from TaveenUtil.Constants import PageType

import re


class qiyiInfoExtractorExt(object):

    @staticmethod
    def on_extractor_finished(video_info_list, url, body, meta, **kwargs):
        assert isinstance(video_info_list, list)
        # ----------------------------------------------------------------------
        # 处理爱奇艺非电影的分集经过模板后解析出两套VideoInfo的情况(其中有一套为无用的VideoInfo，要摒弃).
        # ----------------------------------------------------------------------
        if len(video_info_list) == 2:
            category = VideoInfoUtil.category_ch_to_en(video_info_list[0].category)
            if category == u"movie":
                pass
            else:
                for v in video_info_list:
                    if v.page_type == PageType.ALBUM_PAGE and v.url == v.album_id:
                        video_info_list.remove(v)
                        break
        # ----------------------------------------------------------------------
        # 处理抽取到的title中包含杂乱数据的情况，如“爸爸去哪儿第二季-综艺频道-爱奇艺2014年全网独播-爱奇艺”
        # ----------------------------------------------------------------------
        for v in video_info_list:
            v.title = qiyiInfoExtractorExt.clean_title(v.title)
            v.othername = qiyiInfoExtractorExt.clean_title(v.othername)
            v.video_name = (u"%s   %s" % (v.title, v.othername)).strip()
        return video_info_list

    @staticmethod
    def clean_title(title):
        title = re.sub(ur"-爱奇艺\d+年全网独播", u"", title)
        title = re.sub(ur"-(?:综艺|动漫|电视剧|电影)频道", u"", title)
        title = re.sub(ur"-(?:高清)*视频在线观看", u"", title)
        title = re.sub(ur"-爱奇艺", u"", title)
        return title