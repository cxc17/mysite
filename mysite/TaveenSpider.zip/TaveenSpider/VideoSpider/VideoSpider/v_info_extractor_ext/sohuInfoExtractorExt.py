#encoding:utf-8

import re

class sohuInfoExtractorExt(object):

    @staticmethod
    def on_extractor_finished(video_info_list, url, body, meta, **kwargs):
        assert isinstance(video_info_list, list)
        print str(meta["video_url"]) + "--------------"
        for v in video_info_list:
            #for key in v.__dict__.keys():
            #    if key == "othername":
            #        for kk in v.__dict__.keys():
            #            print str(kk) + "+++===+++" + str(v.__dict__[kk])
            if v.category == ur"电视剧" or v.category == ur"综艺":
                matcher = re.compile("http://tv.sohu.com/item/(.+)\.html").search(v.album_id)
                if not matcher:
                    v.album_id = meta["video_url"]
        return video_info_list
