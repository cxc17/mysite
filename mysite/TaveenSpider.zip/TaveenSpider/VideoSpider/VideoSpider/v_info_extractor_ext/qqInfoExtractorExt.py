#coding:utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.11.26"

from ..util.VideoInfoUtil import VideoInfoUtil
from TaveenUtil.Constants import PageType
from scrapy.spider import log

import re


class qqInfoExtractorExt(object):

    @staticmethod
    def on_extractor_finished(video_info_list, url, body, meta, **kwargs):
        assert isinstance(video_info_list, list)
        # ----------------------------------------------------------------------
        #
        # ----------------------------------------------------------------------
        for v in video_info_list:
            # 给链接加host前缀.
            if not v.url.startswith(u"http://"):
                v.url = u"http://v.qq.com%s" % v.url
            if not v.album_id.startswith(u"http://"):
                v.album_id = u"http://v.qq.com%s" % v.album_id
            v.url = v.url.replace(u"film.qq.com", u"v.qq.com")
            v.album_id = v.album_id.replace(u"film.qq.com", u"v.qq.com")

            # 处理演员和导演中无名字、只有0的情况.
            if v.actor == u"0":
                v.actor = u""
            if v.director == u"0":
                v.director = u""

            if v.page_type == PageType.EPISODE_PAGE:
                # 补充第一集抽取不到集数的问题.
                if v.no == 0:
                    v.no = 1
                # 取出title中的集数信息(因为腾讯视频的分集页都是第1集，然后才动态改变集数).
                v.title = re.sub(ur"第\d+集", u"", v.title).strip()
            if v.page_type == PageType.ALBUM_PAGE:
                if v.title.replace(u"高清在线观看", u"").replace(u"腾讯视频", u"").replace(u"-", u"").strip() == u"":
                    log.msg(u"%s 的title字段异常，可能存在改版问题！" % v.url, level=log.ERROR)
                    video_info_list.remove(v)
                    continue
                # 对于先进入某一个页面，然后在跳转到另一个页面的专辑页链接进行处理(注意不是302那种跳转).
                if meta.get("raw_album_url", None) is not None:
                    v.url = meta["raw_album_url"]
                # 取出title和othername中的无用信息，如果有书名号，则认为书名号以为的字符串为无用信息.
                matcher = re.compile(ur"《(.+?)》").search(v.title)
                if matcher:
                    v.title = matcher.group(1)
                matcher = re.compile(ur"《(.+?)》").search(v.othername)
                if matcher:
                    v.othername = matcher.group(1)
                v.video_name = (u"%s   %s" % (v.title, v.othername)).strip()
                # 处理image以style属性的形式展示图片的情况.
                matcher = re.compile(ur"url\((http://.+)\)").search(v.image)
                if matcher:
                    v.image = matcher.group(1)
        return video_info_list