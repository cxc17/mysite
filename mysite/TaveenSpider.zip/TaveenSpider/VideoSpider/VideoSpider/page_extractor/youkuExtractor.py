#coding:utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.09.10"

from scrapy.selector import Selector
from scrapy.http import Response
from scrapy.spider import log
import json
import re

from ..page_extractor.PageExtractorBase import PageExtractorBase
from ..util.VideoInfoUtil import VideoInfoUtil
from TaveenUtil.Constants import *


class youkuExtractor(PageExtractorBase):
    """youku网站的页面爬虫抽取新链接的类.

    该类主要实现从给定的页面中抽取出新的链接，这些新的链接会被放入爬取队列中进行爬取.

    youku页面抽取的逻辑大致为：
        1. 如果当前是专辑页，那么从专辑页中抽取参数拼接出包含所有分集页链接的中间json/xml页链接，
           然后请求到的json/xml页(一个或多个json/xml页)中包含分集页列表；
        2. 有的专辑页找不到1中所述的拼接json页链接所需的参数，那么这时的剧集一般分集数较少，故直接从专辑页中抽取分集页列表；
        3. 如果是专辑页链接，还需要从页面中抽取出演员/导演页面，以便进行爬全模式.
        4. 如果当前是分集页，则抽取专辑页链接；对于部分页面(如电视剧频道)抽取不到专辑页链接，
           则这时试图从response.meta中寻找专辑页链接进行补充；
        5. 如果是演员/导演页面，则需要拼接参数生成包含 该演员/导演参与过的所有剧集 的json/xml页面的链接，
           该json/xml链接中可抽取到该演员/导演的全部作品.
    """

    album_url_pattern = re.compile(ur"http://www.youku.com/show_page/id_(.+)\.html")
    episode_url_pattern = re.compile(ur"http://v.youku.com/v_show/id_(.+)\.html")
    episode_medium_url_pattern = re.compile(ur"http://www.youku.com/show_episode/id_(.+)\.html\?"
                                            ur"dt=json&divid=reload_(\d+)&__rt=1&__ro=reload_(\d+)")
    actor_url_pattern = re.compile(ur"http://www.youku.com/star_page/uid_(.+)(?:\.html)*")
    actor_production_url_pattern = re.compile(ur"http://www.youku.com/star/~ajax/downloadJsonOpus.html"
                                              ur"\?.*&uid=(.+?)&u=(.+?)&.*")
    soku_url_pattern = re.compile(ur"http://www.soku.com/.+")

    @staticmethod
    def extract(response, display_stamp=""):
        """重写基类的 实现页面新链接抽取的函数.

        @param response: 当前页面的response对象.
        @param display_stamp: 用于显示的标记.
        @return: 返回包含新链接及其附加信息的列表.
        """
        if not isinstance(response, Response):
            raise ValueError(u"Parameter \"response\" must be type<scrapy.http.Response>!")

        new_requests = list()
        if youkuExtractor.album_url_pattern.search(response.url):
            new_requests = youkuExtractor.process_album_page(response, display_stamp)
        elif youkuExtractor.episode_url_pattern.search(response.url):
            new_requests = youkuExtractor.process_episode_page(response, display_stamp)
        elif youkuExtractor.episode_medium_url_pattern.search(response.url):
            new_requests = youkuExtractor.process_episode_medium_page(response, display_stamp)
        elif youkuExtractor.actor_url_pattern.search(response.url):
            new_requests = youkuExtractor.process_actor_page(response, display_stamp)
        elif youkuExtractor.actor_production_url_pattern.search(response.url):
            new_requests = youkuExtractor.process_actor_production_page(response, display_stamp)
        elif youkuExtractor.soku_url_pattern.search(response.url):
            pass
        else:
            log.msg(u"%s 不满足目前代码中支持的任何一种链接格式，请查看原因!" % response.url, level=log.WARNING)
        return new_requests

    @staticmethod
    def process_album_page(response, display_stamp=""):
        """处理专辑页的函数(参数明细参照extract函数)."""
        new_requests = list()
        # 下面是所有的xpath表达式，集中写在最前面方便以后修改.
        # (这样只要不是非常大的改版，就不用每次修改都深入到下面的代码中寻找需要修改的地方了).
        # category的xpath.
        category_xpath = u"//div[@id='title']//h1[@class='title']//span[@class='type']//a/text()"
        # 从专辑页抽取中间json页面链接的xpath.
        ep_json_param_xpath = u"//ul[@id='zySeriesTab']//li/@data"
        # 从专辑页直接抽取分集页链接的xpath.
        ep_from_album_xpath = u"//div[@id='episode']//ul//li"
        # 从专辑页抽取中间json页面的链接字符串.
        ep_json_url_str = u"http://www.youku.com/show_episode/id_[#VID#].html?dt=json&divid=[#EP_PARAM#]" \
                          u"&__rt=1&__ro=[#EP_PARAM#]"
        # 电影专辑页抽取分集页链接的xpath.包括：播放，免费试看，排除“搜库”和播放“预告片”。
        movie_ep_url_xpath = u"//div[@id='showInfo']//a[@class='btnShow btnplayposi' " \
                             u"or @class='btnShow btnfreesee']/@href"

        matcher = youkuExtractor.album_url_pattern.search(response.url)
        if matcher:
            vid = matcher.group(1)
        else:
            raise ValueError(u"提取vid失败! url = %s" % response.url)
        selector = Selector(response)
        category_str = u"".join(selector.xpath(category_xpath).extract())
        # 1.从专辑页中抽取分集页或者抽取包含分集页列表的json/xml页面.
        if u"电视剧" in category_str or u"综艺" in category_str or u"动漫" in category_str:
            # Added by chjchen on 2015.04.21
            # 这里添加的是一段注释，没有添加代码
            # 下面这段for循环应该是这样一种专辑页面
            # 这种专辑页面的分集有很多，一次性没有办法加载完毕，然后需要通过json来进行分页展示
            # 然后这个for循环就是找出这样的json来寻找所有的分集
            # 如果没有这个json的，就说明分集可以一次性展示完毕
            for param in selector.xpath(ep_json_param_xpath).extract():  # 遍历所有xml链接的参数，生成xml页面链接.
                request_url = ep_json_url_str.replace("[#VID#]", vid).replace("[#EP_PARAM#]", param)
                meta = {"category": VideoInfoUtil.category_ch_to_en(category_str),
                        "page_type": PageType.EPISODE_MEDIUM_PAGE,
                        "album_id": response.url}
                new_requests.append({"request_url": request_url, "meta": meta})
            # End of Add on 2015.04.21
            if len(new_requests) == 0:  # 如果没有抽取到xml页面链接，则从专辑页中直接抽取分集页链接.
                nodes = selector.xpath(ep_from_album_xpath)
                for index in xrange(0, len(nodes)):
                    request_url = u""
                    if u"综艺" in category_str:
                        urls = nodes[index].xpath(u"./a/@href").extract()
                        if len(urls) > 0:
                            request_url = u"".join(urls[0])
                    else:
                        request_url = u"".join(nodes[index].xpath(u"./a/@href").extract())
                    if request_url == u"":
                        continue
                    matcher = youkuExtractor.episode_url_pattern.search(request_url)
                    if matcher:  # 用正则匹配以确保抽取到的是分集页链接.
                        request_url = matcher.group()
                    else:
                        if request_url != u"":
                            log.msg(u"抽取出的链接『%s』不符合现在已知的分集页链接格式，请检查原因! from = %s"
                                    % (request_url, response.url), level=log.WARNING)
                    # 为分集页链接抽取no字段.
                    no = VideoInfoUtil.format_no(u"".join(nodes[index].xpath(u"./a/text()").extract()), False)
                    if no is None or no <= 0:
                        #log.msg(u"没有从中间页面中提取到no字段，现在试图用列表顺序作为可能的集数: %s; from = %s"
                        #        % (index + 1, response.url), level=log.INFO)
                        no = index + 1
                    meta = {"category": response.meta["category"],
                            "page_type": PageType.EPISODE_PAGE,
                            "no": no,
                            "album_id": youkuExtractor.clean_url(response.url)}
                    new_requests.append({"request_url": request_url, "meta": meta})
        elif u"电影" in category_str:  # 电影页面和其他类别的页面抽取分集的位置不一样.
            request_url = u"".join(selector.xpath(movie_ep_url_xpath).extract()).strip()
            if request_url != u"":
                meta = {"category": VideoInfoUtil.category_ch_to_en(category_str),
                        "page_type": PageType.EPISODE_PAGE,
                        "album_id": youkuExtractor.clean_url(response.url)}
                new_requests.append({"request_url": request_url, "meta": meta})
        else:
            log.msg(u"提取不到category! from =%s" % response.url, level=log.ERROR)

        # 2.从专辑页中抽取演员/页面.
        if youkuExtractor.is_extract_actor_page:
            actor_url_xpath_1 = u"//div[@id='showInfo']//ul[@class='baseinfo']//span[@class='actor' " \
                                u"or @class='director' or @class='host']//a/@href"
            actor_url_xpath_2 = u"//div[@id='cast']//div[@id='uFollow']//div[@class='users']//ul//" \
                                u"li[@class='username']//a/@href"
            urls = selector.xpath(actor_url_xpath_1).extract()
            if len(urls) == 0:
                urls = selector.xpath(actor_url_xpath_2).extract()
            for url in urls:
                matcher = youkuExtractor.actor_url_pattern.search(url)
                if matcher:
                    request_url = matcher.group()
                    meta = {"category": "",
                            "page_type": PageType.ACTOR_PAGE}
                    new_requests.append({"request_url": youkuExtractor.clean_url(request_url), "meta": meta})
                else:
                    if request_url != u"":
                        log.msg(u"抽取出的链接『%s』不符合现在已知的演员/导演页链接格式，请检查原因! from = %s"
                                % (request_url, response.url), level=log.WARNING)

        return new_requests

    @staticmethod
    def process_episode_page(response, display_stamp=""):
        """处理分集页的函数(参数明细参照extract函数)."""
        ep_url_xpath = u"//div[@id='vpofficialtitlev5']//h1[@class='title']//a/@href"
        selector = Selector(response)
        request_url = u"".join(selector.xpath(ep_url_xpath).extract()).strip()

        # 如果抽取到的专辑页链接为空，那么就从response.meta中尝试寻找专辑页链接.
        if request_url == u"":
            album_url = response.meta.get("album_id", u"")
            if album_url != u"":
                request_url = album_url

        # 判断抽取到的链接是否符合预期的正则表达式，这样做的目的是为了:当出现新的未预期的链接格式时能及时发现.
        matcher = youkuExtractor.album_url_pattern.search(request_url)
        if matcher:
            request_url = matcher.group()
        else:
            if request_url != u"":
                log.msg(u"抽取出的链接『%s』不符合现在已知的专辑页链接格式，请检查原因! from = %s"
                        % (request_url, response.url), level=log.WARNING)

        meta = {"category": response.meta["category"],
                "page_type": PageType.ALBUM_PAGE}

        # Added by chjchen on 2015.04.21
        # 这段代码修复了优酷电视剧之前在抓取过程中，连预告片也放入到数据库中的问题
        # 如果发现这个分集是一个预告片，片花之类的，那么就直接不会return 这个分集的item，达到了非正式数据补入库的目的
        youku_tv_subtitle_xpath = u"//div[@class='base_info']/h1[@class='title']/span[@id='subtitle']/text()"
        youku_tv_subtitle_res = selector.xpath(youku_tv_subtitle_xpath).extract()
        rubbish_res = VideoInfoUtil.is_rubbish(youku_tv_subtitle_res[0])
        if not rubbish_res:
            return [{"request_url": request_url, "meta": meta}]
        # End of Add on 2015.04.21

    @staticmethod
    def process_episode_medium_page(response, display_stamp=""):
        """处理专辑页到分集页的中间页面的函数(参数明细参照extract函数)."""
        new_requests = list()
        ep_url_xpath = u"//ul//li"
        ep_url_variety_xpath = u"//ul//li[@class='ititle' or @class='ititle_w']"
        selector = Selector(response)
        category = response.meta["category"]
        nodes = selector.xpath(category == u"variety" and ep_url_variety_xpath or ep_url_xpath)
        for index in xrange(0, len(nodes)):
            request_url = u"".join(nodes[index].xpath(u"./a/@href").extract()).strip()
            if request_url == u"":
                continue
            if category == u"variety":
                no = VideoInfoUtil.format_curEpisode(u"".join(nodes[index].xpath(u".//text()").extract()), category)
            else:
                no = VideoInfoUtil.format_curEpisode(u"".join(nodes[index].xpath(u"./a//text()").extract()), category)
            # P.S.综艺不采用列表顺序来补充集数(因为其格式是年月日).
            if (no is None or no <= 0) and u"variety" not in category:
                matcher = youkuExtractor.episode_medium_url_pattern.search(response.url)
                if matcher:
                    #log.msg(u"没有从中间页面中提取到no字段，现在试图用列表顺序作为可能的集数: %s; from = %s"
                    #        % (index + int(matcher.group(2)), response.url), level=log.INFO)
                    no = index + int(matcher.group(2))
            matcher = youkuExtractor.episode_url_pattern.search(request_url)
            if matcher:
                request_url = matcher.group()
            else:
                if request_url != u"":
                    log.msg(u"抽取出的链接『%s』的分集页链接格式，请检查原因! from = %s"
                            % (request_url, response.url), level=log.WARNING)
            meta = {"category": category,
                    "page_type": PageType.EPISODE_PAGE,
                    "no": no,
                    "album_id": response.meta.get("album_id", "")}
            new_requests.append({"request_url": request_url, "meta": meta})

        return new_requests

    @staticmethod
    def process_actor_page(response, display_stamp=""):
        """处理演员/导演页面的函数(参数明细参照extract函数)."""
        new_requests = list()
        actor_name_xpath = u"//span[@class='star_name']/text()"
        actor_production_url_str = u"http://www.youku.com/star/~ajax/downloadJsonOpus.html?__rt=1&__ro=" \
                                   u"&uid=[#UID#]==&u=[#ACTOR_NAME#]&t=all&q=0&init=1"
        selector = Selector(response)
        # get uid.
        matcher = youkuExtractor.actor_url_pattern.search(response.url)
        if matcher:
            uid = matcher.group(1)
            actor_name = u"".join(selector.xpath(actor_name_xpath).extract())
            request_url = actor_production_url_str.replace(u"[#UID#]", uid)\
                .replace(u"[#ACTOR_NAME#]", actor_name).strip()
            meta = {"category": "", "page_type": PageType.ACTOR_MEDIUM_PAGE}
            new_requests.append({"request_url": request_url, "meta": meta})
        else:
            log.msg(u"为获取到演员/导演页面的uid! from = %s" % response.url, level=log.WARNING)
        return new_requests

    @staticmethod
    def process_actor_production_page(response, display_stamp=""):
        """处理演员/导演的作品页面的函数(参数明细参照extract函数)."""
        new_requests = list()
        if response.body.strip() == u"\"end\"":
            return new_requests
        json_obj = json.loads(response.body.strip())
        # 1.从页面中抽取出当前演员/导演的作品列表.
        items = json_obj["show"]
        if isinstance(items, dict):
            for key in items.keys():
                text = items[key]
                selector = Selector(text=u"<tbody>%s</tbody>" % text)
                nodes = selector.xpath(u"//tr")
                for node in nodes:
                    category = u"".join(node.xpath(u".//td[@class='type']//text()").extract()).strip()
                    category = VideoInfoUtil.category_ch_to_en(category)
                    if category not in CategoryNames_CH and category not in CategoryNames:
                        continue
                    request_url = u"".join(node.xpath(u".//td[@class='title']//a/@href").extract())
                    matcher = youkuExtractor.album_url_pattern.search(request_url)
                    if matcher:  # 目前只从抽取链接为专辑页链接的作品，为的是防止其他category(如电影频道的预告片)混入.
                        request_url = matcher.group()
                        meta = {"category": category, "page_type": PageType.ALBUM_PAGE}
                        new_requests.append({"request_url": request_url, "meta": meta})

        # 2.拼接出当前演员/导演作品页面的下一页.
        request_url_str = u"http://www.youku.com/star/~ajax/downloadJsonOpus.html?__rt=1&__ro=&uid=[#UID#]&u=" \
                          u"[#ACTOR_NAME]&t=all&q=0&ds=[#ldtShow#]&dd=[#ldtDvd#]&ps=[#pnShow#]&pd=[#pnDvd#]&init=0"
        matcher = youkuExtractor.actor_production_url_pattern.search(response.url)
        if matcher:
            uid = matcher.group(1)
            actor_name = matcher.group(2)
            ldt_show = json_obj["ldtShow"]
            ldt_dvd = json_obj["ldtDvd"]
            pn_show = json_obj["pnShow"]
            pn_dvd = json_obj["pnDvd"]
            request_url = request_url_str.replace(u"[#UID#]", uid).replace(u"[#ACTOR_NAME]", actor_name)\
                .replace(u"[#ldtShow#]", u"%s" % ldt_show).replace(u"[#ldtDvd#]", u"%s" % ldt_dvd)\
                .replace(u"[#pnShow#]", u"%s" % pn_show).replace(u"[#pnDvd#]", u"%s" % pn_dvd)
            meta = {"category": "", "page_type": PageType.ACTOR_MEDIUM_PAGE}
            new_requests.append({"request_url": request_url, "meta": meta})

        return new_requests

    @staticmethod
    def clean_url(url):
        """清理给定链接中的无用参数，得到比较规整的链接.

        @param url: 待清理的链接.
        @return: 返回清理后的链接.
        """
        matcher = youkuExtractor.album_url_pattern.search(url)
        if matcher:
            return matcher.group()
        matcher = youkuExtractor.episode_url_pattern.search(url)
        if matcher:
            return matcher.group()
        matcher = youkuExtractor.actor_url_pattern.search(url)
        if matcher:
            return matcher.group()
        return url