#coding:utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.10.22"

from scrapy.selector import Selector
from scrapy.http import Response
from scrapy.spider import log
import json
import re

from ..page_extractor.PageExtractorBase import PageExtractorBase
from ..util.VideoInfoUtil import VideoInfoUtil
from TaveenUtil.Constants import *


class xxxExtractor(PageExtractorBase):
    """xxx网站的页面爬虫抽取新链接的类.

    该类主要实现从给定的页面中抽取出新的链接，这些新的链接会被放入爬取队列中进行爬取.

    xxx页面抽取的逻辑大致为：
        1.
        2.
        3.
    """

    album_url_pattern = re.compile(ur"xxx")
    episode_url_pattern = re.compile(ur"xxx")
    episode_medium_url_pattern = re.compile(ur"xxx")
    actor_url_pattern = re.compile(ur"xxx")
    actor_production_url_pattern = re.compile(ur"xxx")

    @staticmethod
    def extract(response, display_stamp=""):
        """重写基类的 实现页面新链接抽取的函数.

        @param response: 当前页面的response对象.
        @param display_stamp: 用于显示的标记.
        @return: 返回包含新链接及其附加信息的列表.
        """
        if not isinstance(response, Response):
            raise ValueError(u"Parameter \"response\" must be type<scrapy.http.Response>!")

        new_requests = list()
        if xxxExtractor.album_url_pattern.search(response.url):
            new_requests = xxxExtractor.process_album_page(response, display_stamp)
        elif xxxExtractor.episode_url_pattern.search(response.url):
            new_requests = xxxExtractor.process_episode_page(response, display_stamp)
        elif xxxExtractor.episode_medium_url_pattern.search(response.url):
            new_requests = xxxExtractor.process_episode_medium_page(response, display_stamp)
        elif xxxExtractor.actor_url_pattern.search(response.url):
            new_requests = xxxExtractor.process_actor_page(response, display_stamp)
        elif xxxExtractor.actor_production_url_pattern.search(response.url):
            new_requests = xxxExtractor.process_actor_production_page(response, display_stamp)
        else:
            log.msg(u"%s 不满足目前代码中支持的任何一种链接格式，请查看原因!" % response.url, level=log.WARNING)
        return new_requests

    @staticmethod
    def process_album_page(response, display_stamp=""):
        new_requests = list()
        return new_requests

    @staticmethod
    def process_episode_page(response, display_stamp=""):
        """处理专辑页的函数(参数明细参照extract函数)."""
        new_requests = list()
        return new_requests

    @staticmethod
    def process_episode_medium_page(response, display_stamp=""):
        """处理分集页的函数(参数明细参照extract函数)."""
        new_requests = list()
        return new_requests

    @staticmethod
    def process_actor_page(response, display_stamp=""):
        """处理专辑页到分集页的中间页面的函数(参数明细参照extract函数)."""
        new_requests = list()
        return new_requests

    @staticmethod
    def process_actor_production_page(response, display_stamp=""):
        """处理演员/导演页面的函数(参数明细参照extract函数)."""
        new_requests = list()
        return new_requests
    
    @staticmethod
    def clean_url(url):
        """清理给定链接中的无用参数，得到比较规整的链接.

        @param url: 待清理的链接.
        @return: 返回清理后的链接.
        """
        return url