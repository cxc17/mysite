#coding:utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.10.22"

from scrapy.selector import Selector
from scrapy.http import Response
from scrapy.spider import log
import json
import re

from ..page_extractor.PageExtractorBase import PageExtractorBase
from ..util.VideoInfoUtil import VideoInfoUtil
from TaveenUtil.Constants import *


class letvExtractor(PageExtractorBase):
    """letv网站的页面爬虫抽取新链接的类.

    该类主要实现从给定的页面中抽取出新的链接，这些新的链接会被放入爬取队列中进行爬取.

    letv页面抽取的逻辑大致为：
        1.
        2.
        3.
    """

    album_url_pattern = re.compile(ur"http://www\.le\.com/(?:tv|movie|comic|zongyi)/(\d+)\.html")
    episode_url_pattern = re.compile(ur"http://www\.le\.com/ptv/vplay/(\d+)\.html")
    episode_medium_url_pattern = re.compile(ur"http://api\.letv\.com/mms/out/albumInfo/getVideoListByIdAndDate\?year=(\d+)&month=(\d+)&id=(\d+)")
    actor_url_pattern = re.compile(ur"xxx")
    actor_production_url_pattern = re.compile(ur"xxx")

    @staticmethod
    def extract(response, display_stamp=""):
        """重写基类的 实现页面新链接抽取的函数.

        @param response: 当前页面的response对象.
        @param display_stamp: 用于显示的标记.
        @return: 返回包含新链接及其附加信息的列表.
        """
        if not isinstance(response, Response):
            raise ValueError(u"Parameter \"response\" must be type<scrapy.http.Response>!")

        new_requests = list()
        if letvExtractor.album_url_pattern.search(response.url):
            new_requests = letvExtractor.process_album_page(response, display_stamp)
        elif letvExtractor.episode_url_pattern.search(response.url):
            new_requests = letvExtractor.process_episode_page(response, display_stamp)
        elif letvExtractor.episode_medium_url_pattern.search(response.url):
            new_requests = letvExtractor.process_episode_medium_page(response, display_stamp)
        elif letvExtractor.actor_url_pattern.search(response.url):
            new_requests = letvExtractor.process_actor_page(response, display_stamp)
        elif letvExtractor.actor_production_url_pattern.search(response.url):
            new_requests = letvExtractor.process_actor_production_page(response, display_stamp)
        else:
            log.msg(u"%s 不满足目前代码中支持的任何一种链接格式，请查看原因!" % response.url, level=log.WARNING)
        return new_requests

    @staticmethod
    def process_album_page(response, display_stamp=""):
        new_requests = list()

        selector = Selector(response)
        # extract category.
        category = u"".join(selector.xpath(u"//div[@class='unfurl']//h1//text()").extract())
        category = VideoInfoUtil.category_ch_to_en(category)
        if category == u"tv" or category == u"animation":
            episode_list_xpath_1 = u"//div[@class='listText']//dl//dd//p[@class='p1']//a"
            episode_list_xpath_2 = u"//div[@class='listPic active']//dl//dd//p[@class='p1']//a"
            nodes = selector.xpath(episode_list_xpath_1)
            if len(nodes) <= 0:
                nodes = selector.xpath(episode_list_xpath_2)
            for node in nodes:
                request_url = u"".join(node.xpath(u"./@href").extract()).strip()
                no = u"".join(node.xpath(u"./text()").extract()).strip()
                meta = {"category": category,
                        "no": VideoInfoUtil.format_no(no, category, False),
                        "page_type": PageType.EPISODE_PAGE,
                        "album_id": letvExtractor.clean_url(response.url)}
                new_requests.append({"request_url": letvExtractor.clean_url(request_url), "meta": meta})
        elif category == u"movie":
            episode_xpath = u"//div[@class='showPic']//a/@href"
            request_url = u"".join(selector.xpath(episode_xpath).extract()).strip()
            meta = {"category": category,
                    "page_type": PageType.EPISODE_PAGE,
                    "album_id": letvExtractor.clean_url(response.url)}
            new_requests.append({"request_url": letvExtractor.clean_url(request_url), "meta": meta})
        elif category == u"variety":
            v_id = letvExtractor.album_url_pattern.search(response.url).group(1)
            year_month_xpath = u"//div[@class='gut']//div[@class='listPic active']//div[contains(@class, 'month')]//a"
            nodes = selector.xpath(year_month_xpath)
            for node in nodes:
                year = u"".join(node.xpath(u"./@list-year").extract()).strip()
                month = u"".join(node.xpath(u"./@list-month").extract()).strip()
                request_url = u"http://api.letv.com/mms/out/albumInfo/getVideoListByIdAndDate?year=%s&month=%s&id=%s" \
                              % (year, month, v_id)
                meta = {"category": category,
                        "page_type": PageType.EPISODE_MEDIUM_PAGE,
                        "album_id": letvExtractor.clean_url(response.url)}
                new_requests.append({"request_url": request_url, "meta": meta})
        else:
            log.msg(u"未抽取到有效的category: from = %s" % response.url, level=log.ERROR)

        return new_requests

    @staticmethod
    def process_episode_page(response, display_stamp=""):
        """处理专辑页的函数(参数明细参照extract函数)."""
        new_requests = list()

        selector = Selector(response)
        # extract category.
        category = response.meta.get("category", u"")
        if category == u"":
            category = u"".join(selector.xpath(u"//div[@class='crumbs']/a/text()").extract()).strip()
            category = VideoInfoUtil.category_ch_to_en(category)
        # extract album url.
        album_url = u"".join(selector.xpath(u"//div[@class='Info j-exposure-stat']//li[last()]/em/a/@href").extract())
        if album_url == u"":
            album_url_xpath = u"//div[@class='Detail']//ul[@class='intro_box']" \
                              u"//li[last()]//a[contains(text(), '更多详情')]/@href"
            album_url = u"".join(selector.xpath(album_url_xpath).extract())
        album_url = letvExtractor.clean_url(album_url)
        meta = {"category": category,
                "page_type": PageType.ALBUM_PAGE}
        new_requests.append({"request_url": album_url, "meta": meta})

        return new_requests

    @staticmethod
    def process_episode_medium_page(response, display_stamp=""):
        """处理分集页的函数(参数明细参照extract函数)."""
        new_requests = list()

        resp_data = json.loads(response.body)
        category = response.meta["category"]
        if category == u"variety":
            for year_item_key in resp_data["data"].keys():
                if resp_data["data"][year_item_key] is None:
                    continue
                for month_item_key in resp_data["data"][year_item_key].keys():
                    if resp_data["data"][year_item_key][month_item_key] is None:
                        continue
                    items = resp_data["data"][year_item_key][month_item_key]
                    for item in items:
                        request_url = u"http://www.letv.com/ptv/vplay/%s.html" % item["id"]
                        meta = {"category": category,
                                "no": VideoInfoUtil.format_no(item["issue"], category, False),
                                "page_type": PageType.EPISODE_PAGE,
                                "album_id": letvExtractor.clean_url(response.meta["album_id"])}
                        new_requests.append({"request_url": request_url, "meta": meta})
        return new_requests

    @staticmethod
    def process_actor_page(response, display_stamp=""):
        """处理专辑页到分集页的中间页面的函数(参数明细参照extract函数)."""
        new_requests = list()
        return new_requests

    @staticmethod
    def process_actor_production_page(response, display_stamp=""):
        """处理演员/导演页面的函数(参数明细参照extract函数)."""
        new_requests = list()
        return new_requests
    
    @staticmethod
    def clean_url(url):
        """清理给定链接中的无用参数，得到比较规整的链接.

        @param url: 待清理的链接.
        @return: 返回清理后的链接.
        """
        matcher = letvExtractor.album_url_pattern.search(url)
        if matcher:
            return matcher.group()
        matcher = letvExtractor.episode_url_pattern.search(url)
        if matcher:
            return matcher.group()
        matcher = letvExtractor.actor_url_pattern.search(url)
        if matcher:
            return matcher.group()
        return url