#coding:utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.10.30"

from scrapy.selector import Selector
from scrapy.http import Response
from scrapy.spider import log
import json
import re
import urllib
import random

from ..page_extractor.PageExtractorBase import PageExtractorBase
from ..util.VideoInfoUtil import VideoInfoUtil
from TaveenUtil.Constants import *


class qiyiExtractor(PageExtractorBase):
    """爱奇艺网站的页面爬虫抽取新链接的类.

    该类主要实现从给定的页面中抽取出新的链接，这些新的链接会被放入爬取队列中进行爬取.

    爱奇艺页面抽取的逻辑大致为：
        1.
        2.
        3.
    """

    album_url_pattern_1 = re.compile(ur"http://www\.iqiyi\.com/(?:dianshiju|zongyi|dongman)/[^/]+?\.html")
    album_url_pattern_2 = re.compile(ur"http://www\.iqiyi\.com/(a_.+?)\.html")
    episode_url_pattern_1 = re.compile(ur"http://www\.iqiyi\.com/(v_.+?)\.html")
    episode_url_pattern_2 = re.compile(ur"http://www\.iqiyi\.com/(?:dianshiju|zongyi|dongman|dianying)/.+?/.+?\.html")
    episode_medium_url_pattern_1 = re.compile(ur"http://cache\.video\.qiyi\.com/jp/avlist/(\d+?)/(\d+?)/50/\?"
                                              ur"albumId=(\d+?)&pageNum=50&pageNo=(\d+?)")
    episode_medium_url_pattern_2 = re.compile(ur"http://cache\.video\.qiyi\.com/jp/sdvlst/6/(\d+)/(\d+)/\?"
                                              ur"categoryId=6&sourceId=(\d+)&tvYear=(\d+)")
    episode_medium_url_pattern_3 = re.compile(ur"http://cache\.video\.qiyi\.com/jp/sdlst/6/(\d+)/")
    #episode_medium_url_pattern_3 = re.compile(ur"http://search\.video\.iqiyi\.com/searchDateAlbum/\?source=.+")
    actor_url_pattern = re.compile(ur"http://www\.iqiyi\.com/lib/(s_.+?)\.html")
    actor_production_url_pattern = re.compile(ur"xxx")

    rubbish_url_pattern = re.compile(ur"http://www\.iqiyi\.com/(?:dianshiju|zongyi|dongman|dianying)/$")

    @staticmethod
    def extract(response, display_stamp=""):
        """重写基类的 实现页面新链接抽取的函数.

        @param response: 当前页面的response对象.
        @param display_stamp: 用于显示的标记.
        @return: 返回包含新链接及其附加信息的列表.
        """
        if not isinstance(response, Response):
            raise ValueError(u"Parameter \"response\" must be type<scrapy.http.Response>!")

        new_requests = list()
        if qiyiExtractor.album_url_pattern_1.search(response.url) \
                or qiyiExtractor.album_url_pattern_2.search(response.url):
            new_requests = qiyiExtractor.process_album_page(response, display_stamp)
        elif qiyiExtractor.episode_url_pattern_1.search(response.url) \
                or qiyiExtractor.episode_url_pattern_2.search(response.url):
            new_requests = qiyiExtractor.process_episode_page(response, display_stamp)
        elif qiyiExtractor.episode_medium_url_pattern_1.search(response.url) \
                or qiyiExtractor.episode_medium_url_pattern_2.search(response.url) \
                or qiyiExtractor.episode_medium_url_pattern_3.search(response.url):
            new_requests = qiyiExtractor.process_episode_medium_page(response, display_stamp)
        elif qiyiExtractor.actor_url_pattern.search(response.url):
            new_requests = qiyiExtractor.process_actor_page(response, display_stamp)
        elif qiyiExtractor.actor_production_url_pattern.search(response.url):
            new_requests = qiyiExtractor.process_actor_production_page(response, display_stamp)
        elif qiyiExtractor.rubbish_url_pattern.search(response.url):
            print u"rubbish url: %s" % response.url
            pass
        else:
            log.msg(u"%s 不满足目前代码中支持的任何一种链接格式，请查看原因!" % response.url, level=log.WARNING)
        return new_requests

    @staticmethod
    def process_album_page(response, display_stamp=""):
        """处理专辑页的函数(参数明细参照extract函数)."""
        new_requests = list()

        category_xpath = u"//div[@class='crumb-item']//text()"
        page_nos_xpath = u"//div[@id='block-H']//a[@data-delegate='albumlist-page']//@data-avlist-page"
        ep_url_in_album_xpath = u"//div[@data-tab-body='widget-tab-3']//div[@data-widget='albumlist-render']" \
                                u"//ul[@data-albumlist-elem='cont']//li//a"
        album_id_pattern = re.compile(ur"albumId *: *(.+?),")
        ep_medium_url_str = u"http://cache.video.qiyi.com/jp/avlist/[#ALBUMID#]/[#PAGENO#]/50/" \
                            u"?albumId=[#ALBUMID#]&pageNum=50&pageNo=[#PAGENO#]"

        selector = Selector(response)
        category_str = u"".join(selector.xpath(category_xpath).extract()).strip()
        category = VideoInfoUtil.category_ch_to_en(category_str)
        if category == u"":
            category_str = u"".join(selector.xpath(u"//meta[@name='irCategory']/@content").extract())
            category = VideoInfoUtil.category_ch_to_en(category_str)
        if category == u"":
            category = response.meta.get("category", u"")
        if category == u"":
            log.msg(u"提取不到category! from =%s" % response.url, level=log.ERROR)
        if u"tv" in category or u"movie" in category or u"animation" in category:
            # extract albumId.
            matcher = album_id_pattern.search(response.body)
            if matcher:
                album_id = matcher.group(1)
            else:
                raise ValueError(u"提取albumId失败! url = %s" % response.url)

            # 抽取所有包含分集的中间页面.
            page_nos = selector.xpath(page_nos_xpath).extract()
            num_pattern = re.compile(ur"\d+")
            for page_no in page_nos:
                m = num_pattern.search(page_no)
                if m:
                    request_url = ep_medium_url_str.replace(u"[#ALBUMID#]", album_id).replace("[#PAGENO#]", m.group())
                    meta = {"category": category,
                            "page_type": PageType.EPISODE_MEDIUM_PAGE,
                            "album_id": response.url}
                    new_requests.append({"request_url": request_url, "meta": meta})
            # 抽取专辑页中的分集页.
            ep_nodes = selector.xpath(ep_url_in_album_xpath)
            index = 1
            for ep_node in ep_nodes:
                # no.
                no_txt = u"".join(ep_node.xpath(u"./@data-pb").extract())
                m = num_pattern.search(no_txt)
                if m:
                    no = m.group()
                else:
                    #log.msg(u"没有从中间页面中提取到no字段，现在试图用列表顺序作为可能的集数: %s; from = %s"
                    #        % (index + 1, response.url), level=log.INFO)
                    no = index
                # url.
                request_url = u"".join(ep_node.xpath(u"./@href").extract()).strip()
                meta = {"category": response.meta["category"],
                        "page_type": PageType.EPISODE_PAGE,
                        "no": no,
                        "album_id": qiyiExtractor.clean_url(response.url)}
                new_requests.append({"request_url": request_url, "meta": meta})
        if u"variety" in category:  # 综艺抽取分集的方法跟其他的不一样.
            # ------------------------------------------------------------------
            # 第一种版式.
            # ------------------------------------------------------------------
            matcher = re.compile(ur"sourceId *: *(\d+),").search(response.body)
            if matcher:
                source_id = matcher.group(1)
                # all years.
                years = set()
                year_xpath = u"//div[@class='choose-y-bd' and @data-source-elem='yearcont']//li//a[@data-year]/@data-year"
                for year in selector.xpath(year_xpath).extract():
                    years.add(year.strip())
                for year in years:
                    for month in xrange(1, 13):
                        year_month_str = u"%s%02d" % (year, month)
                        request_url = u"http://cache.video.qiyi.com/jp/sdvlst/6/%s/%s/?categoryId=6&sourceId=%s&tvYear=%s" \
                                      % (source_id, year_month_str, source_id, year_month_str)
                        meta = {"category": response.meta["category"],
                                "page_type": PageType.EPISODE_MEDIUM_PAGE,
                                "album_id": qiyiExtractor.clean_url(response.url)}
                        new_requests.append({"request_url": request_url, "meta": meta})
            # ------------------------------------------------------------------
            # 第二种版式.
            # ------------------------------------------------------------------
            else:
                matcher = re.compile(ur"""data-player-albumid="(\d+)" *""").search(response.body)
                if matcher:
                    album_id = matcher.group(1)
                else:
                    raise ValueError(u"qiyiExtractor没有提取到albumid! URL = %s" % response.url)

                # 请求year list.
                request_url = u"http://cache.video.qiyi.com/jp/sdlst/6/%s/" % album_id
                meta = {"category": category,
                        "page_type": PageType.EPISODE_MEDIUM_PAGE,
                        "album_id": response.url}
                new_requests.append({"request_url": request_url, "meta": meta})
            # ------------------------------------------------------------------
            # 第三种版式.
            # ------------------------------------------------------------------
            nodes = selector.xpath(u"//*[@id='jjlbListCon']//li")
            for node in nodes:
                no = u"".join(node.xpath(u".//em//text()").extract())
                no = VideoInfoUtil.format_no(no, False)
                if no == 0:
                    continue
                request_url = u"".join(node.xpath(u".//a/@href").extract())
                meta = {"category": category,
                        "page_type": PageType.EPISODE_PAGE,
                        "no": no,
                        "album_id": qiyiExtractor.clean_url(response.url)}
                new_requests.append({"request_url": request_url, "meta": meta})
        return new_requests

    @staticmethod
    def process_episode_page(response, display_stamp=""):
        """处理分集页的函数(参数明细参照extract函数)."""
        album_url_xpath = u"//*[@id='widget-videonav']//a[last()]/@href"
        category_xpath = u"//*[@id='widget-videonav']//a//text()"
        selector = Selector(response)
        request_url = u"".join(selector.xpath(album_url_xpath).extract()).strip()

        # 如果抽取到的专辑页链接为空，那么就从response.meta中尝试寻找专辑页链接.
        if request_url == u"":
            album_url = response.meta.get("album_id", u"")
            if album_url != u"":
                request_url = album_url

        # category.
        category = response.meta.get("category", u"")
        if category == u"":
            category_str = u"".join(selector.xpath(category_xpath).extract()).strip()
            category = VideoInfoUtil.category_ch_to_en(category_str)

        # 判断抽取到的链接是否符合预期的正则表达式，这样做的目的是为了:当出现新的未预期的链接格式时能及时发现.
        matcher = qiyiExtractor.album_url_pattern_1.search(request_url)
        if matcher:
            request_url = matcher.group()
        else:
            matcher = qiyiExtractor.album_url_pattern_2.search(request_url)
            if matcher:
                request_url = matcher.group()
            else:
                if request_url != u"" and category != u"movie":  # 电影没有专辑页.
                    log.msg(u"抽取出的链接『%s』不符合现在已知的专辑页链接格式，请检查原因! from = %s"
                            % (request_url, response.url), level=log.WARNING)
        if request_url in [u"http://www.iqiyi.com/dianying/", u"http://www.iqiyi.com/dongman/"]:
            return []

        meta = {"category": response.meta["category"],
                "page_type": PageType.ALBUM_PAGE}
        return [{"request_url": request_url, "meta": meta}]

    @staticmethod
    def process_episode_medium_page(response, display_stamp=""):
        """处理分集页的函数(参数明细参照extract函数)."""
        new_requests = list()
        # ------------------------------------------------------------------
        # 综艺获取year list的页面.
        # ------------------------------------------------------------------
        if qiyiExtractor.episode_medium_url_pattern_3.search(response.url):
            album_id = qiyiExtractor.episode_medium_url_pattern_3.search(response.url).group(1)
            matcher = re.compile(ur"var ?tvInfoJs *= *(\{.+\})").search(response.body)
            if matcher:
                json_obj = json.loads(matcher.group(1))
                for year in json_obj.get("data", {}):
                    for month in json_obj["data"][year]:
                        year_month = u"%s%s" % (year, month)
                        request_url = u"http://cache.video.qiyi.com/jp/sdvlst/6/%s/%s/" \
                                      u"?categoryId=6&sourceId=%s&tvYear=%s"\
                                      % (album_id, year_month, album_id, year_month)
                        meta = {"category": response.meta["category"],
                                "page_type": PageType.EPISODE_MEDIUM_PAGE,
                                "album_id": response.meta["album_id"]}
                        new_requests.append({"request_url": request_url, "meta": meta})
            else:
                raise ValueError(u"未能正确解析出json! URL = %s" % response.url)
            return new_requests
        # ------------------------------------------------------------------
        matcher = re.compile(ur"var ?tvInfoJs *= *(\{.+\})").search(response.body)
        if matcher:
            json_obj = json.loads(matcher.group(1))
            if u"variety" in response.meta["category"]:  # 处理综艺的medium页面.
                if u"data" not in json_obj:
                    return new_requests
                for item in json_obj["data"]:
                    request_url = item["vUrl"].strip()
                    meta = {"category": response.meta["category"],
                            "page_type": PageType.EPISODE_PAGE,
                            "no": (u"%s" % item["tvYear"]).replace(u"-", u""),
                            "album_id": response.meta.get("album_id", "")}
                    new_requests.append({"request_url": request_url, "meta": meta})
            else:  # 处理其他三类(两类)的medium页面.
                for item in json_obj["data"]["vlist"]:
                    request_url = item["vurl"].strip()
                    meta = {"category": response.meta["category"],
                            "page_type": PageType.EPISODE_PAGE,
                            "no": item["pd"],
                            "album_id": response.meta.get("album_id", "")}
                    new_requests.append({"request_url": request_url, "meta": meta})
        #else:
        #    matcher = re.compile(ur"var .+? = ({.+})").search(response.body)
        #    if matcher:
        #        json_obj = json.loads(matcher.group(1))
        #        for item in json_obj["data"]["list"]:
        #            request_url = item["TvApplication.purl"].strip()
        #            meta = {"category": response.meta["category"],
        #                    "page_type": PageType.EPISODE_PAGE,
        #                    "no": item["VrsVideotv.tvYear"],
        #                    "album_id": response.meta.get("album_id", "")}
        #            new_requests.append({"request_url": request_url, "meta": meta})
        else:
            raise ValueError(u"未能正确解析出json! URL = %s" % response.url)
        return new_requests

    @staticmethod
    def process_actor_page(response, display_stamp=""):
        """处理专辑页到分集页的中间页面的函数(参数明细参照extract函数)."""
        new_requests = list()
        return new_requests

    @staticmethod
    def process_actor_production_page(response, display_stamp=""):
        """处理演员/导演页面的函数(参数明细参照extract函数)."""
        new_requests = list()
        return new_requests
    
    @staticmethod
    def clean_url(url):
        """清理给定链接中的无用参数，得到比较规整的链接.

        @param url: 待清理的链接.
        @return: 返回清理后的链接.
        """
        matcher = qiyiExtractor.album_url_pattern_1.search(url)
        if matcher:
            return matcher.group()
        matcher = qiyiExtractor.album_url_pattern_2.search(url)
        if matcher:
            return matcher.group()
        matcher = qiyiExtractor.episode_url_pattern_1.search(url)
        if matcher:
            return matcher.group()
        matcher = qiyiExtractor.episode_url_pattern_2.search(url)
        if matcher:
            return matcher.group()
        matcher = qiyiExtractor.actor_url_pattern.search(url)
        if matcher:
            return matcher.group()
        return url