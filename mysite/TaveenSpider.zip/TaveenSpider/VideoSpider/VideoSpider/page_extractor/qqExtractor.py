#coding:utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.11.25"

from scrapy.selector import Selector
from scrapy.http import Response
from scrapy.spider import log
import json
import re

from ..page_extractor.PageExtractorBase import PageExtractorBase
from ..util.VideoInfoUtil import VideoInfoUtil
from TaveenUtil.Constants import *


class qqExtractor(PageExtractorBase):
    """qq网站的页面爬虫抽取新链接的类.

    该类主要实现从给定的页面中抽取出新的链接，这些新的链接会被放入爬取队列中进行爬取.

    qq页面抽取的逻辑大致为：
        1.
        2.
        3.
    """

    album_url_pattern_1 = re.compile(ur"http://v\.qq\.com/detail/.?/(.+)\.html")
    album_url_pattern_2 = re.compile(ur"http://v\.qq\.com/p/tv/detail/(.+)/(index\.html)*")
    # Modified by chjchen on 2015.04.16
    # 院线表达式为 http://v\.qq.com/p/tv/zt/[^/]+/(index.html)*
    album_url_pattern_3 = re.compile(ur"http://v\.qq\.com/p/tv/zt/(.+)/(index\.html)+")
    # End of modify on 2015.04.16
    episode_url_pattern_1 = re.compile(ur"http://v\.qq\.com/cover/.+/(.+)\.html\?vid=(.+)")
    episode_url_pattern_2 = re.compile(ur"http://v\.qq\.com/cover/.+/(.+)\.html")
    episode_url_pattern_3 = re.compile(ur"http://film\.qq\.com/cover/.?/(.+)\.html")
    episode_medium_url_pattern = re.compile(ur"http://s\.video\.qq\.com/loadplaylist\?vkey=(.+)&vtype=2&otype=json")
    actor_url_pattern = re.compile(ur"xxx")
    actor_production_url_pattern = re.compile(ur"xxx")

    @staticmethod
    def extract(response, display_stamp=""):
        """重写基类的 实现页面新链接抽取的函数.

        @param response: 当前页面的response对象.
        @param display_stamp: 用于显示的标记.
        @return: 返回包含新链接及其附加信息的列表.
        """
        if not isinstance(response, Response):
            raise ValueError(u"Parameter \"response\" must be type<scrapy.http.Response>!")

        new_requests = list()
        # Modified by chjchen on 2015.04.16
        # 增加了album_url_pattern_3的匹配
        if qqExtractor.album_url_pattern_1.search(response.url) \
                or qqExtractor.album_url_pattern_2.search(response.url) \
                or qqExtractor.album_url_pattern_3.search(response.url):
                #or qqExtractor.album_url_pattern_4.search(response.url):
        # End of the modify on 2015.04.16
            new_requests = qqExtractor.process_album_page(response, display_stamp)
        elif qqExtractor.episode_url_pattern_1.search(response.url) \
                or qqExtractor.episode_url_pattern_2.search(response.url) \
                or qqExtractor.episode_url_pattern_3.search(response.url):
            new_requests = qqExtractor.process_episode_page(response, display_stamp)
        elif qqExtractor.episode_medium_url_pattern.search(response.url):
            new_requests = qqExtractor.process_episode_medium_page(response, display_stamp)
        elif qqExtractor.actor_url_pattern.search(response.url):
            new_requests = qqExtractor.process_actor_page(response, display_stamp)
        elif qqExtractor.actor_production_url_pattern.search(response.url):
            new_requests = qqExtractor.process_actor_production_page(response, display_stamp)
        else:
            log.msg(u"%s 不满足目前代码中支持的任何一种链接格式，请查看原因!" % response.url, level=log.WARNING)
        return new_requests

    @staticmethod
    def process_album_page(response, display_stamp=""):
        new_requests = list()

        matcher = re.compile(ur"""special_url *: *(?:'|")(.+)(?:'|") *,""").search(response.body)
        if matcher:
            response.meta["page_type"] = PageType.ALBUM_MEDIUM_PAGE
            new_request_url = matcher.group(1).replace(u"\\x2F", u"/").strip()
            if not new_request_url.startswith(u"http://"):
                log.msg(u"解析出的跳转页链接不正确. VALUE = %s; URL = %s" % (new_request_url, response.url), level=log.ERROR)
            else:
                log.msg(u"跳转到：%s <from %s>" % (new_request_url, response.url))
            meta = {"category": response.meta.get("category", u""),
                    "page_type": PageType.ALBUM_PAGE,
                    "raw_album_url": qqExtractor.clean_url(response.url)}
            new_requests.append({"request_url": qqExtractor.clean_url(new_request_url), "meta": meta})
            return new_requests

        selector = Selector(response)
        # extract category.
        category_xpath = u"//div[@class='mod_box mod_box_summary']//div[@class='video_title']//text()"
        category = u"".join(selector.xpath(category_xpath).extract()).strip()
        category = VideoInfoUtil.category_ch_to_en(category)
        if category == u"":
            category = response.meta.get("category", u"")
        if category == u"":
            raise ValueError(u"无法从页面中提取到category！URL = %s" % response.url)

        album_url = response.url
        if response.meta.get("raw_album_url", None) is not None:
            album_url = response.meta["raw_album_url"]
        if category == u"tv" or category == u"animation" or category == u"movie" or category == u"variety":
            source_id_xpath = u"//div[@class='mod_bd sourceCont']/@sourceid"
            source_id = u"".join(selector.xpath(source_id_xpath).extract()).strip()
            if source_id != u"":
                # 版式1.
                ep_medium_url = u"http://s.video.qq.com/loadplaylist?vkey=%s&vtype=2&otype=json" % source_id
                meta = {"category": category,
                        "page_type": PageType.EPISODE_MEDIUM_PAGE,
                        "album_id": qqExtractor.clean_url(album_url)}
                #print u"%s -->>> %s" % (ep_medium_url, response.url)
                new_requests.append({"request_url": qqExtractor.clean_url(ep_medium_url), "meta": meta})

            else:
                # 版式2.
                ep_block_xpath = u"//div[@class='mod_video_fragments']//li[@class='list_item']"
                nodes = selector.xpath(ep_block_xpath)
                for node in nodes:
                    request_url = u"http://v.qq.com%s" % u"".join(node.xpath(u"./strong/a/@href").extract()).strip()
                    no = u"".join(node.xpath(u"./strong/a/text()").extract()).strip()
                    meta = {"category": response.meta["category"],
                            "no": no,
                            "page_type": PageType.EPISODE_PAGE,
                            "album_id": qqExtractor.clean_url(album_url)}
                    new_requests.append({"request_url": qqExtractor.clean_url(request_url), "meta": meta})
                if len(nodes) == 0:
                    # 版式3(没有分集，只有“台前幕后”).
                    tqmh_xpath = u"//*[@id='tqmh_ul']//li[@class='list_item']/a/@href"
                    urls = selector.xpath(tqmh_xpath).extract()
                    index = 1
                    for url in urls:
                        request_url = qqExtractor.clean_url(url)
                        meta = {"category": response.meta["category"],
                                "no": index,
                                "page_type": PageType.EPISODE_PAGE,
                                "album_id": qqExtractor.clean_url(album_url)}
                        new_requests.append({"request_url": qqExtractor.clean_url(request_url), "meta": meta})
                        index += 1
        return new_requests

    @staticmethod
    def process_episode_page(response, display_stamp=""):
        """处理专辑页的函数(参数明细参照extract函数)."""
        new_requests = list()

        if u"http://film.qq.com" in response.url:
            response.meta["category"] = u"movie"
            return new_requests

        selector = Selector(response)
        # extract category.
        category = response.meta.get("category", u"")
        if category == u"":
            category_xpath = u"//div[@class='container_inner']//div[@class='breadcrumb']//text()"
            category = u"".join(selector.xpath(category_xpath).extract()).strip()
            category = VideoInfoUtil.category_ch_to_en(category)
        # extract album url.
        album_url_xpath_1 = u"//div[@class='container_inner']//div[@class='breadcrumb']//a[last()]/@href"
        album_url_xpath_2 = u"//div[@id='mod_paths']//a[last()]/@href"
        album_url = u"".join(selector.xpath(album_url_xpath_1).extract())
        if album_url == u"":
            album_url = u"".join(selector.xpath(album_url_xpath_2).extract()).strip()
        album_url = u"http://v.qq.com%s" % album_url
        album_url = qqExtractor.clean_url(album_url)
        meta = {"category": category,
                "page_type": PageType.ALBUM_PAGE}

        # 这段代码不知道为啥莫名都是抓到第一集的标题进行垃圾处理
        # Added by chjchen on 2015.04.22
        # 这段代码修复了腾讯电视剧之前在抓取过程中，连预告片也放入到数据库中的问题
        # 如果发现这个分集是一个预告片，片花之类的，那么就直接不会return 这个分集的item，达到了非正式数据补入库的目的
        #qq_tv_subtitle_xpath = u"//div[@class='mod_player_head cf']/div[@class='mod_titles']/h1/text()"
        #qq_tv_subtitle_res = selector.xpath(qq_tv_subtitle_xpath).extract()
        #rubbish_res = VideoInfoUtil.is_rubbish(qq_tv_subtitle_res[0])
        #for tmp in qq_tv_subtitle_res:
        #    print str(tmp) + "~~~~"
        ##print str(qq_tv_subtitle_res[0]) + "~~~"
        #if not rubbish_res:
        #    new_requests.append({"request_url": album_url, "meta": meta})
        #return new_requests
        # End of Add on 2015.04.22

        # Modified by chjchen on 2015.04.23
        # 这段代码修复了腾讯电视剧之前在抓取过程中，连预告片也放入到数据库中的问题
        if len(response.meta["title"]) > 0:
            rubbish_res = VideoInfoUtil.is_rubbish(response.meta["title"])
            if not rubbish_res:
                new_requests.append({"request_url": album_url, "meta": meta})
                return new_requests
        else:
            qq_tv_subtitle_xpath = u"//div[@class='mod_player_head cf']/div[@class='mod_titles']/h1/text()"
            qq_tv_subtitle_res = selector.xpath(qq_tv_subtitle_xpath).extract()
            rubbish_res = VideoInfoUtil.is_rubbish(qq_tv_subtitle_res[0])
            if not rubbish_res:
                new_requests.append({"request_url": album_url, "meta": meta})
                return new_requests
        # End of Modify on 2015.04.23

    @staticmethod
    def process_episode_medium_page(response, display_stamp=""):
        """处理分集页的函数(参数明细参照extract函数)."""
        new_requests = list()

        matcher = re.compile(ur"QZOutputJson *= *({.+}) *;").search(response.body)
        if matcher:
            data = json.loads(matcher.group(1))
        else:
            log.msg(u"未正确获取到json格式的response数据. URL = %s" % response.url, level=log.WARNING)
            return new_requests

        for item in data["video_play_list"]["playlist"]:
            request_url = item["url"]
            if response.meta["category"] == u"movie":  # 对于电影来说，去掉后缀的&vid=xxxx.
                request_url = re.sub(u"\?vid=.+", u"", request_url)
            meta = {"category": response.meta["category"],
                    "no": item["episode_number"],
                    "title": item.get("title"),
                    "page_type": PageType.EPISODE_PAGE,
                    "album_id": qqExtractor.clean_url(response.meta["album_id"])}
            new_requests.append({"request_url": qqExtractor.clean_url(request_url), "meta": meta})

        return new_requests

    @staticmethod
    def process_actor_page(response, display_stamp=""):
        """处理专辑页到分集页的中间页面的函数(参数明细参照extract函数)."""
        new_requests = list()
        return new_requests

    @staticmethod
    def process_actor_production_page(response, display_stamp=""):
        """处理演员/导演页面的函数(参数明细参照extract函数)."""
        new_requests = list()
        return new_requests
    
    @staticmethod
    def clean_url(url):
        """清理给定链接中的无用参数，得到比较规整的链接.

        @param url: 待清理的链接.
        @return: 返回清理后的链接.
        """
        matcher = qqExtractor.album_url_pattern_1.search(url)
        if matcher:
            return matcher.group()
        matcher = qqExtractor.album_url_pattern_2.search(url)
        if matcher:
            return matcher.group()
        # Modified by chjchen on 2015.04.16
        # 将pattern3的清洗加入到这个函数里面
        matcher = qqExtractor.album_url_pattern_3.search(url)
        if matcher:
           return matcher.group()
        # End of the modify on 2015.04.06
        matcher = qqExtractor.episode_url_pattern_1.search(url)  # 注意：1在前，2在后，不然会被覆盖掉.
        if matcher:
            return matcher.group()
        matcher = qqExtractor.episode_url_pattern_2.search(url)
        if matcher:
            return matcher.group()
        matcher = qqExtractor.episode_url_pattern_3.search(url)
        if matcher:
            return matcher.group()
        matcher = qqExtractor.actor_url_pattern.search(url)
        if matcher:
            return matcher.group()
        return url