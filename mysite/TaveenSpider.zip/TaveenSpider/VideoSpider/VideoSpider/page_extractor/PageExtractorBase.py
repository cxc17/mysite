#coding:utf-8
__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.09.10"

from scrapy.http import Response

from TaveenUtil.SpiderConfig import SpiderConfig


class PageExtractorBase(object):
    """页面爬虫抽取新链接的基类.

    该类及其子类主要实现从给定的页面中抽取出新的链接，这些新的链接会被放入爬取队列中进行爬取.
    """

    # 当前处理的网站名.
    website = SpiderConfig.get_website()
    # 当前是否为快速更新(小循环)模式.
    is_quick_update = SpiderConfig.get_is_quick_update()
    # 是否对演员及其作品的页面进行抽取和处理.
    is_extract_actor_page = SpiderConfig.get_if_extract_video_from_actor_page()

    @staticmethod
    def extract(response, display_stamp=""):
        """实现页面新链接抽取的函数.

        该函数必须被子类重写.

        @param response: 当前页面的response对象.
        @param display_stamp: 用于显示的标记.
        @return: 返回包含新链接及其附加信息的列表.
        """
        if not isinstance(response, Response):
            raise ValueError(u"Parameter \"response\" must be type<scrapy.http.Response>!")
        raise NotImplementedError()