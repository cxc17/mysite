#coding:utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.10.22"

from scrapy.selector import Selector
from scrapy.http import Response
from scrapy.spider import log
import json
import re

from ..page_extractor.PageExtractorBase import PageExtractorBase
from ..util.VideoInfoUtil import VideoInfoUtil
from TaveenUtil.Constants import *


class tudouExtractor(PageExtractorBase):
    """tudou网站的页面爬虫抽取新链接的类.

    该类主要实现从给定的页面中抽取出新的链接，这些新的链接会被放入爬取队列中进行爬取.

    tudou页面抽取的逻辑大致为：
        1.
        2.
        3.
    """

    album_url_pattern = re.compile(ur"http://www\.tudou\.com/albumcover/([^/]+)?\.html")
    episode_url_pattern1 = re.compile(ur"http://www\.tudou\.com/albumplay/([^/]+)\.html")
    episode_url_pattern2 = re.compile(ur"http://www\.tudou\.com/albumplay/([^/]+)/([^/]+)\.html")
    episode_medium_url_pattern = re.compile(ur"http://www\.tudou\.com/albumcover/albumdata/getAlbumvoInfo\.html\?charset=utf-8&acode=(.+)")
    actor_url_pattern = re.compile(ur"http://www\.tudou\.com/albumtop/person/.+?\.html")
    #actor_production_url_pattern = re.compile(ur"")

    @staticmethod
    def extract(response, display_stamp=""):
        """重写基类的 实现页面新链接抽取的函数.

        @param response: 当前页面的response对象.
        @param display_stamp: 用于显示的标记.
        @return: 返回包含新链接及其附加信息的列表.
        """
        if not isinstance(response, Response):
            raise ValueError(u"Parameter \"response\" must be type<scrapy.http.Response>!")

        new_requests = list()
        if tudouExtractor.album_url_pattern.search(response.url):
            new_requests = tudouExtractor.process_album_page(response, display_stamp)
        elif tudouExtractor.episode_url_pattern1.search(response.url) \
                or tudouExtractor.episode_url_pattern2.search(response.url):
            new_requests = tudouExtractor.process_episode_page(response, display_stamp)
        elif tudouExtractor.episode_medium_url_pattern.search(response.url):
            new_requests = tudouExtractor.process_episode_medium_page(response, display_stamp)
        elif tudouExtractor.actor_url_pattern.search(response.url):
            new_requests = tudouExtractor.process_actor_page(response, display_stamp)
        #elif tudouExtractor.actor_production_url_pattern.search(response.url):
        #    new_requests = tudouExtractor.process_actor_production_page(response, display_stamp)
        else:
            log.msg(u"%s 不满足目前代码中支持的任何一种链接格式，请查看原因!" % response.url, level=log.WARNING)
        return new_requests

    @staticmethod
    def process_album_page(response, display_stamp=""):
        """处理专辑页的函数(参数明细参照extract函数)."""
        new_requests = list()

        # all xpath or url.
        category_xpath = u"//title/text()"
        ep_medium_url = u"http://www.tudou.com/albumcover/albumdata/getAlbumvoInfo.html?charset=utf-8&acode=[#ACODE#]"

        selector = Selector(response)
        # 1.从专辑页中抽取分集页或者抽取包含分集页列表的json/xml页面.
        # extract vid.
        matcher = tudouExtractor.album_url_pattern.search(response.url)
        if matcher:
            vid = matcher.group(1)
        else:
            raise ValueError(u"从URL中提取vid失败! url = %s" % response.url)
        # extract category.
        category = VideoInfoUtil.category_ch_to_en(u"".join(selector.xpath(category_xpath).extract()))
        if category == u"":
            category = VideoInfoUtil.category_ch_to_en(response.meta.get("category", u""))
        # extract episodes.
        if category == u"tv" or category == u"movie" or category == u"variety" or category == u"animation":
            request_url = ep_medium_url.replace(u"[#ACODE#]", vid)
            meta = {"category": category,
                    "page_type": PageType.EPISODE_MEDIUM_PAGE,
                    "album_id": tudouExtractor.clean_url(response.url)}
            new_requests.append({"request_url": request_url, "meta": meta})
        # 2.从专辑页中抽取演员/页面.
        if tudouExtractor.is_extract_actor_page:
            # extract actor page url.
            actor_url_xpath = u"//div[@class='cover_keys']//span[contains(span, '主演') or contains(span, '编导') " \
                              u"or contains(span, '导演') or contains(span, '编剧') or contains(span, '主持人') " \
                              u"or contains(span, '声优')]//a/@href"
            urls = selector.xpath(actor_url_xpath).extract()
            for url in urls:
                matcher = tudouExtractor.actor_url_pattern.search(url)
                if matcher:
                    request_url = matcher.group()
                    meta = {"category": "",
                            "page_type": PageType.ACTOR_PAGE}
                    new_requests.append({"request_url": tudouExtractor.clean_url(request_url), "meta": meta})
                else:
                    if request_url != u"":
                        log.msg(u"抽取出的链接『%s』不符合现在已知的演员/导演页链接格式，请检查原因! from = %s"
                                % (request_url, response.url), level=log.WARNING)

        return new_requests

    @staticmethod
    def process_episode_page(response, display_stamp=""):
        """处理分集页的函数(参数明细参照extract函数)."""
        new_requests = list()

        # all xpath or url.
        category_xpath = u"//title/text()"
        album_url_xpath = u"//h1[@id='videoKw']//a/@href"

        selector = Selector(response)
        # extract category.
        category = VideoInfoUtil.category_ch_to_en(u"".join(selector.xpath(category_xpath).extract()))
        if category == u"":
            category = VideoInfoUtil.category_ch_to_en(response.meta.get("category", u""))
        # extract album.
        album_url = u"".join(selector.xpath(album_url_xpath).extract())
        # 判断抽取到的链接是否符合预期的正则表达式，这样做的目的是为了:当出现新的未预期的链接格式时能及时发现.
        matcher = tudouExtractor.album_url_pattern.search(album_url)
        if matcher:
            album_url = matcher.group()
        else:
            if album_url != u"":
                log.msg(u"抽取出的链接『%s』不符合现在已知的专辑页链接格式，请检查原因! from = %s"
                        % (album_url, response.url), level=log.WARNING)

        meta = {"category": category,
                "page_type": PageType.ALBUM_PAGE}

        # Added by chjchen on 2015.05.02
        # 这段代码修复了tudou电视剧之前在抓取过程中，连预告片也放入到数据库中的问题
        # 如果发现这个分集是一个预告片，片花之类的，那么就直接不会return 这个分集的item，达到了非正式数据补入库的目的
        if len(response.meta["title"]) > 0:
            rubbish_res = VideoInfoUtil.is_rubbish(response.meta["title"])
            if not rubbish_res:
                new_requests.append({"request_url": album_url, "meta": meta})
                return new_requests
        else:
            tudou_tv_subtitle_xpath = u"//div[@class='summary_main']/div[@class='fix']/h1/text()"
            tudou_tv_subtitle_res = selector.xpath(tudou_tv_subtitle_xpath).extract()
            rubbish_res = VideoInfoUtil.is_rubbish(tudou_tv_subtitle_res[0])
            if not rubbish_res:
                new_requests.append({"request_url": album_url, "meta": meta})
                return new_requests
        # End of Modify by chjchen on 2015.05.02

    @staticmethod
    def process_episode_medium_page(response, display_stamp=""):
        """处理专辑页到分集页的中间页面的函数(参数明细参照extract函数)."""
        new_requests = list()

        resp_data = json.loads(response.body)
        category = response.meta["category"]
        for data in resp_data["items"]:
            if category == u"tv" or category == u"movie" or category == u"variety" or category == u"animation":
                request_url = data["itemPlayUrl"]
                if request_url == u"":
                    continue
                meta = {"category": category,
                        "page_type": PageType.EPISODE_PAGE,
                        "no": data.get("itemTitle", 0),
                        "album_id": response.meta.get("album_id", "")}
                new_requests.append({"request_url": request_url, "meta": meta})
        return new_requests

    @staticmethod
    def process_actor_page(response, display_stamp=""):
        """处理演员/导演页面的函数(参数明细参照extract函数)."""
        new_requests = list()
        selector = Selector(response)
        nodes = selector.xpath(u"//div[@id='secPros']//dl//dd")
        for node in nodes:
            category = u"".join(node.xpath(u"./span[@class='t']//text()").extract()).strip()
            category = VideoInfoUtil.category_ch_to_en(category)
            if category not in CategoryNames_CH and category not in CategoryNames:
                continue
            request_url = u"".join(node.xpath(u".//a[@class='name']/@href").extract())
            matcher = tudouExtractor.album_url_pattern.search(request_url)
            if matcher:  # 目前只从抽取链接为专辑页链接的作品，为的是防止其他category混入.
                request_url = matcher.group()
                meta = {"category": category, "page_type": PageType.ALBUM_PAGE}
                new_requests.append({"request_url": request_url, "meta": meta})
        return new_requests

    #@staticmethod
    #def process_actor_production_page(response, display_stamp=""):
    #    """处理演员/导演的作品页面的函数(参数明细参照extract函数)."""
    #    new_requests = list()
    #    return new_requests

    @staticmethod
    def clean_url(url):
        """清理给定链接中的无用参数，得到比较规整的链接.

        @param url: 待清理的链接.
        @return: 返回清理后的链接.
        """
        matcher = tudouExtractor.album_url_pattern.search(url)
        if matcher:
            return matcher.group()
        matcher = tudouExtractor.episode_url_pattern1.search(url)
        if matcher:
            return matcher.group()
        matcher = tudouExtractor.episode_url_pattern2.search(url)
        if matcher:
            return matcher.group()
        matcher = tudouExtractor.actor_url_pattern.search(url)
        if matcher:
            return matcher.group()
        return url