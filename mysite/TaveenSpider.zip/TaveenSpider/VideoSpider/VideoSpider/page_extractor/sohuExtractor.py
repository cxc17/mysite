#coding:utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.10.22"

from scrapy.selector import Selector
from scrapy.http import Response
from scrapy.spider import log
import time
import json
import re

from ..page_extractor.PageExtractorBase import PageExtractorBase
from ..util.VideoInfoUtil import VideoInfoUtil
from TaveenUtil.Constants import *


class sohuExtractor(PageExtractorBase):
    """sohu网站的页面爬虫抽取新链接的类.

    该类主要实现从给定的页面中抽取出新的链接，这些新的链接会被放入爬取队列中进行爬取.

    xxx页面抽取的逻辑大致为：
        1.
        2.
        3.
    """

    album_url_pattern_1 = re.compile(ur"http://tv\.sohu\.com/item/(.+)\.html")
    album_url_pattern_2 = re.compile(ur"http://tv\.sohu\.com/([^/]+)/([^/.]+)/")
    album_url_pattern_3 = re.compile(ur"http://tv\.sohu\.com/([^/]+)/")
    episode_url_pattern = re.compile(ur"http://tv\.sohu\.com/(.+)/(.+)\.shtml")
    episode_medium_url_pattern = re.compile(ur"http://tv\.sohu\.com/item/VideoServlet\?source=sohu&id=(\d+)&year=(\d+)&month=(\d+)")
    actor_url_pattern = re.compile(ur"xxx")
    actor_production_url_pattern = re.compile(ur"xxx")

    @staticmethod
    def extract(response, display_stamp=""):
        """重写基类的 实现页面新链接抽取的函数.

        @param response: 当前页面的response对象.
        @param display_stamp: 用于显示的标记.
        @return: 返回包含新链接及其附加信息的列表.
        """
        if not isinstance(response, Response):
            raise ValueError(u"Parameter \"response\" must be type<scrapy.http.Response>!")

        new_requests = list()
        # 下面的if,else跟正则表达式有关系，顺序是避免正则之间覆盖的.
        if sohuExtractor.episode_medium_url_pattern.search(response.url):
            new_requests = sohuExtractor.process_episode_medium_page(response, display_stamp)
        elif sohuExtractor.episode_url_pattern.search(response.url):
            new_requests = sohuExtractor.process_episode_page(response, display_stamp)
        elif sohuExtractor.album_url_pattern_1.search(response.url)\
                or sohuExtractor.album_url_pattern_2.search(response.url) \
                or sohuExtractor.album_url_pattern_3.search(response.url):
            new_requests = sohuExtractor.process_album_page(response, display_stamp)
        elif sohuExtractor.actor_url_pattern.search(response.url):
            new_requests = sohuExtractor.process_actor_page(response, display_stamp)
        elif sohuExtractor.actor_production_url_pattern.search(response.url):
            new_requests = sohuExtractor.process_actor_production_page(response, display_stamp)
        else:
            log.msg(u"%s 不满足目前代码中支持的任何一种链接格式，请查看原因!" % response.url, level=log.WARNING)
        return new_requests

    @staticmethod
    def process_album_page(response, display_stamp=""):
        new_requests = list()

        selector = Selector(response)
        # extract category.
        category_xpath = u"//div[@class='show-name area rel cfix']//h2//text()"
        category = u"".join(selector.xpath(category_xpath).extract())
        category = VideoInfoUtil.category_ch_to_en(category)
        if category == u"":
            category_xpath = u"//*[@id='location']//h1//text()"
            category = VideoInfoUtil.category_ch_to_en(u"".join(selector.xpath(category_xpath).extract()))
        if category == u"":
            category = response.meta.get("category", u"")
        if category == u"":
            raise ValueError(u"无法从页面中提取到category！URL = %s" % response.url)

        album_url = response.url  # 解决sohu视频从专辑页跳到分集页后，从分集页会跳转到另一个专辑页的问题.
        if category == u"tv" or category == u"animation" or category == u"variety":
            if sohuExtractor.album_url_pattern_1.search(album_url):
                new_album_xpath = u"//div[@class='l actionR']//a[contains(text(), '收藏')]/@href"
                new_album_url = u"".join(selector.xpath(new_album_xpath).extract()).strip()
                if new_album_url == u"":
                    log.msg(u"未成功从sohu视频专辑页抓取到新的URL FROM = %s" % album_url, level=log.WARNING)
                else:
                    album_url = new_album_url

        if category == u"tv" or category == u"animation":
            # 版式1.
            ep_list_xpath = u"//div[@class='mod general']//ul[@class='list listA cfix']//li//strong//a"
            nodes = selector.xpath(ep_list_xpath)
            if len(nodes) == 0:  # 版式2.
                ep_list_xpath = u"//*[@id='list_asc']//li//strong//a"
                nodes = selector.xpath(ep_list_xpath)
            for node in nodes:
                request_url = u"".join(node.xpath(u"./@href").extract()).strip()
                no = u"".join(node.xpath(u".//text()").extract()).strip()
                meta = {"category": response.meta["category"],
                        "no": no,
                        "page_type": PageType.EPISODE_PAGE,
                        "album_id": sohuExtractor.clean_url(album_url)}
                new_requests.append({"request_url": sohuExtractor.clean_url(request_url), "meta": meta})
            pass
        elif category == u"movie":
            # Modified by chjchen on 2015.04.10
            ep_xpath = u"//div[@class='cfix movie-info']//a[contains(text(), '播放正片')]/@href"
            test_ep_xpath = u"//div[@class='cfix movie-info']//a[contains(text(), '播放预告片')]/@href"
            request_url1 = u"".join(selector.xpath(ep_xpath).extract()).strip()
            request_url2 = u"".join(selector.xpath(test_ep_xpath).extract()).strip()
            #print str(request_url1) + "request_url1"
            #print str(request_url2) + "request_url2"
            if request_url1 != u"":
                request_url = request_url1
            elif request_url2 != u"":
                request_url = request_url2
            else:
                log.msg(u"从电影页面 %s 中既没有抽取到正片，也没有抽取到预告片." % response.url, level=log.WARNING)
                return new_requests
            #print str(sohuExtractor.clean_url(request_url)) + "request_urlllll"
            meta = {"category": response.meta["category"],
                    "page_type": PageType.EPISODE_PAGE,
                    "album_id": sohuExtractor.clean_url(response.url)}
            new_requests.append({"request_url": sohuExtractor.clean_url(request_url), "meta": meta})
            # End of Modify on 2015.04.10
        elif category == u"variety":
            # extract years.
            year_xpath = u"//ul[@class='filter']//li[@class='v-year']//a//text()"
            years = selector.xpath(year_xpath).extract()
            if len(years) == 0:  # 版式2.
                year_xpath = u"//*[@id='zy_y']//a//text()"
                years = selector.xpath(year_xpath).extract()
                # Added by chjchen on 2015.04.10
                # 版式3
                if len(years) == 0:
                    year_xpath = u"substring(//div[@class='show-name area rel cfix'] \
                                   /span[contains(text(), '更新至')]/em/text(), 1, 4)"
                    years = selector.xpath(year_xpath).extract()
                # End of the add on 2015.04.10
            # extract vid.
            matcher = re.compile(ur"""var +?playlistId *= *(?:'|")(.+?)(?:'|") *;""").search(response.body)
            if matcher:
                vid = matcher.group(1)
            else:
                matcher = re.compile(ur"""var +?PLAYLIST_ID *= *(?:'|")(.+?)(?:'|") *;""").search(response.body)
                if matcher:
                    vid = matcher.group(1)
                else:
                    log.msg(u"未成功获取到vid! URL = %s" % response.url, level=log.ERROR)
                    return new_requests
            if len(years) == 0:
                years = [time.strftime("%Y", time.localtime())]
            # extract episode medium url.
            for year in years:
                for month in xrange(1, 13):
                    request_url = u"http://tv.sohu.com/item/VideoServlet?source=sohu&id=%s&year=%s&month=%s" \
                                  % (vid, year, month)
                    meta = {"category": response.meta["category"],
                            "page_type": PageType.EPISODE_MEDIUM_PAGE,
                            "album_id": sohuExtractor.clean_url(album_url)}
                    new_requests.append({"request_url": sohuExtractor.clean_url(request_url), "meta": meta})

        return new_requests

    @staticmethod
    def process_episode_page(response, display_stamp=""):
        """处理专辑页的函数(参数明细参照extract函数)."""
        new_requests = list()

        selector = Selector(response)
        # extract category.
        category = response.meta.get("category", u"")
        if category == u"":
            category_xpath = u"//*[@id='crumbsBar']//div[@class='crumbs']//a//text()"
            category = u"".join(selector.xpath(category_xpath).extract()).strip()
            category = VideoInfoUtil.category_ch_to_en(category)
        # extract album url.
        album_url_xpath = u"//*[@id='crumbsBar']//div[@class='crumbs']//a[last()]/@href"
        album_url = u"".join(selector.xpath(album_url_xpath).extract()).strip()

        # Added by chjchen on 2015.04.09
        if category == u"tv" or category == u"variety":
            album_url = response.meta["video_url"]
        # 这个是针对电视剧这种进行修改，搜狐的电视剧会出现这样一种情况，那就是不同的url会指向同一部电视剧
        # 这两个不同的url虽然指向同一部电视剧，而且他们的分集链接也是一样的，不同的是他们的专辑页面

        album_url = sohuExtractor.clean_url(album_url)

        # 处理有些综艺的分集页找不到专辑页链接的问题.
        if album_url == u"" or not album_url.startswith(u"http://") and response.meta.get("album_id", None) is not None:
            album_url = response.meta["album_id"]

        meta = {"category": category,
                "page_type": PageType.ALBUM_PAGE}
        new_requests.append({"request_url": album_url, "meta": meta})

        for tmp in new_requests:
            print str(tmp["request_url"]) + "!!!!!!!!!!!!"
        return new_requests

    @staticmethod
    def process_episode_medium_page(response, display_stamp=""):
        """处理分集页的函数(参数明细参照extract函数)."""
        new_requests = list()

        category = response.meta["category"]
        if category == u"variety":
            # 排除没有数据的情况.
            if len(response.body) < 50 and re.compile(ur"""videos[^"']{0,1}:\[\]""").search(response.body):
                return new_requests
            data = json.loads(response.body)
            for item in data["videos"]:
                request_url = item["url"]
                no = item["showDate"]
                meta = {"category": response.meta["category"],
                        "no": no,
                        "page_type": PageType.EPISODE_PAGE,
                        "album_id": sohuExtractor.clean_url(response.meta["album_id"])}
                new_requests.append({"request_url": sohuExtractor.clean_url(request_url), "meta": meta})

        return new_requests

    @staticmethod
    def process_actor_page(response, display_stamp=""):
        """处理专辑页到分集页的中间页面的函数(参数明细参照extract函数)."""
        new_requests = list()
        return new_requests

    @staticmethod
    def process_actor_production_page(response, display_stamp=""):
        """处理演员/导演页面的函数(参数明细参照extract函数)."""
        new_requests = list()
        return new_requests
    
    @staticmethod
    def clean_url(url):
        """清理给定链接中的无用参数，得到比较规整的链接.

        @param url: 待清理的链接.
        @return: 返回清理后的链接.
        """
        matcher = sohuExtractor.episode_medium_url_pattern.search(url)  # 这个要放在最前面，避免被其他正则表达式覆盖.
        if matcher:
            return matcher.group()
        matcher = sohuExtractor.episode_url_pattern.search(url)         # 这个要放在前面，避免被其他正则表达式覆盖.
        if matcher:
            return matcher.group()
        matcher = sohuExtractor.album_url_pattern_1.search(url)
        if matcher:
            return matcher.group()
        matcher = sohuExtractor.album_url_pattern_2.search(url)
        if matcher:
            return matcher.group()
        matcher = sohuExtractor.album_url_pattern_3.search(url)
        if matcher:
            return matcher.group()
        matcher = sohuExtractor.actor_url_pattern.search(url)
        if matcher:
            return matcher.group()
        return url