# coding=utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.09.03"

from TaveenUtil.SpiderConfig import SpiderConfig
from TaveenUtil.FileOperator import FileOperator
from TaveenUtil.Global import Global

from ..util.SQLGenerator import PageSpiderSqlGenerator
from ..util.VideoInfo import VideoInfo

from scrapy.spider import log
import traceback
import json


class PageSpiderStatistics(object):
    """页面爬虫的相关数据统计类.

    该类用于统计所有与页面爬虫相关的数据，以便进行改版预警或者是后续数据统计和分析.
    """

    website = ""                        # 当前正在统计的website.

    spider_mode = ""                    # 爬虫执行模式: quick_update/nomal/nomal_extract_actor

    ip = ""                             # 本机IP地址.

    start_time = None                   # 本次爬虫启动时的时间.

    time_used = 0                       # 本次爬虫执行所用的总时间.

    result_state = "unset"              # 从本次统计结果得出的爬虫执行状态: ok/warning/error/unknown/unset.

    scrapy_stat = {}                    # scrapy在程序最后提供出的status.

    __extract_stat_file_path = None     # [内部可见]page_extract_stat.txt文件的路径.
    __extract_stat_file_handler = None  # [内部可见]page_extract_stat.txt文件的读写句柄

    __v_info_stat_file_path = None      # [内部可见]v_info_extract_stat.txt文件的路径.
    __v_info_stat_file_handler = None   # [内部可见]v_info_extract_stat.txt文件的读写句柄

    __insert_sql_file_path = None       # [内部可见]insert_sql.txt文件的路径.
    __insert_sql_file_handler = None    # [内部可见]insert_sql.txt文件的读写句柄.

    def __init__(self):
        """初始化统计类的实例."""
        self.website = SpiderConfig.get_website()
        self.ip = Global.ip
        self.start_time = Global.ProgramStartTime
        self.scrapy_stat = {}
        pass

    def write_statistics_to_db(self):
        """将统计类的信息写入VideoStat数据库中的stat_page_exec表中."""
        print u"★STEP INFO★: 将页面爬虫本次执行的统计信息写入数据库中..."
        sql = PageSpiderSqlGenerator.sql_insert_exec_log(self)
        Global.DbOperator_VideoSpider.update(sql)
        print u"★STEP INFO★: 写入完毕."

    def calculate_statistics(self):
        """计算爬虫执行的统计信息."""
        self.start_time = Global.ProgramStartTime
        self.website = SpiderConfig.get_website()
        self.time_used = Global.ProgramUsedTime
        self.spider_mode = PageSpiderStatistics.get_page_spider_mode()

        self.result_state = "ok"
        pass

    @staticmethod
    def get_page_spider_mode():
        """获取当前的spider_mode.

        @return: 返回spider_mode.
        """
        if SpiderConfig.get_is_quick_update():
            return "quick_update"
        elif not SpiderConfig.get_if_extract_video_from_actor_page():
            return "nomal"
        elif SpiderConfig.get_if_apply_seeds_filter():
            return "nomal_extract_actor"
        else:
            return ""

    @staticmethod
    def write_extract_stat(response, page_type, new_requests):
        """将extract_stat信息写入page_extract_stat.txt文件中.

        @param response: 当前页面的response对象.
        @param page_type: 当前页面的页面类型.
        @param new_requests: 从当前页面中抽取中的信息的待爬取的链接列表.
        #@param video_info_list: 从当前页面中抽取出的视频信息列表.
        @return: 无.
        """
        if PageSpiderStatistics.__extract_stat_file_path is None:
            directory = SpiderConfig.get_log_output_dir()
            PageSpiderStatistics.__extract_stat_file_path = u"%spage_extract_stat.txt" % directory
            if not FileOperator.exist_file(PageSpiderStatistics.__extract_stat_file_path):
                FileOperator.create_file(PageSpiderStatistics.__extract_stat_file_path)
        if PageSpiderStatistics.__extract_stat_file_handler is None:
            PageSpiderStatistics.__extract_stat_file_handler = open(PageSpiderStatistics.__extract_stat_file_path,
                                                                    "w+")

        requests_dict = {"new_requests": new_requests}
        text = u"""{"response_url": "%s", "page_type": "%s", "new_requests": %s}\n""" \
               % (response.url, page_type, json.dumps(requests_dict["new_requests"], ensure_ascii=False))

        PageSpiderStatistics.__extract_stat_file_handler.writelines(text)
        PageSpiderStatistics.__extract_stat_file_handler.flush()

    @staticmethod
    def write_v_info_stat(video_data):
        """将v_info_stat信息写入v_info_extract_stat.txt文件中.

        @param video_data: 从当前页面中抽取出的视频信息或视频信息列表.
        @return: 无.
        """
        try:
            if PageSpiderStatistics.__v_info_stat_file_path is None:
                directory = SpiderConfig.get_log_output_dir()
                PageSpiderStatistics.__v_info_stat_file_path = u"%sv_info_extract_stat.txt" % directory
                if not FileOperator.exist_file(PageSpiderStatistics.__v_info_stat_file_path):
                    FileOperator.create_file(PageSpiderStatistics.__v_info_stat_file_path)
            if PageSpiderStatistics.__v_info_stat_file_handler is None:
                PageSpiderStatistics.__v_info_stat_file_handler = open(PageSpiderStatistics.__v_info_stat_file_path,
                                                                       "w+")
            text = ""
            if isinstance(video_data, VideoInfo):
                text = u"""{"url": "%s", "video_info": %s}\n""" % (video_data.url, video_data.dump())
            elif isinstance(video_data, list):
                text = ""
                for v in video_data:
                    text += u"""{"url": "%s", "video_info": %s}\n""" % (v.url, v.dump())

            PageSpiderStatistics.__v_info_stat_file_handler.writelines(text)
            PageSpiderStatistics.__v_info_stat_file_handler.flush()
        except Exception, err:
            log.msg(err.message, level=log.ERROR)
            log.msg(traceback.format_exc(), level=log.ERROR)

    @staticmethod
    def write_insert_sql_stat(sql):
        """将VideoInfo生成的SQL语句写入insert_sql.txt文件中.

        @return: 无.
        """
        if PageSpiderStatistics.__insert_sql_file_path is None:
            directory = SpiderConfig.get_log_output_dir()
            PageSpiderStatistics.__insert_sql_file_path = u"%sinsert_sql.txt" % directory
            if not FileOperator.exist_file(PageSpiderStatistics.__insert_sql_file_path):
                FileOperator.create_file(PageSpiderStatistics.__insert_sql_file_path)
        if PageSpiderStatistics.__insert_sql_file_handler is None:
            PageSpiderStatistics.__insert_sql_file_handler = open(PageSpiderStatistics.__insert_sql_file_path, "w+")

        PageSpiderStatistics.__insert_sql_file_handler.writelines(u"%s\n" % sql)
        PageSpiderStatistics.__insert_sql_file_handler.flush()