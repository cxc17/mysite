# coding=utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.09.03"

from ..util.SQLGenerator import SeedsSpiderSqlGenerator
from TaveenUtil.SpiderConfig import SpiderConfig
from TaveenUtil.Global import Global
from TaveenUtil.Constants import *
from TaveenUtil.Util import OSUtil

from scrapy.spider import log


class SeedsSpiderStatistics(object):
    """种子爬虫的相关数据统计类.

    该类用于统计所有与种子爬虫相关的数据，以便进行改版预警或者是后续数据统计和分析.
    """

    website = ""            # 当前正在统计的website.

    spider_mode = ""        # quick_update, nomal_no_filter, nomal_apply_filter.

    ip = ""                 # 本机IP地址.

    start_time = None       # 本次爬虫启动时的时间.

    time_used = 0           # 本次爬虫执行所用的总时间.

    result_state = "unset"  # 从本次统计结果得出的爬虫执行状态: ok/warning/error/unknown/unset.

    extract_stat = {}       # 种子程序抽取相关的统计信息.

    response_stat = {}      # 种子程序response的统计信息.

    video_stat = {}         # 种子程序抽取到的视频相关的统计信息.

    seeds = None            # 种子程序抽取到的所有种子(与种子文件中的内容一致).

    def __init__(self):
        """初始化所有存储统计数据的对象."""
        for category in CategoryNames:
            self.video_stat[category] = 0
            self.response_stat[category] = 0
            self.extract_stat[category] = {}
            for field in SeedsDataFields:
                self.extract_stat[category][field] = {"count": 0, "total": 0}
        self.response_stat["total"] = 0
        self.video_stat["total"] = 0

    def check_revision(self):
        """[没有用到]检测是否有可能发生了改版."""
        self.result_state = "ok"
        pass

    def write_statistics_to_db(self, write_seeds_data=False):
        """将统计类的信息写入VideoStat数据库中的stat_page_exec表中.

        @param write_seeds_data: 是否把抽取到的所有种子信息也一起写入数据库(默认不写入).
        """
        print u"★STEP INFO★: 将种子程序本次执行的统计信息写入数据库中..."
        sql = SeedsSpiderSqlGenerator.sql_insert_stat_seeds_exec(self, write_seeds_data)
        Global.DbOperator_VideoSpider.update(sql)
        print u"★STEP INFO★: 写入完毕."

    def calculate_statistics(self, seeds):
        """计算爬虫执行的统计信息.

        @param seeds: 种子程序抽取到的所有种子.
        """
        print u"★STEP INFO★: 计算种子程序本次执行的相关统计信息..."
        self.start_time = Global.ProgramStartTimeStr
        self.time_used = Global.ProgramUsedTime
        if self.time_used < 0:
            log.msg(u"Global.ProgramUsedTime在被赋值前被访问!", level=log.WARNING)
        self.website = SpiderConfig.get_website()
        self.ip = OSUtil.get_localhost_ip()
        self.spider_mode = SeedsSpiderStatistics.get_seeds_spider_mode()

        self.seeds = seeds is not None and seeds or {}

        self._calculate_extract_stat()
        self._calculate_video_stat()
        print u"★STEP INFO★: 统计完毕."

    def _calculate_extract_stat(self):
        """[内部调用]计算种子程序抽取相关的统计信息."""
        for category in CategoryNames:
            if category not in self.seeds.keys():
                continue
            for item_key in self.seeds[category].keys():
                item = self.seeds[category][item_key]
                for field in SeedsDataFields:
                    if field not in item.keys():
                        continue
                    text = (u"%s" % item[field]).strip()
                    if text != u"":
                        self.extract_stat[category][field]["count"] += 1
                    self.extract_stat[category][field]["total"] += 1

    def _calculate_video_stat(self):
        """[内部调用]计算种子程序抽取到的视频相关的统计信息."""
        for category in CategoryNames:
            if category not in self.seeds.keys():
                continue
            self.video_stat[category] = len(self.seeds[category])
            self.video_stat["total"] += self.video_stat[category]

    @staticmethod
    def get_seeds_spider_mode():
        """获取当前的spider_mode.

        @return: 返回spider_mode.
        """
        if SpiderConfig.get_is_quick_update():
            return "quick_update"
        elif not SpiderConfig.get_if_apply_seeds_filter():
            return "nomal_no_filter"
        elif SpiderConfig.get_if_apply_seeds_filter():
            return "nomal_apply_filter"
        else:
            return ""