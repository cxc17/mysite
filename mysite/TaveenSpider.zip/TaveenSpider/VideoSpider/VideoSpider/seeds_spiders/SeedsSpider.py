# coding: utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.08.18"

from scrapy.http.request import Request
from scrapy.contrib.spiders import CrawlSpider
from scrapy.spider import log
import traceback
import json
import os
import re

from ..seeds_extractor.SeedsTemplateProcessor import SeedsTemplateProcessor
from ..statistics.SeedsSpiderStatistics import SeedsSpiderStatistics
from TaveenUtil.SpiderConfig import SpiderConfig
from TaveenUtil.FileOperator import FileOperator
from TaveenUtil.Util import RandomUtil
from TaveenUtil.Global import Global
from TaveenUtil.Constants import *


class SeedsSpider(CrawlSpider):
    """种子爬虫程序.

    种子爬虫程序主要是为后续的页面爬虫提供入口的种子，但需要提出的是，种子生成程序本身也是一个爬虫.
    """

    name = "SeedsSpider"                        # 爬虫名称.
    start_urls = ["http://www.baidu.com"]       #

    template_processor = None                   # 种子程序的模板解释器.
    website = ""                                # 当前处理的网站名.
    is_quick_update = True                      # 标识当前是否为快速更新模式(小循环).
    is_apply_seeds_filter = False               # 是否对索引页面应用筛选器.

    max_retry_times = 5                         # 索引页访问出错时最大的重试次数.

    # use as static var.
    seeds = dict()                              # 存储所有从索引页抽取出的种子的容器.

    # use as static var.
    seeds_statistics = SeedsSpiderStatistics()  # 种子程序的数据统计对象.

    def __init__(self, *a, **kw):
        self.website = SpiderConfig.get_website()
        self.is_quick_update = SpiderConfig.get_is_quick_update()
        self.is_apply_seeds_filter = SpiderConfig.get_if_apply_seeds_filter()

        SeedsSpider.seeds = dict()
        for category in CategoryNames:
            SeedsSpider.seeds[category] = dict()

        # initialize seeds template processor.
        self.template_processor = SeedsTemplateProcessor(self.website)
        self.template_processor.load_template("../VideoSpider/VideoSpider/seeds_extractor/%s_seeds.tmplt"
                                              % self.website)
        super(CrawlSpider, self).__init__(*a, **kw)

    def parse(self, response):
        try:
            # 获取basic urls，并将其添加到爬取队列(basic urls是所有筛选项拼接成的索引页面的第一页)。
            if "www.baidu.com" in response.url:
                result = self.template_processor.generate_basic_urls(self.is_quick_update, self.is_apply_seeds_filter)

                # 如果模板的page_type为json，则需要做如下的处理.
                # 该处理的原因是json模式下无法获取页数，只能在模板中指定一个固定值，
                # 但是固定值在所有filter排列组合的情况下会产生数量巨大的链接，
                # 所以需要每页获取到之后yield下一页，而不是根据total_page_count进行yield.
                # 但是这是我们又希望base url能完整的yield到total_page_count的数量以保证种子数的完整，
                # 所以在所有处理的开头先将base url对应的所有页yield出来。
                # P.S.对于其他情况，采取的方式是每页都根据current page count和total page count来yield出所有其他页，
                # 这么做的原因是，会存在一种情况，当页面访问到一定页数后才会出现更多页面。
                # 比如：某网站在第一页只能看到后面30页的链接，但是当访问到30页的时候又会出现后续大于30页的页面链接.
                if self.template_processor.page_type == "json" and not SpiderConfig.get_is_quick_update():
                    for category in CategoryNames:
                        print u"★STEP INFO★ %s -->>> yield all base urls(all pages) %s " % (category, "-"*30)
                        total_page = self.template_processor.extract_page_count(category, response)
                        template_obj = getattr(self.template_processor, category)
                        start_page_count = template_obj["page_count"]["start_page_count"]
                        base_url_pattern = template_obj["base_url"]
                        for i in xrange(start_page_count, total_page+start_page_count):
                            request_url = base_url_pattern.replace("[#PAGE#]", "%s" % i)
                            # 针对腾讯视频的链接是以相位做标志
                            request_url = request_url.replace("[#OFFSET#]", "%s" % str(int(i)*20))
                            matcher = re.compile(ur"\[#PAGE_MOD_(\d+)#\]").search(request_url)  # 针对腾讯视频动漫的链接有取模操作.
                            if matcher:
                                mod_value = matcher.group(1)
                                page_mod_str = matcher.group(0)
                                request_url = request_url.replace(page_mod_str, u"%s" % (i % int(mod_value)))
                            yield Request(url=request_url,
                                          meta={"category": category,
                                                "current_page": i,
                                                "total_page": total_page,
                                                "retry_times": 0,
                                                "url_pattern": base_url_pattern},
                                          callback=self.parse)
                            print u"★STEP INFO★ yield new Request(base_url): %s" % request_url

                for category in CategoryNames:
                    for url in result[category]:
                        start_page_count = getattr(self.template_processor, category)["page_count"]["start_page_count"]
                        request_url = url.replace("[#PAGE#]", "%s" % start_page_count)
                        # 针对腾讯视频的链接是以相位做标志
                        request_url = request_url.replace("[#OFFSET#]", "%s" % str(int(start_page_count)*20))
                        matcher = re.compile(ur"\[#PAGE_MOD_(\d+)#\]").search(request_url)  # 针对腾讯视频动漫的链接有取模操作.
                        if matcher:
                            mod_value = matcher.group(1)
                            page_mod_str = matcher.group(0)
                            request_url = request_url.replace(page_mod_str, u"%s" % (start_page_count % int(mod_value)))
                        yield Request(url=request_url,
                                      meta={"category": category,
                                            "current_page": start_page_count,
                                            "total_page": -1,
                                            "retry_times": 0,
                                            "url_pattern": url},
                                      callback=self.parse)
            else:  # 抓取到第一页后，提取其他页，并抽取视频链接信息.
                category = response.meta["category"]
                template_obj = getattr(self.template_processor, category)
                start_page_count = template_obj["page_count"]["start_page_count"]
                rand_str = RandomUtil.random_str(9)  # 这个random str是一个标记，会随着输出信息一起输出，可方便查看日志。
                print u"-"*100
                print u"★%s★ Processing %s page -->>> %s " % (rand_str, category, response.url)

                # get total page count.
                total_page = response.meta.get("total_page", -1)
                if total_page == -1:  # 此处为-1表示该response是第一页，还没有来得及提取总页数.
                    total_page = self.template_processor.extract_page_count(category, response)
                    if SpiderConfig.get_is_debug():
                        print u"★%s★ total page count(extracted) = %s" % (rand_str, total_page)
                    if total_page < 0:
                        total_page = response.meta.get("current_page", start_page_count)

                # extract video info in current page.
                result_list = self.template_processor.extract_video_info(category, response)
                SeedsSpider.display_video_info_list(result_list, rand_str)
                SeedsSpider.add_video_to_seeds(category=category, video_dict_list=result_list, display_id=rand_str)

                # If Quick Update Mode.
                if SpiderConfig.get_is_quick_update():
                    max_page_cnt = SpiderConfig.get_quick_update_max_page_count()
                    if SpiderConfig.get_is_debug():
                        print u"★%s★ max_page_count(configured) = %s" % (rand_str, max_page_cnt)
                    total_page = int(total_page) > int(max_page_cnt) and max_page_cnt or total_page
                    if SpiderConfig.get_is_debug():
                        print u"★%s★ total page count(final) = %s" % (rand_str, total_page)

                # yield new Requests.
                if self.template_processor.page_type != "json" and response.meta["current_page"] < total_page:
                    for page in xrange(response.meta["current_page"]+1, int(total_page)+1):
                        # print "yield URL = %s" % response.meta["url_pattern"].replace("[#PAGE#]", "%s" % page)
                        request_url = response.meta["url_pattern"].replace("[#PAGE#]", "%s" % page)
                        # 针对腾讯视频的链接是以相位做标志
                        request_url = request_url.replace("[#OFFSET#]", "%s" % str(int(page)*20))
                        matcher = re.compile(ur"\[#PAGE_MOD_(\d+)#\]").search(request_url)  # 针对腾讯视频动漫的链接有取模操作.
                        if matcher:
                            mod_value = matcher.group(1)
                            page_mod_str = matcher.group(0)
                            request_url = request_url.replace(page_mod_str, u"%s" % (page % int(mod_value)))
                        yield Request(url=request_url,
                                      meta={"category": category,
                                            "current_page": page,
                                            "total_page": total_page,
                                            "retry_times": 0,
                                            "url_pattern": response.meta["url_pattern"]},
                                      callback=self.parse)
                    print u"★%s★ yield [%s] new Request(s) from page [%s] to page [%s]." \
                          % (rand_str,
                             int(total_page)-response.meta["current_page"],
                             response.meta["current_page"]+1,
                             int(total_page))
                elif self.template_processor.page_type == "json":  # 如果是json模式则要重新处理page count，不能一下子全部yield.
                    page = response.meta["current_page"]
                    # 只有当当前页抽取到数据时才会yield下一页，否则认为已经没有数据了.
                    if page < total_page and len(result_list) > 0:
                        request_url = response.meta["url_pattern"].replace("[#PAGE#]", "%s" % (page+1))
                        # 针对腾讯视频的链接是以相位做标志
                        request_url = request_url.replace("[#OFFSET#]", "%s" % str(int(page)*20))
                        matcher = re.compile(ur"\[#PAGE_MOD_(\d+)#\]").search(request_url)  # 针对腾讯视频动漫的链接有取模操作.
                        if matcher:
                            mod_value = matcher.group(1)
                            page_mod_str = matcher.group(0)
                            request_url = request_url.replace(page_mod_str, u"%s" % (page % int(mod_value)))
                        yield Request(url=request_url,
                                      meta={"category": category,
                                            "current_page": page+1,
                                            "total_page": total_page,
                                            "retry_times": 0,
                                            "url_pattern": response.meta["url_pattern"]},
                                      callback=self.parse)
                        print u"★%s★ yield new Request(page=%s): %s" % (rand_str, page+1, request_url)

                # statistics.
                SeedsSpider.seeds_statistics.response_stat[category] += 1
                SeedsSpider.seeds_statistics.response_stat["total"] += 1
        except Exception, err:
            print err.message
            log.msg(traceback.format_exc(), level=log.ERROR)
        pass

    @staticmethod
    def add_video_to_seeds(category, video_dict_list, display_id=""):
        """向种子容器中添加种子.

        @param category: 当前待添加的种子所属的category.
        @param video_dict_list: 待添加的种子列表.
        @param display_id: 程序打LOG时的标记(只是为了显示).
        """
        counter = 0
        for video_dict in video_dict_list:
            video_url = video_dict["video_url"]
            if video_url in SeedsSpider.seeds[category]:
                continue
            SeedsSpider.seeds[category][video_url] = video_dict
            counter += 1
            pass
        print u"★%s★ [%s] videos added to seeds list, [%s] reduplicated, [%s] total." \
              % (display_id, counter, len(video_dict_list)-counter, len(video_dict_list))
        pass

    @staticmethod
    def display_video_info_list(video_dict_list, display_id=""):
        """以下面的格式显示video_dict_list中的所有种子.

        @param video_dict_list: 待显示的种子列表.
        @param display_id: 程序打LOG时的标记(只是为了显示).
        """
        if SpiderConfig.get_is_debug():
            for video_dict in video_dict_list:
                print u"★%s★------------------------------" % display_id
                for key in video_dict.keys():
                    print u"☆%s☆     %s -->>> %s" % (display_id, key, video_dict[key])
            print u"☆%s☆------------------------------" % display_id
            print u"★%s★ %s videos extracted." % (display_id, len(video_dict_list))
            print u"☆%s☆------------------------------" % display_id
        pass

    @staticmethod
    def _calculate_seeds_file_statistics(seeds):
        """[内部调用]统计种子文件的信息，并生成报表一并写入种子文件.

        @param seeds: 种子容器.
        """
        # 统计数据 & 生成报表.
        print u"★STATISTICS★: 统计种子数据..."
        statistics = {i: 0 for i in seeds.keys()}
        statistics["total"] = 0
        for category in seeds.keys():
            category_dict = seeds[category]
            print u"★STATISTICS★: %s seeds count = %s" % (category, len(category_dict))
            statistics[category] = len(category_dict)
            statistics["total"] += len(category_dict)
        print u"★STATISTICS★: total seeds count = %s" % statistics["total"]
        statistics["start_time"] = Global.ProgramStartTimeStr
        statistics["finish_time"] = Global.ProgramFinishTimeStr
        statistics["time_used"] = Global.ProgramUsedTime

        return statistics

    @staticmethod
    def write_seeds_file(seeds):
        """将所有写入种子文件中.

        @param seeds: 种子容器.
        """
        statistics = SeedsSpider._calculate_seeds_file_statistics(seeds)
        # 将结果写入种子文件.
        result = {"seeds": seeds, "statistics": statistics}
        text = "%s" % json.dumps(result, ensure_ascii=False, indent=4)
        output_path = SpiderConfig.get_seeds_output_path()
        print u"★STEP INFO★: 写种子文件... -->>> \"%s\"" % os.path.abspath(output_path)
        FileOperator.write_all_text(content=text, file_path=output_path, is_append=False)