# coding=utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.09.27"

from TaveenUtil.FileOperator import FileOperator
from TaveenUtil.SpiderConfig import SpiderConfig
from LogAnalyzerBase import LogAnalyzerBase
from TaveenUtil.Util import DatetimeUtil
from TaveenUtil.Global import Global
from TaveenUtil.Util import SqlUtil
from TaveenUtil.Constants import *

from page_log_util import PageLogSQLUtil

from ..util.VideoInfo import VideoInfo

import traceback
import json
import re


class PageLogAnalyzer(LogAnalyzerBase):
    """对页面爬虫和抽取执行日志分析程序的类.

    该类主要实现从页面爬虫的日志，输出，数据库登记记录等来源分析本次爬虫执行的情况，
    以进行爬虫改版的预警.
    """

    def analyze(self):
        """启动分析程序."""
        print u"%s Start Analyzing Log @ %s %s\n" % (u"*"*50, DatetimeUtil.get_datetime_now_str(), u"*"*50)

        Global.DbOperator_VideoSpider.auto_close = False

        # 查询并分析stat_page_exec表中的执行记录.
        self.write_logger(u"Analyzing execute statistics...", u"info")
        try:
            self._analyze_exec_stat()
        except Exception, err:
            self.write_logger(u"Error occurred when analyzing execute statistics...", u"error")
            self.write_logger(err.message, u"error")
            self.write_logger(traceback.format_exc(), u"error")

        # 分析日志文件.
        if not SpiderConfig.get_is_debug():
            self.write_logger(u"Analyzing log file...", u"info")
            try:
                self._analyze_log_file(log_file_path=u"%s%s_spider.log" % (self.log_dir, self.website))
            except Exception, err:
                self.write_logger(u"Error occurred when analyzing log file...", u"error")
                self.write_logger(err.message, u"error")
                self.write_logger(traceback.format_exc(), u"error")

        # 分析insert_sql文件.
        self.write_logger(u"Analyzing insert_sql file...", u"info")
        try:
            self._analyze_insert_sql_file()
        except Exception, err:
            self.write_logger(u"Error occurred when analyzing insert_sql file...", u"error")
            self.write_logger(err.message, u"error")
            self.write_logger(traceback.format_exc(), u"error")

        # 分析page_extract_stat文件.
        self.write_logger(u"Analyzing page_extract_stat file...", u"info")
        try:
            self._analyze_page_extract_stat_file()
        except Exception, err:
            self.write_logger(u"Error occurred when analyzing page_extract_stat file...", u"error")
            self.write_logger(err.message, u"error")
            self.write_logger(traceback.format_exc(), u"error")

        # 分析v_info_extract_stat文件.
        self.write_logger(u"Analyzing v_info_extract_stat file...", u"info")
        try:
            self._analyze_v_info_extract_stat_file()
        except Exception, err:
            self.write_logger(u"Error occurred when analyzing v_info_extract_stat file...", u"error")
            self.write_logger(err.message, u"error")
            self.write_logger(traceback.format_exc(), u"error")

        # 分析stat_v_change_log记录.
        self.write_logger(u"Analyzing stat_v_change_log...", u"info")
        try:
            self._analyze_v_change_log()
        except Exception, err:
            self.write_logger(u"Error occurred when analyzing 分析stat_v_change_log...", u"error")
            self.write_logger(err.message, u"error")
            self.write_logger(traceback.format_exc(), u"error")

        print u"\n%s End Analyzing Log @ %s %s" % (u"*"*50, DatetimeUtil.get_datetime_now_str(), u"*"*50)

        self.write_info_to_db()
        pass

    def _analyze_exec_stat(self):
        """分析stat_page_exec表中本次页面爬虫执行的数据."""
        # 查询本次种子程序执行时写入的统计数据.
        stat_sql = u"SELECT * FROM stat_page_exec WHERE start_time = '%s' AND website = '%s' AND ip = '%s'" \
                   % (self.start_time, self.website, self.ip)
        self.write_logger(u"  > 查询本次爬虫程序执行的统计信息, SQL = %s" % stat_sql, u"info")
        cur_result = Global.DbOperator_VideoSpider.query(stat_sql)
        if len(cur_result) == 0:
            self.write_logger(u"  > 没有从stat_page_exec表中查询到数据! SQL = %s" % stat_sql, u"error")
        cur_result = cur_result[0]
        self.write_logger(u"  > 查询完毕.", u"info")

        # 查询最近1000条种子程序执行时写入的统计数据(用于对比).
        history_sql = u"select * from stat_page_exec  where start_time < '%s' AND website = '%s' AND spider_mode = " \
                      u"'%s' AND state = 'ok' limit 1000" % (self.start_time, self.website, cur_result["spider_mode"])
        self.write_logger(u"  > 查询最近1000次(小于或等于1000)种子程序执行的统计信息, SQL = %s" % history_sql, u"info")
        history_result = Global.DbOperator_VideoSpider.query(history_sql)
        if len(history_result) == 0:
            self.write_logger(u"  > 没有查询到最近1000条(1条都没有)跟本次执行模式相同的页面爬虫程序执行的统计结果，"
                              u"系统将假设本次页面爬虫的执行为历史上第一次执行.", u"warning")
        self.write_logger(u"  > 查询完毕.", u"info")

        self.write_logger(u"  > 开始分析 scrapy_stat...", u"info")
        # check scrapy_stat.
        #cur_data = json.loads(cur_result["scrapy_stat"])
        # 暂时什么都没写.
        self.write_logger(u"  > 分析完毕.", u"info")
        pass

    def _analyze_log_file(self, log_file_path):
        """分析LOG文件."""
        self._arrange_log_file()

        self.analyze_log_file(log_file_path)
        pass

    def _analyze_insert_sql_file(self):
        """分析insert_sql.txt文件."""
        pass

    def _analyze_page_extract_stat_file(self):
        """分析page_extract_stat.txt文件."""
        path = u"%spage_extract_stat.txt" % self.log_dir
        if not FileOperator.exist_file(path):
            self.write_logger(u"  > page_extract_stat.txt文件路径: %s 不存在!" % path, u"warning")
            return
        objects = []
        _f = open(path, "r")
        # 读出所有的行并实例化成字典.
        for line in _f:
            line = unicode(line)
            data = None
            try:
                data = json.loads(line)
                tmp_dict = {}
                for request in data["new_requests"]:
                    tmp_dict[request["request_url"]] = request
                data["new_requests"] = tmp_dict
            except Exception, err:
                self.write_logger(err.message)
            if data is None:
                continue
            objects.append(data)
        # 处理所有的行(字典).
        # 1. 抽取情况跟数据库中对比.
        # 2. 登记变化.
        # 3. 登记新的抽取情况到数据库中.
        Global.DbOperator_VideoSpider.auto_close = False
        for obj in objects:
            query_sql = u"SELECT * FROM stat_page_extract WHERE website = %s AND response_url = %s" \
                        % (SqlUtil.format_field(self.website, "str"),
                           SqlUtil.format_field(obj["response_url"], "str"))
            query_result = Global.DbOperator_VideoSpider.query(query_sql)
            # 对比数据库中的数据与本次抽取的数据.
            warn = False
            #self.write_logger(u"processing %s" % obj["response_url"])
            if len(query_result) > 0:
                requests = query_result[0]["new_requests"]
                requests = json.loads(requests)
                for request_key in requests:
                    request = requests[request_key]
                    request_url = request["request_url"]
                    page_type = request["meta"].get("page_type", u"")
                    if page_type == PageType.ACTOR_MEDIUM_PAGE or page_type == PageType.ACTOR_PAGE:
                        if SpiderConfig.get_if_extract_video_from_actor_page():
                            if request_url not in obj["new_requests"]:
                                self.write_logger(u"页面『%s』中以前抽取到过链接『%s』，而本次抽取却没有抽取到，"
                                                  u"请确认是否发生了问题." % (obj["response_url"], request_url),
                                                  level="warning")
                                warn = True
                    else:
                        if request_url not in obj["new_requests"]:
                            self.write_logger(u"页面『%s』中以前抽取到过链接『%s』，而本次抽取却没有抽取到，"
                                              u"请确认是否发生了问题." % (obj["response_url"], request_url),
                                              level="warning")
                            warn = True
            if not warn:
                #self.write_logger(u"ok", level="info")
                sql = PageLogSQLUtil.sql_insert_stat_page_extract(self.website, obj)
                Global.DbOperator_VideoSpider.update(sql)
        Global.DbOperator_VideoSpider.auto_close = True
        pass

    def _analyze_v_info_extract_stat_file(self):
        """分析v_info_extract_stat.txt文件."""
        path = u"%sv_info_extract_stat.txt" % self.log_dir
        if not FileOperator.exist_file(path):
            self.write_logger(u"  > v_info_extract_stat.txt文件路径: %s 不存在!" % path, u"warning")
            return
        objects = []
        _f = open(path, "r")
        # 读出所有的行并实例化成字典.
        for line in _f:
            line = unicode(line)
            data = None
            try:
                data = json.loads(line)
            except Exception, err:
                self.write_logger(err.message)
            if data is None:
                continue
            objects.append(data)
        # 处理所有的行(字典).
        # 1. 抽取情况跟数据库中对比.
        # 2. 登记变化.
        # 3. 登记新的抽取情况到数据库中.
        Global.DbOperator_VideoSpider.auto_close = False
        for obj in objects:
            page_type = obj["video_info"].get("page_type", "")
            warn = False
            if page_type == PageType.ALBUM_PAGE:
                sql = u"SELECT * FROM stat_video_album WHERE albumuri = '%s' and website = '%s'" \
                      % (obj["url"], obj["video_info"]["website"])
                db_data = Global.DbOperator_VideoSpider.query(sql)
                #self.write_logger(u"A -->>> %s" % obj["video_info"], level="info")
                #self.write_logger(u"B -->>> %s" % db_data, level="info")
                if len(db_data) > 0:
                    db_data = db_data[0]
                    for field in db_data:
                        if field not in obj["video_info"]:
                            continue
                        if db_data[field] is not None and obj["video_info"][field] is None:
                            self.write_logger(u"页面『%s』中以前抽取到过字段『%s』，其值为『%s』，而本次抽取却没有抽取到，"
                                              u"请确认是否发生了问题." % (obj["url"], field, obj["video_info"][field]),
                                              level="warning")
                            warn = True
                        elif db_data[field] != u"" and obj["video_info"][field] == u"":
                            self.write_logger(u"页面『%s』中以前抽取到过字段『%s』，其值为『%s』，而本次抽取却没有抽取到，"
                                              u"请确认是否发生了问题." % (obj["url"], field, obj["video_info"][field]),
                                              level="warning")
                            warn = True
            elif page_type == PageType.EPISODE_PAGE:
                sql = u"SELECT * FROM stat_video_episode WHERE url = '%s' and website = '%s'" \
                      % (obj["url"], obj["video_info"]["website"])
                db_data = Global.DbOperator_VideoSpider.query(sql)
                if len(db_data) > 0:
                    db_data = db_data[0]
                    for field in db_data:
                        if field not in obj["video_info"]:
                            continue
                        if db_data[field] is not None and obj["video_info"][field] is None:
                            self.write_logger(u"页面『%s』中以前抽取到过字段『%s』，其值为『%s』，而本次抽取却没有抽取到，"
                                              u"请确认是否发生了问题." % (obj["url"], field, obj["video_info"][field]),
                                              level="warning")
                            warn = True
                        elif db_data[field] != u"" and obj["video_info"][field] == u"":
                            self.write_logger(u"页面『%s』中以前抽取到过字段『%s』，其值为『%s』，而本次抽取却没有抽取到，"
                                              u"请确认是否发生了问题." % (obj["url"], field, obj["video_info"][field]),
                                              level="warning")
                            warn = True
            else:
                self.write_logger(u"未预期的page type: %s" % page_type, level="error")
            if not warn:
                #self.write_logger(u"video_info -->>> ok", level="info")
                video_info = VideoInfo.dict_to_video_info(obj["video_info"],
                                                          self.website,
                                                          obj["video_info"]["page_type"])
                sql = PageLogSQLUtil.sql_insert_stat_video_album_or_episode(video_info)
                Global.DbOperator_VideoSpider.update(sql)
        Global.DbOperator_VideoSpider.auto_close = True
        pass

    def _analyze_v_change_log(self):
        """分析VideoStat数据库中的stat_v_change_log表中本次爬虫执行产生的字段变更."""
        pass

    def _arrange_log_file(self):
        try:
            if SpiderConfig.get_is_debug():
                self.write_logger(u"  > debug模式不对LOG文件进行分析.", u"info")
                return
            _f = open(u"%s%s_spider.log" % (self.log_dir, self.website), "r")
            lines = []
            for line in _f:
                lines.append(u"%s" % line)
            _f.close()
            item_blocks = []
            step_info_list = []
            index = 0
            pattern_1 = re.compile(ur"★(.+)★ Processing page (http://.+)")
            pattern_2 = re.compile(ur"★STEP INFO★.+")
            while index < len(lines):
                line = lines[index]
                matcher = pattern_1.search(line)
                if matcher:
                    item = {"display_stamp": matcher.group(1), "url": matcher.group(2), "logs": []}
                    #item["logs"].append(matcher.group())
                    item_blocks.append(item)
                else:
                    matcher = pattern_2.search(line)
                    if matcher:
                        step_info_list.append(matcher.group())
                index += 1
            for item in item_blocks:
                display_stamp = item["display_stamp"]
                index = 0
                while index < len(lines):
                    matcher = re.compile(ur"★%s★.+" % display_stamp).search(lines[index])
                    if matcher:
                        item["logs"].append(matcher.group())
                        lines.pop(index)
                    else:
                        index += 1

            path = u"%s%s_spider_1.log" % (self.log_dir, self.website)
            FileOperator.create_file(path, True)
            _f = open(path, "w+")
            for line in lines:
                _f.writelines(u"%s" % line)
            _f.close()

            path = u"%s%s_spider_2.log" % (self.log_dir, self.website)
            FileOperator.create_file(path, True)
            _f = open(path, "w+")
            for item in item_blocks:
                _f.writelines(u"%s\n" % (u"-"*100))
                for txt in item["logs"]:
                    _f.writelines(u"%s\n" % txt)
            _f.close()
        except Exception, err:
            self.write_logger(u"Error occurred when arranging log file...", u"error")
            self.write_logger(err.message, u"error")
            self.write_logger(traceback.format_exc(), u"error")