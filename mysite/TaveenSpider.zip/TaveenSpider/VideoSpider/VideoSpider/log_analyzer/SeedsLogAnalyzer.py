# coding=utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.09.27"

from TaveenUtil.FileOperator import FileOperator
from TaveenUtil.SpiderConfig import SpiderConfig
from LogAnalyzerBase import LogAnalyzerBase
from TaveenUtil.Util import DatetimeUtil
from TaveenUtil.Global import Global
from TaveenUtil.Constants import *

import traceback
import json


class SeedsLogAnalyzer(LogAnalyzerBase):
    """对种子爬虫执行日志分析程序的类.

    该类主要实现从种子爬虫的日志，输出，数据库登记记录等来源分析本次爬虫执行的情况，
    以进行爬虫改版的预警.
    """

    def analyze(self):
        """启动分析程序."""
        print u"%s Start Analyzing Log @ %s %s\n" % (u"*"*50, DatetimeUtil.get_datetime_now_str(), u"*"*50)

        # 查询并分析stat_seeds_exec表中的执行记录.
        self.write_logger(u"Analyzing execute statistics...", u"info")
        try:
            self._analyze_exec_stat()
        except Exception, err:
            self.write_logger(u"Error occurred when analyzing execute statistics...", u"error")
            self.write_logger(err.message, u"error")
            self.write_logger(traceback.format_exc(), u"error")

        # 分析日志文件.
        if not SpiderConfig.get_is_debug():
            self.write_logger(u"Analyzing log file...", u"info")
            try:
                self._analyze_log_file(log_file_path=u"%s%s_seeds.log" % (self.log_dir, self.website))
            except Exception, err:
                self.write_logger(u"Error occurred when analyzing log file...", u"error")
                self.write_logger(err.message, u"error")
                self.write_logger(traceback.format_exc(), u"error")

        # 分析种子输出文件.
        self.write_logger(u"Analyzing seeds file... ", u"info")
        try:
            self._analyze_seeds_file()
        except Exception, err:
            self.write_logger(u"Error occurred when analyzing seeds file...", u"info")
            self.write_logger(err.message, u"info")
            self.write_logger(traceback.format_exc(), u"info")

        print u"\n%s End Analyzing Log @ %s %s" % (u"*"*50, DatetimeUtil.get_datetime_now_str(), u"*"*50)

        self.write_info_to_db()
        pass

    def _analyze_exec_stat(self):
        """分析stat_seeds_exec表中本次种子爬虫执行的数据."""
        # 查询本次种子程序执行时写入的统计数据.
        stat_sql = u"SELECT * FROM stat_seeds_exec WHERE start_time = '%s' AND website = '%s' AND ip = '%s'" \
                   % (self.start_time, self.website, self.ip)
        self.write_logger(u"  > 查询本次种子程序执行的统计信息, SQL = %s" % stat_sql, u"info")
        cur_result = Global.DbOperator_VideoSpider.query(stat_sql)
        if len(cur_result) == 0:
            self.write_logger(u"  > 没有从stat_seeds_exec表中查询到数据! SQL = %s" % stat_sql, u"error")
        cur_result = cur_result[0]
        self.write_logger(u"  > 查询完毕.", u"info")

        # 查询最近1000条种子程序执行时写入的统计数据(用于对比).
        history_sql = u"select * from stat_seeds_exec  where start_time < '%s' AND website = '%s' AND spider_mode = " \
                      u"'%s' AND state = 'ok' limit 1000" % (self.start_time, self.website, cur_result["spider_mode"])
        self.write_logger(u"  > 查询最近1000次(小于或等于1000)种子程序执行的统计信息, SQL = %s" % history_sql, u"info")
        history_result = Global.DbOperator_VideoSpider.query(history_sql)
        if len(history_result) == 0:
            self.write_logger(u"  > 没有查询到最近1000条(1条都没有)跟本次执行模式相同的种子程序执行的统计结果，"
                              u"系统将假设本次种子执行为历史上第一次执行.", u"warning")
        self.write_logger(u"  > 查询完毕.", u"info")

        # check video_stat.
        self.write_logger(u"  > 开始分析 video_stat...", u"info")
        cur_data = json.loads(cur_result["video_stat"])
        #print json.dumps(cur_data, ensure_ascii=False, indent=4)
        if cur_data["total"] == 0:  # 一个视频链接都没有抽取到，说明肯定存在问题.
            self.write_logger(u"  > 一个视频链接都没有抽取到，请检查原因.", u"error")
        for category in CategoryNames:
            if category not in cur_data:
                continue
            # 如果本次执行对于某一个category一条数据都没有获取到，则与历史记录做对比.
            if cur_data[category] == 0:
                for history_data in history_result:
                    v_stat = json.loads(history_data["video_stat"])
                    if category not in v_stat:
                        self.write_logger(u"    > 从历史记录中发现%s类别不存在." % category, u"info")
                        self.need_notify_developer = True
                        break
                    if v_stat[category] > 0:
                        self.write_logger(u"    > 本次执行中，%s没有抽取到任何视频链接，但是历史记录中抽取到过视频信息."
                                          % category, u"warning")
                        break
        self.write_logger(u"  > 分析完毕.", u"info")

        # check response_stat.
        # 暂时不实现.

        # check extract_stat.
        self.write_logger(u"  > 开始分析 extract_stat... ", u"info")
        cur_data = json.loads(cur_result["extract_stat"])
        #print json.dumps(cur_data, ensure_ascii=False, indent=4)
        for category in cur_data.keys():  # 遍历所有category，每个category下有一套数据.
            item = cur_data[category]
            for key in item.keys():
                if item[key]["count"] == 0:
                    for history_data in history_result:
                        e_stat = json.loads(history_data["extract_stat"])
                        if category not in e_stat:
                            self.write_logger(u"    > 从历史记录中发现%s类别不存在." % category, u"info")
                            break
                        if e_stat[category][key]["count"] > 0:
                            self.write_logger(u"    > 本次执行中，%s没有抽取到任何%s，但是历史记录中抽取到过."
                                              % (category, key), u"warning")
                            break
        self.write_logger(u"  > 分析完毕.", u"info")
        pass

    def _analyze_seeds_file(self):
        """分析种子文件(xxx_seeds.txt)."""
        # check seeds file.
        seeds_file_path = u"%s%s_seeds.txt" % (self.output_dir, self.website)

        text = FileOperator.read_all_text(seeds_file_path)
        data = json.loads(text)
        seeds_data = data["seeds"]
        flag = False
        for category in seeds_data:
            if u"" in seeds_data[category]:
                self.write_logger(u"  > 种子文件中的seeds节点发现key为空字符串的项.", u"error")
                flag = True
            for key in seeds_data[category]:
                item = seeds_data[category][key]
                if item["video_url"].strip() == u"":
                    self.write_logger(u"  > 种子文件中发现空的视频链接: category = %s" % category, u"error")
                    flag = True
        if not flag:
            self.write_logger(u"  > 未发现异常.", u"info")
        pass

    def _analyze_log_file(self, log_file_path):
        """分析种子爬虫的LOG文件."""
        self.analyze_log_file(log_file_path)