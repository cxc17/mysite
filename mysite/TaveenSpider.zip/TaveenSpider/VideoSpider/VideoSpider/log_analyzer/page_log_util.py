# coding=utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.10.14"

from TaveenUtil.Util import SqlUtil
from TaveenUtil.Constants import PageType
from ..util.VideoInfo import VideoInfo

import datetime
import json


class PageLogSQLUtil(object):

    @staticmethod
    def sql_insert_stat_page_extract(website, line_obj):
        time_now = datetime.datetime.now()
        #new_requests = line_obj["new_requests"]
        #new_obj = {}
        #for request in new_requests:
        #    new_obj[request["request_url"]] = request
        #new_request_str = json.dumps(new_obj, ensure_ascii=False)
        new_request_str = json.dumps(line_obj["new_requests"], ensure_ascii=False)
        sql = u"INSERT INTO stat_page_extract(website, response_url, page_type, new_requests, " \
              u"create_time, last_modify) VALUES(%s, %s, %s, %s, %s, %s) " \
              % (SqlUtil.format_field(website, "str"),
                 SqlUtil.format_field(line_obj["response_url"], "str"),
                 SqlUtil.format_field(line_obj["page_type"], "str"),
                 SqlUtil.format_field(new_request_str, "str"),
                 SqlUtil.format_field(time_now, "str"),
                 SqlUtil.format_field(time_now, "str"))
        sql += u"ON DUPLICATE KEY UPDATE website = %s, response_url = %s, page_type = %s, " \
               u"new_requests = %s, last_modify = %s" \
               % (SqlUtil.format_field(website, "str"),
                  SqlUtil.format_field(line_obj["response_url"], "str"),
                  SqlUtil.format_field(line_obj["page_type"], "str"),
                  SqlUtil.format_field(new_request_str, "str"),
                  SqlUtil.format_field(time_now, "str"))
        return sql

    @staticmethod
    def sql_insert_stat_video_album_or_episode(video_info):
        assert isinstance(video_info, VideoInfo)
        if video_info.page_type == PageType.ALBUM_PAGE:
            return PageLogSQLUtil.sql_insert_stat_video_album(video_info)
        elif video_info.page_type == PageType.EPISODE_PAGE:
            return PageLogSQLUtil.sql_insert_stat_video_episode(video_info)
        else:
            raise ValueError(u"未预期的page type: %s" % video_info.page_type)

    @staticmethod
    def sql_insert_stat_video_album(video_info):
        assert isinstance(video_info, VideoInfo)
        datetime_now = datetime.datetime.now()
        sql = u"INSERT INTO stat_video_album(website, title, video_name, othername, category, pay, " \
              u"image, albumuri, actor, director, screenwriter, drama, type, region, year, pubdate, " \
              u"length, curEpisode, rate, valid, quality, isEnd, publish_area, idc, create_time, " \
              u"last_modify) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, " \
              u"%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)" \
              % (SqlUtil.format_field(video_info.website, "str"),
                 SqlUtil.format_field(video_info.title, "str"),
                 SqlUtil.format_field(video_info.video_name, "str"),
                 SqlUtil.format_field(video_info.othername, "str"),
                 SqlUtil.format_field(video_info.category, "str"),
                 SqlUtil.format_field(video_info.pay, "int"),
                 SqlUtil.format_field(video_info.image, "str"),
                 SqlUtil.format_field(video_info.url, "str"),
                 SqlUtil.format_field(video_info.actor, "str"),
                 SqlUtil.format_field(video_info.director, "str"),
                 SqlUtil.format_field(video_info.screenwriter, "str"),
                 SqlUtil.format_field(video_info.drama, "str"),
                 SqlUtil.format_field(video_info.type, "str"),
                 SqlUtil.format_field(video_info.region, "str"),
                 SqlUtil.format_field(video_info.year, "int"),
                 SqlUtil.format_field(video_info.pubdate, "str"),
                 SqlUtil.format_field(video_info.length, "int"),
                 SqlUtil.format_field(video_info.curEpisode, "int"),
                 SqlUtil.format_field(video_info.rate, "float"),
                 SqlUtil.format_field(video_info.valid, "int"),
                 SqlUtil.format_field(video_info.quality, "str"),
                 SqlUtil.format_field(video_info.isEnd, "int"),
                 SqlUtil.format_field(video_info.publish_area, "str"),
                 SqlUtil.format_field(video_info.idc, "str"),
                 SqlUtil.format_field(datetime_now, "str"),
                 SqlUtil.format_field(datetime_now, "str"))
        sql += u"ON DUPLICATE KEY UPDATE website = %s, title = %s, video_name = %s, othername = %s, category = %s, " \
               u"pay = %s, image = %s, albumuri = %s, actor = %s, director = %s, screenwriter = %s, drama = %s, " \
               u"type = %s, region = %s, year = %s, pubdate = %s, length = %s, curEpisode = %s, rate = %s, valid = %s, " \
               u"quality = %s, isEnd = %s, publish_area = %s, idc = %s, last_modify = %s" \
               % (SqlUtil.format_field(video_info.website, "str"),
                  SqlUtil.format_field(video_info.title, "str"),
                  SqlUtil.format_field(video_info.video_name, "str"),
                  SqlUtil.format_field(video_info.othername, "str"),
                  SqlUtil.format_field(video_info.category, "str"),
                  SqlUtil.format_field(video_info.pay, "int"),
                  SqlUtil.format_field(video_info.image, "str"),
                  SqlUtil.format_field(video_info.url, "str"),
                  SqlUtil.format_field(video_info.actor, "str"),
                  SqlUtil.format_field(video_info.director, "str"),
                  SqlUtil.format_field(video_info.screenwriter, "str"),
                  SqlUtil.format_field(video_info.drama, "str"),
                  SqlUtil.format_field(video_info.type, "str"),
                  SqlUtil.format_field(video_info.region, "str"),
                  SqlUtil.format_field(video_info.year, "int"),
                  SqlUtil.format_field(video_info.pubdate, "str"),
                  SqlUtil.format_field(video_info.length, "int"),
                  SqlUtil.format_field(video_info.curEpisode, "int"),
                  SqlUtil.format_field(video_info.rate, "float"),
                  SqlUtil.format_field(video_info.valid, "int"),
                  SqlUtil.format_field(video_info.quality, "str"),
                  SqlUtil.format_field(video_info.isEnd, "int"),
                  SqlUtil.format_field(video_info.publish_area, "str"),
                  SqlUtil.format_field(video_info.idc, "str"),
                  SqlUtil.format_field(datetime_now, "str"))
        return sql

    @staticmethod
    def sql_insert_stat_video_episode(video_info):
        assert isinstance(video_info, VideoInfo)
        datetime_now = datetime.datetime.now()
        sql = u"INSERT INTO stat_video_episode(website, url, video_name, category, year, no, " \
              u"director, actor, isValidURL, guests, album_id, idc, create_time, last_modify) " \
              u"VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)" \
              % (SqlUtil.format_field(video_info.website, "str"),
                 SqlUtil.format_field(video_info.url, "str"),
                 SqlUtil.format_field(video_info.title, "str"),
                 SqlUtil.format_field(video_info.category, "str"),
                 SqlUtil.format_field(video_info.year, "int"),
                 SqlUtil.format_field(video_info.no, "int"),
                 SqlUtil.format_field(video_info.director, "str"),
                 SqlUtil.format_field(video_info.actor, "str"),
                 SqlUtil.format_field(video_info.valid, "int"),
                 SqlUtil.format_field(video_info.guests, "str"),
                 SqlUtil.format_field(video_info.album_id, "str"),
                 SqlUtil.format_field(video_info.idc, "str"),
                 SqlUtil.format_field(datetime_now, "str"),
                 SqlUtil.format_field(datetime_now, "str"))
        sql += u"ON DUPLICATE KEY UPDATE website = %s, url = %s, video_name = %s, category = %s, year = %s, " \
               u"no = %s, director = %s, actor = %s, isValidURL = %s, guests = %s, album_id = %s, idc = %s, " \
               u"last_modify = %s" \
               % (SqlUtil.format_field(video_info.website, "str"),
                  SqlUtil.format_field(video_info.url, "str"),
                  SqlUtil.format_field(video_info.title, "str"),
                  SqlUtil.format_field(video_info.category, "str"),
                  SqlUtil.format_field(video_info.year, "int"),
                  SqlUtil.format_field(video_info.no, "int"),
                  SqlUtil.format_field(video_info.director, "str"),
                  SqlUtil.format_field(video_info.actor, "str"),
                  SqlUtil.format_field(video_info.valid, "int"),
                  SqlUtil.format_field(video_info.guests, "str"),
                  SqlUtil.format_field(video_info.album_id, "str"),
                  SqlUtil.format_field(video_info.idc, "str"),
                  SqlUtil.format_field(datetime_now, "str"))
        return sql