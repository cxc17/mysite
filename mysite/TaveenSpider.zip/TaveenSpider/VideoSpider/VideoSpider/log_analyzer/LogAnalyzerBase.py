# coding=utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.09.27"

from TaveenUtil.FileOperator import FileOperator
from TaveenUtil.SpiderConfig import SpiderConfig
from TaveenUtil.Global import Global
from TaveenUtil.Util import *

import traceback
import logging
import sys
import re


class LogAnalyzerBase(object):
    """对爬虫执行日志分析程序的基类.

    该类及其子类主要实现从爬虫的日志，输出，数据库登记记录等来源分析本次爬虫执行的情况，
    以进行爬虫改版的预警.
    """

    # 标记是否需要通知开发人员关注本次日志.
    need_notify_developer = None

    # 日志类对象.
    logger = None

    # 各种日志格式的正则表达式(use as static var).
    log_critical_error_pattern = re.compile(ur"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\+\d{4} \[.+\] *CRITICAL")
    log_error_pattern = re.compile(ur"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\+\d{4} \[.+\] *ERROR")
    log_warning_pattern = re.compile(ur"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\+\d{4} \[.+\] *WARNING")

    log_result = {"info": 0, "debug": 0, "warning": 0, "error": 0, "fatal": 0}

    def __init__(self, spider_type, start_time, website, ip, log_dir, output_dir):
        """初始化日志分析程序的实例.

        @param spider_type: 当前的spider(种子爬虫还是页面爬虫).
        @param start_time: 程序启动的时间(查询数据库的重要依据).
        @param website: 当前正在处理的网站名.
        @param ip: 本机的ip地址.
        @param log_dir: 日志文件输出的目录.
        @param output_dir: 数据文件输出的目录.
        """
        self.need_notify_developer = False
        # 还原对标准输出流的重定向.
        sys.stdout = sys.__stdout__
        sys.stderr = sys.__stderr__

        # 初始化参数.
        self.spider_type = spider_type
        self.start_time = start_time
        self.website = website
        self.log_dir = log_dir
        self.output_dir = output_dir
        self.ip = ip
        self.analyzer_log_path = u"%slog_analyzer.log" % log_dir

        # 重定向LOG.
        try:
            # 设置LOG.
            formatter = logging.Formatter("%(asctime)s %(levelname)-8s: %(message)s")
            self.logger = logging.getLogger('')
            if not SpiderConfig.get_is_debug():
                # 重定向输出流.
                self.__f_handler = None
                if not FileOperator.exist_file(os.path.abspath(self.analyzer_log_path)):
                    FileOperator.create_file(file_path=os.path.abspath(self.analyzer_log_path),
                                             override_if_exists=False)
                self.__f_handler = open(self.analyzer_log_path, "a")
                sys.stdout = self.__f_handler
                sys.stderr = self.__f_handler

                handler = logging.StreamHandler(sys.stdout)
                handler.setFormatter(formatter)
                self.logger.setLevel(SpiderConfig.get_log_level())
                self.logger.addHandler(handler)
            else:
                console = logging.StreamHandler()
                console.setLevel(SpiderConfig.get_log_level())
                console.setFormatter(formatter)
                self.logger.addHandler(console)
                self.__f_handler = None
                if not FileOperator.exist_file(os.path.abspath(self.analyzer_log_path)):
                    FileOperator.create_file(file_path=os.path.abspath(self.analyzer_log_path),
                                             override_if_exists=False)
                self.__f_handler = open(self.analyzer_log_path, "w")
                sys.stdout = self.__f_handler
                sys.stderr = self.__f_handler
        except Exception, err:
            self.logger.error(u"%s\n%s" % (err.message, traceback.format_exc()))
            self.need_notify_developer = True
        pass

    def analyze(self):
        """启动分析程序.

        所有的子类必须重写该函数.
        """
        raise NotImplementedError()
        pass

    def write_info_to_db(self):
        """在分析程序结束后，将分集的结果写入数据库stat_spider_warning表中(需要在分析程序的最后调用该函数)."""
        if self.log_result["warning"] > 0 or self.log_result["error"] > 0 or self.log_result["fatal"] > 0:
            self.need_notify_developer = True

        if self.need_notify_developer:
            if self.__f_handler is not None:
                self.__f_handler.flush()
            description = ""
            try:
                if FileOperator.exist_file(self.analyzer_log_path):
                    description = FileOperator.read_all_text(self.analyzer_log_path)
                    if len(description) > 10000:
                        description = description[0:10000]
                else:
                    description = u"未发现LogAnalyzer程序产生的LOG文件，可能本次执行是调试模式."
            except Exception, err:
                self.logger.error(u"%s\n%s" % (err.message, traceback.format_exc()))

            try:
                from ..util.SQLGenerator import LogAnalyzerSqlGenerator
                sql = LogAnalyzerSqlGenerator.sql_insert_warning_info(self.start_time,
                                                                      self.website,
                                                                      self.spider_type,
                                                                      self.ip,
                                                                      description,
                                                                      os.path.abspath(self.log_dir))
                #print sql
                Global.DbOperator_VideoSpider.update(sql)
            except Exception, err:
                self.logger.error(u"%s\n%s" % (err.message, traceback.format_exc()))
            pass
        pass

    def write_logger(self, description=u"", level=u"info"):
        level = level.lower().strip()
        if level == u"info":
            self.logger.info(description)
            self.log_result["info"] += 1
        elif level == u"debug":
            self.logger.debug(description)
            self.log_result["debug"] += 1
        elif level == u"warning" or level == u"warn":
            self.logger.warn(description)
            self.log_result["warning"] += 1
        elif level == u"error" or level == u"err":
            self.logger.error(description)
            self.log_result["error"] += 1
        elif level == u"fatal" or level == u"critical":
            self.logger.fatal(description)
            self.log_result["fatal"] += 1
        else:
            self.logger.error(u"不识别的log level: %s" % level)

    def analyze_log_file(self, log_file_path):
        """分析LOG文件."""
        if SpiderConfig.get_is_debug():
            self.write_logger(u"  > debug模式不对LOG文件进行分析.", u"info")
            return

        log_critical_error = {}
        log_error = {}
        other_error = {}
        log_warning = {}
        other_warning = {}

        # check log file.
        self.write_logger(u"  > Start reading log file...", u"info")
        if not FileOperator.exist_file(log_file_path):
            self.write_logger(u"  > LOG文件路径: %s 不存在!" % log_file_path, u"warning")
            return
        _f = open(log_file_path, "r")
        line_num = 1
        for line in _f:
            line = (u"%s" % line).replace(u"\n", u"")
            matcher = self.log_critical_error_pattern.search(line)  # log_critical_error.
            if matcher:
                log_critical_error[u"%s" % line_num] = line
            else:
                matcher = self.log_error_pattern.search(line)  # log_error.
                if matcher:
                    log_error[u"%s" % line_num] = line
                else:
                    matcher = self.log_warning_pattern.search(line)  # log_warning.
                    if matcher:
                        log_warning[u"%s" % line_num] = line
                    else:
                        line_lower = line.lower()
                        if u"warning" in line_lower:  # other_error.
                            other_warning[u"%s" % line_num] = line
                        if u"error" in line_lower:  # other_warning.
                            other_error[u"%s" % line_num] = line
            line_num += 1
        _f.close()
        self.write_logger(u"  > End reading log file.", u"info")
        # 展示错误信息和严重错误信息.
        if len(log_critical_error) > 0 or len(log_error) > 0 or len(other_error) > 0:
            self.write_logger(u"  > 错误信息如下:", u"info")
            for key in log_critical_error:
                self.write_logger(u"    > [%s] -->>> %s" % (key, log_critical_error[key]), u"fatal")
            for key in log_error:
                self.write_logger(u"    > [%s] -->>> %s" % (key, log_error[key]), u"error")
            for key in other_error:
                self.write_logger(u"    > [%s] -->>> %s" % (key, other_error[key]), u"error")
        else:
            self.write_logger(u"  > 未发现错误信息.", u"info")
        # 展示警告信息.
        if len(log_warning) > 0 or len(other_warning) > 0:
            self.write_logger(u"  > 警告信息如下:", u"info")
            for key in log_warning:
                self.write_logger(u"    > [%s] -->>> %s" % (key, log_warning[key]), u"warning")
            for key in other_warning:
                self.write_logger(u"    > [%s] -->>> %s" % (key, other_warning[key]), u"warning")
        else:
            self.write_logger(u"  > 未发现警告信息.", u"info")
        pass