#coding:utf-8
__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.08.18"

import traceback
import urllib
import json
import os

from scrapy.contrib.spiders import CrawlSpider
from scrapy.http import Request
from scrapy.spider import log

from TaveenUtil.FileOperator import FileOperator
from TaveenUtil.SpiderConfig import SpiderConfig
from TaveenUtil.Util import RandomUtil
from TaveenUtil.Global import Global
from TaveenUtil.Constants import *

from ..videoinfo_extractor.VideoInfoExtractProcessor import VideoInfoExtractProcessor
from ..videoinfo_extractor.VideoInfoExtractTemplate import VideoInfoExtractTemplate
from ..statistics.PageSpiderStatistics import PageSpiderStatistics
from ..util.SQLGenerator import VideoInfoSqlGenerator
from ..items.VideoInfoItem import VideoInfoItem
from ..util.VideoInfoUtil import VideoInfoUtil
from ..util.VideoData import VideoData


class PageSpider(CrawlSpider):
    """页面爬虫程序.

    """

    name = "PageSpider"                    # 爬虫名称.
    #start_urls = ["http://www.youku.com/show_page/id_zfceaf4bcd00611e3a705.html",
    #              "http://www.youku.com/show_page/id_z7dabff26832511e38b3f.html",
    #              "http://www.youku.com/show_page/id_zf293ca8e41db11e38b3f.html",
    #              "http://www.youku.com/show_page/id_zcc003400962411de83b1.html"]

    start_urls = ["http://www.baidu.com"]  #

    template = None                        # 视频信息抽取XML模板对象.
    processor = None                       # 视频信息抽取解释器对象.

    # use as static var.
    AlbumAllMd5 = set()                    # 存储所有专辑的idc字段值.
    EpisodeAllMd5 = set()                  # 存储所有分集的idc字段值.
    statistics = PageSpiderStatistics()    # 页面爬虫程序的数据统计对象.

    def __init__(self):
        """初始化页面爬虫的实例."""
        self.website = SpiderConfig.get_website()
        self.is_debug_mode = SpiderConfig.get_is_debug()
        self.is_quick_update = SpiderConfig.get_is_quick_update()
        self.extract_video_from_actor_page = SpiderConfig.get_if_extract_video_from_actor_page()

        # initialize page spider template & processor(new solution).
        self.template = VideoInfoExtractTemplate(u"../VideoSpider/VideoSpider/videoinfo_extractor/%s_video_info.tmplt"
                                                 % self.website)
        self.processor = VideoInfoExtractProcessor(self.website, self.template)
        pass

    def parse(self, response):
        #video_info_list = self.processor.extract(response.url, response.body, response.meta)
        #for video_info in video_info_list:
        #    print video_info.dump()
        #return
        display_stamp = RandomUtil.random_str(8)
        print u"★%s★ Processing page %s" % (display_stamp, response.url)
        try:
            if u"www.baidu.com" in response.url:
                ## debug test.
                #yield Request(url="http://www.youku.com/show_page/id_z69720cd43d5c11e4a080.html",
                #              meta={"category": "variety"},
                #              callback=self.parse)
                #return
                ## end of debug test.
                seeds = PageSpider.load_seeds_file()
                #print json.dumps(seeds, ensure_ascii=False)
                for block_key in seeds.keys():
                    item = seeds[block_key]
                    meta = {}  # 将从种子来的附加信息附加给产生的Request.
                    for key in item.keys():
                        meta[key] = item[key]
                    meta["page_type"] = PageType.UNKNOWN_PAGE

                    # Added by chjchen on 2015.04.30
                    # 这里的思路是这样，判断一个页面的种子是来自哪一家网站
                    # 如果是qq视频或者tudou，那么就在meta信息表里面再添加一个字段flag_db，表示是否将这个数据写入数据库
                    # 如果是首页抓到的种子，都会进行跳转到某一个播放页，那么就将flag_db置为0，反置为1
                    # 置为1的代码在else里面
                    if self.website == "qq" or self.website == "tudou":
                        meta["flag_db"] = 0
                        print "first #########"
                    # End of add on 2015.04.30 by chjchen

                    yield Request(url=item["video_url"], meta=meta, callback=self.parse)
                pass
            else:
                response_url = response.url.strip()
                page_type = response.meta.get("page_type", "")
                exec(u"from ..page_extractor.%sExtractor import %sExtractor" % (self.website, self.website))
                extractor_class = eval(u"%sExtractor" % self.website)
                new_requests = extractor_class.extract(response)

                # Added by chjchen on 2015.04.30
                # 这段代码是用来调试的，目的就是看标志位是否符合要求
                if self.website == "qq":
                    print "##########!!!"
                    print str(response.meta["flag_db"]) + "===" + str(response.url)
                # End of Add by chjchen on 2015.04.30

                # 检查返回值(new_requests)的结构是否符合要求.
                self.check_new_requests_structure(response, new_requests, display_stamp)

                # 检查返回值(new_requests)列表中的每一个新链接的内容是否符合要求.
                self.check_new_requests_value(response, new_requests, display_stamp)

                # 从数据库中取出当前的剧集的所有分集.
                #for tmp in new_requests:
                #    for k,v in tmp.items():
                #        print str(k) + "@#$%" + str(v)
                urls = set()
                try:
                    for request in new_requests:
                        if request["meta"].get("page_type", "") == PageType.EPISODE_PAGE:
                            if request["meta"].get("album_id", None) is not None:
                                sql = VideoInfoSqlGenerator\
                                    .sql_query_episode_urls_by_album(self.website, request["meta"]["album_id"])
                                urls = Global.DbOperator_VideoBasic.query(sql)
                                urls = set([row["url"] for row in urls])
                            else:
                                log.msg(u"从 %s 提取出的分集链接 %s 的meta附加信息中没有找到album信息."
                                        % (response_url, request["request_url"]), level=log.WARNING)
                except Exception, err:
                    print err.message
                    log.msg(traceback.format_exc(), level=log.ERROR)

                # yield新的链接.
                for request in new_requests:
                    request_url = request["request_url"]
                    if request_url.strip() == u"":
                        log.msg(u"★%s★ 从页面中抽取链接时抽取到空链接，请检查原因! referer = %s" % (display_stamp, response.url),
                                level=log.ERROR)
                        continue
                    # 排除以前曾经爬取过的xx_url表链接，以实现增量爬取.
                    if request["meta"].get("page_type", "") == PageType.EPISODE_PAGE:
                        if request_url in urls:
                            print u"★%s★ Ignore url = %s" % (display_stamp, request_url)
                            continue

                    # 补充meta信息.
                    if page_type != PageType.ACTOR_PAGE and page_type != PageType.ACTOR_MEDIUM_PAGE:
                        self.makeup_meta_info(response.meta, request["meta"], display_stamp)
                    if True:  # self.is_quick_update
                        print u"★%s★ yield request = %s" % (display_stamp, request_url)
                    #print str(request_url) + "request_url======="

                    # Added by chjchen on 2015.04.30
                    # 这段代码也和上面if里面的flag_db标志的meta信息相对应
                    if self.website == "qq" or self.website == "tudou":
                        request["meta"]["flag_db"] = 1
                        print "yield new #########"
                    # End of add by chjchen on 2015.04.30

                    yield Request(url=request_url, meta=request["meta"], callback=self.parse)

                # 抽取视频信息(VideoInfo).
                content_type = response.headers.get("Content-Type", u"").lower()
                encoding = u""
                for enc in [u"utf8", u"utf-8", u"gbk", u"gb2312"]:
                    if enc in content_type:
                        encoding = enc
                        break
                response.meta["page_encoding"] = encoding

                video_info_list = self.processor.extract(response.url, response.body, response.meta)
                #video_info_list = []
                # 将video_info写入本地文件，作为日志以便后续的日志分析和改版预警.
                # 之所以写在这里是因为此处的video_info还没有做专辑页和分集页之间的信息互补，最接近抽取的原始数据.
                PageSpider.statistics.write_v_info_stat(video_info_list)
                for video_info in video_info_list:
                    print u"★%s★ VideoInfo = %s" % (display_stamp, video_info.dump())


                # 将视频信息循环yield到pipelines中.
                # Modified by chjchen on 2015.04.30
                # 这里做出了如下修改
                # 之前的if和else里面对每一个新yield的url都在meta信息表里面添加了flag_db这个字段
                # 如果这个flag_db字段等于1，那么就说明这条数据需要写入到数据库中
                # 如果这个flag_db字段等于0，那么就说明这条数据是从列表直接点开得到的播放页，然而这个播放页成为了一个种子
                if (self.website == "qq" and response.meta["flag_db"] == 0) or \
                   (self.website == "tudou" and response.meta["flag_db"] == 0):
                    pass
                else:
                    for video_info in video_info_list:
                        # 检查视频信息的各个字段是否合法
                        if VideoInfoUtil.is_rubbish(video_info.title):
                            print u"★%s★ Filter rubbish video info = %s" % (display_stamp, video_info.url)
                            continue
                        #l = VideoData.get_video_info_list(video_info)
                        #for v in l:
                        #    item = VideoInfoItem()
                        #    item["video_url"] = v.url
                        #    item["video_info"] = v
                        #    print u"★%s★ yield item = %s" % (display_stamp, v.dump())
                        #    yield item
                        flag = VideoInfoUtil.check_necessary_field(video_info)
                        if flag:
                            l = VideoData.get_video_info_list(video_info)
                            for v in l:
                                item = VideoInfoItem()
                                item["video_url"] = v.url
                                item["video_info"] = v
                                print u"★%s★ yield item = %s" % (display_stamp, v.dump())
                                yield item
                # End of modify by chjchen on 2015.04.30

                # 写统计信息.
                PageSpiderStatistics.write_extract_stat(response, response.meta.get("page_type", ""), new_requests)
                pass
            if False:
                path = u"%s/files/%s" % ((os.path.abspath(SpiderConfig.get_log_output_dir())),
                                         urllib.quote(response.url))
                if path.endswith("/"):
                    path = path[0:len(path)-1]
                FileOperator.write_all_text(path, response.body, is_append=False)

        except Exception, err:
            print u"%s Error when processing %s" % (err.message, response.url)
            log.msg(traceback.format_exc(), level=log.ERROR)
        pass

    @staticmethod
    def load_seeds_file():
        """从种子文件中加载所有种子.

        @return: 返回包含所有种子的容器(字典).
        """
        file_path = SpiderConfig.get_seeds_output_path()
        print u"★STEP INFO★: Loading Seeds File: \"%s\"." % os.path.abspath(file_path)
        text = FileOperator.read_all_text(file_path)
        _seeds = json.loads(text)["seeds"]

        for category in _seeds.keys():
            for block_key in _seeds[category].keys():
                item = _seeds[category][block_key]
                item["category"] = category
        seeds = {}
        for category in _seeds.keys():
            seeds = dict(seeds, **_seeds[category])
        print u"★STEP INFO★: Seeds count = %s" % len(seeds)
        return seeds

    def makeup_meta_info(self, meta_from, meta_to, display_stamp=""):
        """将meta_from的meta信息补充到meta_to中.

        @param meta_from: 从meta_from中读取字段.
        @param meta_to: 补充到meta_to中.
        @param display_stamp: 用来显示的标记(仅用于显示).
        """
        if self.is_debug_mode:
            print u"★%s★ 补充meta信息: from = %s\n                       to = %s" \
                  % (display_stamp, json.dumps(meta_from, ensure_ascii=False), json.dumps(meta_to, ensure_ascii=False))

        for key in meta_from.keys():
            if key in ["download_latency", "download_timeout", "depth", "download_slot", "page_type"]:
                continue
            if key.startswith(u"_"):
                continue
            if meta_to.get(key, None) is None:
                meta_to[key] = meta_from[key]
            else:
                value = meta_to[key]
                if (isinstance(value, str) or isinstance(value, unicode)) and \
                        VideoInfoUtil.string_denoising(value) == u"":
                    meta_to[key] = meta_from[key]
        if self.is_debug_mode:
            print u"%sresult = %s" % (u" "*23, json.dumps(meta_to, ensure_ascii=False))
        pass

    def check_new_requests_structure(self, response, new_requests, display_stamp):
        """检查页面爬虫的抽取器抽取出新的待爬取的链接列表(new_requests)的结构的合法性.

        不合法的结构会以log的形式输出.

        @param response: 当前页面的response对象.
        @param new_requests: 页面爬虫抽取器抽取出的新的待爬链接的列表.
        @param display_stamp: 用来显示的标记(仅用于显示).
        """
        # check return value.
        usage_tip = u"""
            %sExtractor.extract函数的返回值必须是一个list，list中的每个元素是一个dict;dict中比须有key为"request_url"
            的字符串和一个key为"meta"的字典，meta字典用来存储于request相关的键值信息.""" % self.website
        if not isinstance(new_requests, list):
            raise ValueError(usage_tip)

        #for tmp in new_requests:
        #    if tmp["request_url"] is None:
        #        new_requests.remove(tmp)

        for request in new_requests:
            if not isinstance(request, dict) or request.get("request_url", None) is None \
                    or not isinstance(request.get("meta", None), dict):
                log.msg(usage_tip, level=log.ERROR)

            # Added by chjchen on 2015.05.06
            # 这里为tudou增加了这样一个过滤条件，判断request["request_url"]是不是一个None
            if request["request_url"] is None and self.website == "tudou":
                log.msg(u"request[\"request_url\"]为None对象，将其过滤", level=log.ERROR)
                continue
            # End of Add by chjchen on 2015.05.06

            # request_url必须存在且为有效值.
            if request["request_url"].strip() == u"":
                log.msg(u"★%s★ request_url的值不能为空! referer = make-up%s" % (display_stamp, response.url),
                        level=log.ERROR)
            # meta.pate_type必须存在且为有效值.
            if request["meta"].get("page_type", "") not in PageType.PageTypeNames:
                log.msg(u"★%s★ meta.page_type必须存在且为有效值，当前为：%s; referer = %s"
                        % (display_stamp, request["meta"].get("page_type", ""), response.url), level=log.ERROR)
            # meta.category在不是actor相关链接时category必须为有效值.
            if request["meta"].get("page_type", "") != PageType.ACTOR_PAGE and \
                    request["meta"].get("page_type", "") != PageType.ACTOR_MEDIUM_PAGE:
                if request["meta"].get("category", None) is None:
                    log.msg(u"★%s★ meta.category必须存在且为有效值，当前为: %s; referer = %s"
                            % (display_stamp, request["meta"].get("category", None), response.url), level=log.ERROR)
        # end of check.

    def check_new_requests_value(self, response, new_requests, display_stamp):
        # TODO 检查episode链接必须有album_id链接.
        pass