-- --------------------------------------------------
-- 时间: 2014.09.25.
-- 作者: HuangGK.
-- 用途: stat_page_exec表用来登记页面爬虫的每次执行.
-- --------------------------------------------------

CREATE TABLE `stat_page_exec` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,    -- 自增ID
  `start_time` datetime NOT NULL,                   -- 程序启动时间
  `website` varchar(10) NOT NULL,                   -- 当前网站名称
  `ip` varchar(20) DEFAULT NULL,                    -- 执行程序的机器ip地址
  `time_used` int(10) unsigned DEFAULT 0,           -- 程序执行所用时间
  `spider_mode` varchar(20) NOT NULL,               -- 种子程序的执行模式: quick_update/nomal/nomal_extract_actor
  `state` varchar(20) DEFAULT NULL,                 -- 程序执行结果状态: ok/warning/error/unknown/unset

  `scrapy_stat` text,                               -- scrapy自己的状态统计信息

  `create_time` datetime NOT NULL,                  -- 数据插入时间
  `modify_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_key` (`start_time`,`website`, `ip`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;