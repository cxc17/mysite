CREATE TABLE `stat_page_extract` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `website` varchar(20) NOT NULL,

  `response_url` varchar(255) NOT NULL,
  `page_type` varchar(20) NOT NULL,
  `new_requests` text,

  `create_time` datetime DEFAULT NULL,
  `last_modify` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `website_response_url` (`website`, `response_url`)
) ENGINE=InnoDB AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;