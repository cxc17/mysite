CREATE TABLE `stat_url_check_result` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `website` varchar(10) NOT NULL,
  `page_type` varchar(50) NOT NULL,
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `original_state` varchar(50) DEFAULT NULL,
  `new_state` varchar(50) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `insert_time` datetime NOT NULL,
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
  -- UNIQUE KEY `unique_key` (`website`,`page_type`,`url`, `insert_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;