-- --------------------------------------------------
-- 时间: 2014.09.25.
-- 作者: HuangGK.
-- 用途: stat_seeds_exec表用来登记种子爬虫的每次执行，并写入爬虫执行的一些统计结果.
-- --------------------------------------------------

CREATE TABLE `stat_seeds_exec` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,    -- 自增ID
  `start_time` datetime NOT NULL,                   -- 程序启动时间
  `time_used` int(10) unsigned DEFAULT 0,           -- 程序执行所用时间
  `website` varchar(10) NOT NULL,                   -- 当前网站名称
  `spider_mode` varchar(20) NOT NULL,               -- 种子程序的执行模式: quick_update/nomal_no_filter/nomal_apply_filter
  `state` varchar(20) DEFAULT NULL,                 -- 程序执行结果状态: ok/warning/error/unknown/unset
  `ip` varchar(20) DEFAULT NULL,                    -- 执行程序的机器ip地址
  
  `video_stat` text,                                -- 所有video的统计信息
  `response_stat` text,                             -- 所有response的统计信息
  `extract_stat` text,                              -- 所有抽取结果的统计信息
  `seeds_data` longtext,                            -- 种子统计信息
    
  `last_modified` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,    -- 数据更新/插入时间
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_key` (`start_time`,`website`, `ip`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;