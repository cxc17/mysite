-- --------------------------------------------------
-- 时间: 2014.09.25.
-- 作者: HuangGK.
-- 用途: stat_spider_warning表用来记录爬虫抽取到的视频信息与已有视频信息中各字段发生的字段变更.
-- --------------------------------------------------

CREATE TABLE `stat_v_change_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,    -- 自增ID
  `start_time` datetime NOT NULL,                   -- 程序启动时间
  `website` varchar(10) NOT NULL,                   -- 当前网站名称
  `page_type` varchar(10) NOT NULL,                 -- 当前数据的页面类型: album/episode
  `url` varchar(255) NOT NULL,                      -- 当前数据的url
  `ip` varchar(20) DEFAULT NULL,                    -- 执行程序的机器ip地址

  `change_stat` text DEFAULT NULL,                  -- 视频信息变化统计

  `last_modified` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,    -- 数据更新/插入时间
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_key` (`start_time`,`website`, `page_type`, `url`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;