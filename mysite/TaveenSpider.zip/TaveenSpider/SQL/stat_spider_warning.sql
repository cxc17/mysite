-- --------------------------------------------------
-- 时间: 2014.09.25.
-- 作者: HuangGK.
-- 用途: stat_spider_warning表用来存储LOG分析程序分析到的警告和错误信息.
-- --------------------------------------------------

CREATE TABLE `stat_spider_warning` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,    -- 自增ID
  `start_time` datetime NOT NULL,                   -- 程序启动时间
  `website` varchar(10) NOT NULL,                   -- 当前网站名称
  `spider_type` varchar(20) NOT NULL,               -- SpiderType
  `ip` varchar(20) DEFAULT NULL,                    -- 执行程序的机器ip地址

  `description` text,                               -- 错误/警告的摘要信息.
  `log_dir` varchar(255) NOT NULL,                  -- 日志文件的路径.

  `last_modified` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_key` (`start_time`,`website`, `spider_type`, `ip`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;