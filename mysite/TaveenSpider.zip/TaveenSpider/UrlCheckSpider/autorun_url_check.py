#coding:utf-8

__author__ = 'HuangGK'


if __name__ == "__main__":
    websites = ["youku", "tudou", "qiyi", "qq", "letv", "sohu"]

    for website in websites:
        command = u"python url_check_starter.py %s" % website
        import os
        os.system(command)