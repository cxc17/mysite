# Scrapy settings for UrlCheckSpider project
#
# For simplicity, this file contains only the most important settings by
# default. All the other settings are documented here:
#
#     http://doc.scrapy.org/en/latest/topics/settings.html
#

BOT_NAME = 'TAVEEN_URLCHECK_SPIDER'

SPIDER_MODULES = ['UrlCheckSpider.spiders']
NEWSPIDER_MODULE = 'UrlCheckSpider.spiders'

# Crawl responsibly by identifying yourself (and your website) on the user-agent
#USER_AGENT = 'UrlCheckSpider (+http://www.yourdomain.com)'
USER_AGENT = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36"

EXTENSIONS = {
    'UrlCheckSpider.extensions.startup_ext.StartupExt': 100,
    'UrlCheckSpider.extensions.shutdown_ext.ShutdownExt': 100,
}

ITEM_PIPELINES = {
    "UrlCheckSpider.pipelines.pipelines.UrlCheckPipeline": 100,
}

DOWNLOADER_MIDDLEWARES = {
    #"scrapy.contrib.downloadermiddleware.httpcompression.HttpCompressionMiddleware": None,
    #"scrapy.contrib.downloadermiddleware.httpproxy.HttpProxyMiddleware": None,
    #"Spider2000.middlewares.httpproxyMid.HttpProxy": None,
    #"scrapy.contrib.downloadermiddleware.retry.RetryMiddleware": 500,
    "UrlCheckSpider.middlewares.url_check_middleware.UrlCheckMiddleWare": 500
}

DOWNLOAD_DELAY = 0

CONCURRENT_REQUESTS = 32

LOG_STDOUT = False
LOG_FILE = None
LOG_LEVEL = "DEBUG"