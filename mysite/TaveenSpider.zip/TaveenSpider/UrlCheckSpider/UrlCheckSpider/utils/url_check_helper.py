#coding:utf-8
__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.12.29"

from scrapy.spider import log
import traceback
import datetime
import math

from TaveenUtil.SpiderConfig import SpiderConfig
from TaveenUtil.Global import Global
from TaveenUtil.Constants import PageType
from TaveenUtil.Util import SqlUtil

from ..ext_byLilun.reset_website import Reset_website


class UrlCheckHelper(object):

    MAX_CHECK_TIME = 5          # 最大检测次数(同时也是爬虫执行次数).
    THRESHOLD_PERCENTAGE = 0.6  #

    ALBUM_URLS = []             # xxx_album表中所有的链接(每次爬虫执行都加载).
    EPISODE_URLS = []           # xxx_url表中的所有链接(每次爬虫执行都加载).
    ORIGINAL_DATA = {}          # 从数据库中取出的待检测的数据(字典套字典结构，key为url，
                                # value主要包括url、page_type、valid).
    INVALID_DATA = {}           # 检测到的失效了的数据(字典套字典结构，key为url，value主要包括url、page_type、valid)

    reset_website = Reset_website()  # 用来给video表置位的类(李仑提供).

    @staticmethod
    def get_start_urls_from_db():
        start_urls_list = []
        website = SpiderConfig.get_website()
        check_times = SpiderConfig.get_config("check_times")
        # test code.
        test_data = []
        #test_data = [{"url": "http://v.youku.com/v_show/id_XNDU4NjQyNzc2.html", "valid": 1, "page_type": "EPISODE_PAGE"},
        #             {"url": "http://v.youku.com/v_show/id_XNjk0NzQ2014-04-10", "valid": 1, "page_type": "EPISODE_PAGE"},
        #             {"url": "http://www.youku.com/show_page/id_z6e9e904e3f2411e1a19e.html", "valid": 1, "page_type": "ALBUM_PAGE"}]
        #test_data = [{"url": "http://www.tudou.com/albumplay/WlVACCy9qjA/ZTfyRo5vuCg.html", "valid": 1, "page_type": "EPISODE_PAGE"},
        #             {"url": "http://www.tudou.com/albumplay/dDjTk24fGr4/8EhltT1an_s.html", "valid": 1, "page_type": "EPISODE_PAGE"},
        #             {"url": "http://www.tudou.com/albumplay/tx7rx00g94o/pmqhUIhaDaY.html", "valid": 1, "page_type": "EPISODE_PAGE"}]
        #test_data = [{"url": "http://www.letv.com/ptv/vplay/2100371.html", "valid": 1, "page_type": "EPISODE_PAGE"}]
        #test_data = [{"url": "http://v.qq.com/cover/4/4w0tem5gwwpnao3.html", "valid": 1, "page_type": "EPISODE_PAGE"}]
        #test_data = [{"url": "http://tv.sohu.com/20110222/n279464211.shtml", "valid": 1, "page_type": "EPISODE_PAGE"}]
        test_data = [{"url": "http://www.letv.com/ptv/vplay/51805.html", "valid": 1, "page_type": "EPISODE_PAGE"}]
        try:
            # ---------------------------------------------------------------
            # 首次启动失效地址检测爬虫时需要做的工作：
            if check_times == 1:
                # ---------------------------------------------------------------
                # 清空临时数据表(stat_url_check_tmp)中的数据，确保不干扰新产生的数据.
                sql = u"delete from stat_url_check_tmp where website = '%s'" % website
                Global.DbOperator_VideoSpider.update(sql)

                # ---------------------------------------------------------------
                # 从数据库xxx_album表和xxx_url表中加载待检测的数据(如何选取哪些数据来检测，尚未解决，待议).
                sql_album = u"SELECT albumuri AS url, valid, 'ALBUM_PAGE' AS page_type FROM %s_album" % website
                sql_url = u"SELECT url, isValidURL as valid, 'EPISODE_PAGE' AS page_type FROM %s_url" % website
                a_result = Global.DbOperator_VideoBasic.query(sql_album)
                e_result = Global.DbOperator_VideoBasic.query(sql_url)
                data = a_result + e_result
                # test code.
                if len(test_data) > 0:
                    data = test_data

                for item in data:
                    item["valid"] = item["valid"] == 1 and u"valid" or u"invalid"
                    # 把新加载的数据部署到相应的存储变量中.
                    UrlCheckHelper.ORIGINAL_DATA[item["url"]] = item
                    start_urls_list.append(item["url"])
                    # 部署数据到ALBUM_URLS和EPISODE_URLS中.
                    if item["page_type"] == PageType.ALBUM_PAGE:
                        UrlCheckHelper.ALBUM_URLS.append(item["url"])
                    elif item["page_type"] == PageType.EPISODE_PAGE:
                        UrlCheckHelper.EPISODE_URLS.append(item["url"])
            else:  # 第2次及其以后启动失效地址检测爬虫时需要做的工作：
                # ---------------------------------------------------------------
                # 从临时数据表(stat_url_check_tmp)中加载第一次检测时筛选出的可疑数据，
                # 后续只不断检测这些数据，最终得到一个多次检测的结果.
                sql = u"SELECT * FROM stat_url_check_tmp WHERE website = '%s' AND check_times = 1 " % website
                result = Global.DbOperator_VideoSpider.query(sql)
                for row in result:
                    item = {"url": row["url"], "valid": row["original_validity"], "page_type": row["page_type"]}
                    UrlCheckHelper.ORIGINAL_DATA[item["url"]] = item
                    start_urls_list.append(item["url"])
                # ---------------------------------------------------------------
                # 从xxx_album表和xxx_url表中加载所有的url，并部署到ALBUM_URLS和EPISODE_URLS列表中.
                sql = u"SELECT albumuri FROM %s_album" % website
                result = Global.DbOperator_VideoBasic.query(sql)
                for row in result:
                    UrlCheckHelper.ALBUM_URLS.append(row["albumuri"])
                sql = u"SELECT url FROM %s_url" % website
                result = Global.DbOperator_VideoBasic.query(sql)
                for row in result:
                    UrlCheckHelper.ALBUM_URLS.append(row["url"])
                # test code.
                if len(test_data) > 0:
                    for item in test_data:
                        if item["page_type"] == PageType.ALBUM_PAGE:
                            UrlCheckHelper.ALBUM_URLS.append(item["url"])
                        elif item["page_type"] == PageType.EPISODE_PAGE:
                            UrlCheckHelper.EPISODE_URLS.append(item["url"])

            print u"total url count = %s" % len(start_urls_list)
            return start_urls_list
        except Exception, err:
            log.msg(err.message, level=log.ERROR)
            log.msg(traceback.format_exc(), level=log.ERROR)

    @staticmethod
    def set_invalid(data):
        """设置一条视频数据为失效数据.

        @param data: 失效数据的结构体，字典结构，主要包括check_url、result、description.
        """
        UrlCheckHelper.INVALID_DATA[data["check_url"]] = data

    @staticmethod
    def sql_insert_stat_url_check_tmp(data):
        """产生插入stat_url_check_tmp表中的数据的SQL语句.

        """
        datetime_now = datetime.datetime.now()
        sql = u"INSERT INTO stat_url_check_tmp(website, page_type, url, original_validity, check_result, " \
              u"description, check_times, insert_time, update_time) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s)" \
              % (SqlUtil.format_field(SpiderConfig.get_website(), "str"),
                 SqlUtil.format_field(UrlCheckHelper.ORIGINAL_DATA[data["check_url"]]["page_type"], "str"),
                 SqlUtil.format_field(data["check_url"], "str"),
                 SqlUtil.format_field(UrlCheckHelper.ORIGINAL_DATA[data["check_url"]]["valid"], "str"),
                 SqlUtil.format_field(data["result"], "str"),
                 SqlUtil.format_field(data["description"], "str"),
                 SqlUtil.format_field(SpiderConfig.get_config("check_times"), "int"),
                 SqlUtil.format_field(datetime_now, "str"),
                 SqlUtil.format_field(datetime_now, "str"))
        return sql

    @staticmethod
    def sql_insert_stat_url_check_result(data):
        """产生插入stat_url_check_result表中的数据的SQL语句.

        """
        datetime_now = datetime.datetime.now()
        sql = u"INSERT INTO stat_url_check_result(website, page_type, url, original_state, new_state, " \
              u"description, insert_time, update_time) VALUES(%s, %s, %s, %s, %s, %s, %s, %s)" \
              % (SqlUtil.format_field(data["website"], "str"),
                 SqlUtil.format_field(data["page_type"], "str"),
                 SqlUtil.format_field(data["url"], "str"),
                 SqlUtil.format_field(data["original_state"], "str"),
                 SqlUtil.format_field(data["new_state"], "str"),
                 SqlUtil.format_field(data["description"], "str"),
                 SqlUtil.format_field(datetime_now, "str"),
                 SqlUtil.format_field(datetime_now, "str"))
        return sql

    @staticmethod
    def calculate_result():
        """最后一次检测爬虫执行完成的最后，整理和统计出发生有效性变更的数据，
           并写入stat_url_check_result表中.

        """
        # ---------------------------------------------------------------
        # 计算满足存在几次有效数据时即认为该视频数据发生了有效性变更(有效变失效，或失效变有效).
        #   计算最少要满足多少次才能算入检验结果.
        min_times = int(math.ceil(float(UrlCheckHelper.MAX_CHECK_TIME) * UrlCheckHelper.THRESHOLD_PERCENTAGE))
        min_times = min_times <= 0 and 0 or min_times
        min_times = min_times > UrlCheckHelper.MAX_CHECK_TIME and UrlCheckHelper.MAX_CHECK_TIME or min_times
        print min_times

        Global.DbOperator_VideoSpider.auto_close = False
        Global.DbOperator_VideoBasic.auto_close = False
        # ---------------------------------------------------------------
        # 从临时数据表(stat_url_check_tmp)中读取所有检测过的链接(以check_times等于1时的数据为准).
        sql = u"SELECT url FROM stat_url_check_tmp WHERE website = '%s' AND check_times = 1" \
              % SpiderConfig.get_website()
        url_result = Global.DbOperator_VideoSpider.query(sql)
        # ---------------------------------------------------------------
        # 针对每个url，检索出针对这个url所进行过的所有有效性检测结果，并整理和统计出发生有效性变更的数据.
        for row in url_result:
            sql = u"SELECT * FROM stat_url_check_tmp WHERE website = '%s' AND url = %s" \
                  % (SpiderConfig.get_website(), SqlUtil.format_field(row["url"], "str"))
            check_result = Global.DbOperator_VideoSpider.query(sql)
            count = 0
            for item in check_result:
                # invalid-->>>invalid的数据虽然是失效结果，但是由于不写入result表，故不作后续统计.
                if item["check_result"] == u"invalid" and item["original_validity"] == u"invalid":
                    continue
                count += 1
            # 当count大于等于临界值时，则认定该数据为失效数据.
            if count >= min_times:
                # 收集需要写入stat_url_check_result表中的数据.
                data = {"website": check_result[0]["website"],
                        "page_type": check_result[0]["page_type"],
                        "url": check_result[0]["url"],
                        "original_state": check_result[0]["original_validity"],
                        "new_state": check_result[0]["check_result"],
                        "description": check_result[0]["description"]}
                # 如果当前视频链接存在于ALBUM_URLS中时，
                # 生成一条page_type为ALBUM_PAGE的插入stat_url_check_result表中的数据.
                # (该情况是由于某些网站没有专辑页，所以用分集页构造出一个专辑页而导致的)
                if check_result[0]["url"] in UrlCheckHelper.ALBUM_URLS \
                        and check_result[0]["url"] in UrlCheckHelper.EPISODE_URLS:
                    data["page_type"] = PageType.ALBUM_PAGE
                    sql = UrlCheckHelper.sql_insert_stat_url_check_result(data)
                    print sql
                    Global.DbOperator_VideoSpider.update(sql)
                # 否则，生成一条page_type为ALBUM_PAGE的插入stat_url_check_result表中的数据(默认).
                # (之所以默认是EPISODE，是因为加载start_urls时是将episode数据最佳到album数据后面，
                # album数据会被覆盖成episode数据)
                sql = UrlCheckHelper.sql_insert_stat_url_check_result(data)
                print sql
                Global.DbOperator_VideoSpider.update(sql)
                UrlCheckHelper.update_final_validity(data)
                pass
        pass

    @staticmethod
    def update_final_validity(data):
        """将最终整理好的结果在xxx_album表、xxx_url表和video表中进行置位.

        """
        url = data["url"]
        website = data["website"]
        if data["new_state"] == u"invalid":
            state = 0
        else:
            state = 1
        # ---------------------------------------------------------------
        # 如果url在xxx_album表中存在.
        if url in UrlCheckHelper.ALBUM_URLS:
            sql = u"UPDATE %s_album SET valid = %s WHERE albumuri = %s"\
                  % (website, state, SqlUtil.format_field(data["url"], "str"))
            print sql
            Global.DbOperator_VideoBasic.update(sql)
        elif url in UrlCheckHelper.EPISODE_URLS:  # 如果url在xxx_url表中存在.
            sql = u"UPDATE %s_url SET isValidURL = %s WHERE url = %s"\
                  % (website, state, SqlUtil.format_field(data["url"], "str"))
            print sql
            Global.DbOperator_VideoBasic.update(sql)
            # ---------------------------------------------------------------
            if state == 0:
                UrlCheckHelper.reset_website.website_set_0(url, website)
            else:
                UrlCheckHelper.reset_website.website_set_1(url, website)
        pass