#-*- coding:utf8 -*-
__author__ = 'lilun'
import MySQLdb
import MySQLdb.cursors

from TaveenUtil.Global import Global
from TaveenUtil.SpiderConfig import SpiderConfig


class DbUtil(object):
    config = SpiderConfig.get_db_config_video_basic()

    host = config["Host"]
    port = config["Port"]
    user = config["UserName"]
    passwd = config["Password"]
    db = config["DbName"]
    charset = "utf8"
    use_unicode = True
    conn = MySQLdb.connect(host=host, port=int(port), user=user, passwd=passwd, db=db,
                           charset=charset, use_unicode=True,)
    cursor = conn.cursor()

    def get_connection(self):
        conn = MySQLdb.connect(host=self.host, user=self.user,
                               passwd=self.passwd, db=self.db, charset=self.charset, use_unicode=self.use_unicode)
        return conn

    def close_connection(self, conn):
        if conn is not None:
            conn.close()

    def get_cursor(self, conn):
        if conn is not None:
            return conn.cursor()

    def execute_query_sql(self, conn, sql):
        if conn is None:
            pass
        cursor = conn.cursor()
        cursor.execute(sql)
        conn.commit()
        result = cursor.fetchall()
        return result

    def execute_sql(self, conn, sql):
        if conn is None:
            pass
        cursor = conn.cursor()
        cursor.execute(sql)

    def commit(self, conn):
        if conn is None:
            pass
        conn.commit()

