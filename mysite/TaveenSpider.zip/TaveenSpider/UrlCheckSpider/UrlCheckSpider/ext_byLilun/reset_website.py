#-*- coding:utf8 -*-
__author__ = 'lilun'
from db_util import DbUtil


class Reset_website(object):
    REVERSE_CODE = 511
    V56_CODE = 256
    PPTV_CODE = 128
    PPS_CODE = 64
    SOHU_CODE = 32
    QQ_CODE = 16
    YOUKU_CODE = 8
    QIYI_CODE = 4
    TUDOU_CODE = 2
    LETV_CODE = 1
    trans_site_code_list = {'v56_url': V56_CODE, 'pptv_url': PPTV_CODE, 'pps_url': PPS_CODE,
                            'sohu_url': SOHU_CODE, 'qq_url': QQ_CODE, 'youku_url': YOUKU_CODE,
                            'qiyi_url': QIYI_CODE, 'tudou_url': TUDOU_CODE, 'letv_url': LETV_CODE}

    def website_set_0(self, url, site):
        try:
            db_handler = DbUtil()
            conn = db_handler.get_connection()
            sql = u"select video_id from %s_url where url='%s'" % (site, url)
            #print sql
            result = db_handler.execute_query_sql(conn, sql)
            if len(result) == 0:
                print u"%s_url 数据库中未找到url为『 %s 』的数据条目." % (site, url)
                return
            video_id = result[0][0]
            if video_id is None:
                return
            sql = u"select count(*) from %s_url where isValidURL = 1 and video_id = %s" % (site, str(video_id))
            #print sql
            result = db_handler.execute_query_sql(conn, sql)
            count_url = int(result[0][0])
            if count_url == 0:
                sql = u"select website from video where video_id = %s" % str(video_id)
                #print sql
                result = db_handler.execute_query_sql(conn, sql)
                website = result[0][0]
                code = self.trans_site_code_list[site+"_url"]
                reverse_code = self.REVERSE_CODE - code
                new_website = website & reverse_code
                sql = u"update video set website = " + str(new_website) + u" where video_id = " + str(video_id)
                print sql
                db_handler.execute_sql(conn, sql)
                db_handler.commit(conn)
                db_handler.close_connection(conn)
        except Exception, err:
            print err

    def website_set_1(self, url, site):
        db_handler = DbUtil()
        conn = db_handler.get_connection()
        sql = u"select video_id from %s_url where url='%s'" % (site, url)
        #print sql
        result = db_handler.execute_query_sql(conn, sql)
        if len(result) == 0:
            print u"%s_url 数据库中未找到url为『 %s 』的数据条目." % (site, url)
            return
        video_id = result[0][0]
        if video_id is None:
            print "该条数据木有video_id."
            return
        sql = u"select website from video where video_id = " + str(video_id)
        result = db_handler.execute_query_sql(conn, sql)
        website = result[0][0]
        code = self.trans_site_code_list[site+"_url"]
        new_website = website | code
        sql = u"update video set website = " + str(new_website) + u" where video_id = " + str(video_id)
        print sql
        db_handler.execute_sql(conn, sql)
        db_handler.commit(conn)
        db_handler.close_connection(conn)

if __name__ == '__main__':
    #reset_handler = Reset_website()
    #reset_handler.website_set_0(10298, 'qq_url')
    pass