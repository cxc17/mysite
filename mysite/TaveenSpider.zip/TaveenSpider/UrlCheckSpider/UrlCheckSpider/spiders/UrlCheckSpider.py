#coding:utf-8
__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.12.23"

from scrapy.http.request import Request
from scrapy.contrib.spiders import CrawlSpider
from scrapy.spider import log
import traceback

from TaveenUtil.SpiderConfig import SpiderConfig
from TaveenUtil.Global import Global
from TaveenUtil.Util import RandomUtil
from ..utils.url_check_helper import UrlCheckHelper


class UrlCheckSpider(CrawlSpider):

    name = "UrlCheckSpider"                # 爬虫名称.
    start_urls = ["http://www.baidu.com"]       #

    verify_time_counter = 5

    def __init__(self, *a, **kw):
        self.website = SpiderConfig.get_website()

        super(CrawlSpider, self).__init__(*a, **kw)

    def parse(self, response):
        try:
            #print response.url
            if u"www.baidu.com" in response.url:
                urls = UrlCheckHelper.get_start_urls_from_db()
                for url in urls:
                    meta = {"display_mark": RandomUtil.random_str(8),
                            "check_url": url}
                    # 指定不允许发生页面跳转的网站.
                    if self.website in ["youku", "tudou", "v56"]:
                        meta["dont_redirect"] = True
                    yield Request(url=url, meta=meta, callback=self.parse, dont_filter=True)
                return
            # 调用不同的checker进行检验.
            command = u"from ..url_checker.%s_checker import %sChecker" % (self.website, self.website)
            class_name = u"%sChecker" % self.website
            exec command
            obj = eval(u"%s.process_parse(response)" % class_name)
            if obj is not None:
                request_list, item_list = obj
                for request in request_list:
                    print u"★%s★ yield %s" % (response.meta.get("display_mark", ""), request["url"])
                    print u"yield request: %s" % request
                    meta = request.get("meta", {})
                    meta["display_mark"] = RandomUtil.random_str(8)
                    yield Request(url=request["url"],
                                  meta=meta,
                                  callback=self.parse,
                                  dont_filter=request.get("dont_filter", False))
                for item in item_list:
                    print u"yield item %s" % item
                    yield item
            pass
        except Exception, err:
            log.msg(err.message, level=log.ERROR)
            log.msg(traceback.format_exc(), level=log.ERROR)
        pass