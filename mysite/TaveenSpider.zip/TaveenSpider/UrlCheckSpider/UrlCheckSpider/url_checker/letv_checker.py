#coding:utf-8
__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.12.23"

from scrapy.http import Request
from scrapy.selector import Selector
from scrapy.exceptions import IgnoreRequest
from scrapy.spider import log
import traceback
import json
import re

from ..utils.url_check_helper import UrlCheckHelper


class letvChecker(object):

    @staticmethod
    def process_parse(response):
        request_list = []
        item_list = []

        try:
            pass
        except Exception, err:
            print u"%s Error when processing %s" % (err.message, response.url)
            log.msg(traceback.format_exc(), level=log.ERROR)

        return request_list, item_list

    @staticmethod
    def process_response(request, response, spider):
        if response.status == 404 or response.status == 500:
            selector = Selector(response)
            title_txt = "".join(selector.xpath(u"//title/text()").extract())
            if u"出错" in title_txt:
                print u"★%s★ Invalid url %s (description: %s 页面不存在或已被删除)" \
                      % (request.meta.get("display_mark", u""),
                         request.meta["check_url"],
                         response.status)
                result = {"check_url": request.meta["check_url"],
                          "result": u"invalid",
                          "description": u"%s 页面不存在或已被删除" % response.status}
                UrlCheckHelper.set_invalid(result)
                raise IgnoreRequest()
        pass

    @staticmethod
    def process_request(request, spider):
        #print u"Request url = %s" % request.url
        pass