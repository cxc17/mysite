#coding:utf-8
__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.12.23"

from scrapy.http import Request
from scrapy.exceptions import IgnoreRequest
from scrapy.spider import log
import traceback
import json
import re

from ..utils.url_check_helper import UrlCheckHelper


class qiyiChecker(object):

    @staticmethod
    def process_parse(response):
        request_list = []
        item_list = []

        try:
            pass
        except Exception, err:
            print u"%s Error when processing %s" % (err.message, response.url)
            log.msg(traceback.format_exc(), level=log.ERROR)

        return request_list, item_list

    @staticmethod
    def process_response(request, response, spider):
        try:
            pass
        except Exception, err:
            print u"%s Error when processing %s" % (err.message, response.url)
            log.msg(traceback.format_exc(), level=log.ERROR)
        pass

    @staticmethod
    def process_request(request, spider):
        #print u"Request url = %s" % request.url
        pass