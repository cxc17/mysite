#coding:utf-8
__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.12.23"

from scrapy.http import Request
from scrapy.exceptions import IgnoreRequest
from scrapy.spider import log
import traceback
import json
import re

from ..utils.url_check_helper import UrlCheckHelper


class sohuChecker(object):

    sohu_vid_pattern = re.compile(ur"var vid=\"(.+)\"")

    @staticmethod
    def process_parse(response):
        request_list = []
        item_list = []

        try:
            if u"http://tv.sohu.com" in response.url:
                matcher = sohuChecker.sohu_vid_pattern.search(response.body)
                if matcher:
                    vid = matcher.group(1)
                    url = u"http://220.181.118.181/vrs_flash.action?vid=%s" % vid
                    request_list.append({"url": url,
                                         "meta": {"check_url": response.meta.get("check_url", "")},
                                         "dont_filter": True})
            elif u"http://220.181.118.181" in response.url:
                json_obj = json.loads(response.body)
                status = json_obj.get("status", u"")
                if status == 3 or status == 6 or status == 7 or status == 8 or status == 9:
                    print u"★%s★ Invalid url %s (description: 该视频版权已到期(50%s))" \
                          % (response.meta.get("display_mark", u""),
                             response.meta["check_url"],
                             status)
                    result = {"check_url": response.meta["check_url"],
                              "result": u"invalid",
                              "description": u"该视频版权已到期(50%s)" % status}
                    UrlCheckHelper.set_invalid(result)
                elif status == 10:
                    print u"★%s★ Invalid url %s (description: 该视频已过付费有效期(510))" \
                          % (response.meta.get("display_mark", u""),
                             response.meta["check_url"])
                    result = {"check_url": response.meta["check_url"],
                              "result": u"invalid",
                              "description": u"该视频已过付费有效期(510)"}
                    UrlCheckHelper.set_invalid(result)
                elif status == 5 or status == 11:
                    # 暂时没有遇到这样的样例，但是从sohu播放器的代码看，这两种状态也属于错误状态.
                    pass
                elif status == 12:
                    print u"★%s★ Invalid url %s (description: 该视频内容存在异常)" \
                          % (response.meta.get("display_mark", u""),
                             response.meta["check_url"])
                    result = {"check_url": response.meta["check_url"],
                              "result": u"invalid",
                              "description": u"该视频内容存在异常"}
                    UrlCheckHelper.set_invalid(result)
                elif json_obj["data"] is None:
                    print u"★%s★ Invalid url %s (description: 未预期的失效形式)" \
                          % (response.meta.get("display_mark", u""),
                             response.meta["check_url"])
                    result = {"check_url": response.meta["check_url"],
                              "result": u"invalid",
                              "description": u"未预期的失效形式"}
                    UrlCheckHelper.set_invalid(result)
            pass
        except Exception, err:
            print u"%s Error when processing %s" % (err.message, response.url)
            log.msg(traceback.format_exc(), level=log.ERROR)

        return request_list, item_list

    @staticmethod
    def process_response(request, response, spider):
        pass

    @staticmethod
    def process_request(request, spider):
        #print u"Request url = %s" % request.url
        pass