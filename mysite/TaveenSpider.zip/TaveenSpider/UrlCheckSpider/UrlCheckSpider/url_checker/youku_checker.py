#coding:utf-8
__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.12.23"

from scrapy.http import Request
from scrapy.exceptions import IgnoreRequest
from scrapy.spider import log
import traceback
import json
import re

from ..utils.url_check_helper import UrlCheckHelper


class youkuChecker(object):

    youku_vid_pattern = re.compile(ur"var videoId = '(\d+)';")
    
    @staticmethod
    def process_parse(response):
        request_list = []
        item_list = []

        try:
            if response.status == 200:
                if response.url.startswith(u"http://v.youku.com/v_show/") \
                        or response.url.startswith(u"http://v.youku.com/show_page/"):
                    matcher = youkuChecker.youku_vid_pattern.search(response.body)
                    if matcher:
                        vid = matcher.group(1)
                        url = u"http://v.youku.com/player/getPlayList/VideoIDS/%s" % vid
                        request_list.append({"url": url,
                                             "meta": {"check_url": response.meta.get("check_url", "")},
                                             "dont_filter": True})
                elif response.url.startswith(u"http://v.youku.com/player/getPlayList/VideoIDS"):
                    # 注意，当youku的这段代码由于改版等原因需要更改时，下面土豆的检测代码十有八九也需要修改。
                    json_obj = json.loads(response.body)
                    if len(json_obj["data"]) == 0:
                        log.msg(u"WARNING: data标签下没有内容(%s) -->>> %s" % (response.url, json_obj["data"]))
                        return request_list, item_list
                    text = json_obj["data"][0].get("error", "")
                    if len(text) > 0:
                        text = text.replace(u"\n", "").replace(u"\r", "")
                        print u"★%s★ Invalid url %s (description: %s)" \
                              % (response.meta.get("display_mark", u""), response.meta["check_url"], text)
                        result = {"check_url": response.meta["check_url"], "result": u"invalid", "description": text}
                        UrlCheckHelper.set_invalid(result)
            pass
        except Exception, err:
            print u"%s Error when processing %s" % (err.message, response.url)
            log.msg(traceback.format_exc(), level=log.ERROR)

        return request_list, item_list

    @staticmethod
    def process_response(request, response, spider):
        if response.status == 302:
            if u"index/y404" in response.headers.get("Location", u""):
                print u"★%s★ Invalid url %s (description: 302 to 404 页面不存在; to: %s)" \
                      % (request.meta.get("display_mark", u""),
                         request.meta["check_url"],
                         response.headers.get("Location", ""))
                result = {"check_url": request.meta["check_url"],
                          "result": u"invalid",
                          "description": u"页面不存在(302 to 404)"}
                #UrlCheckHelper.INVALID_DATA[request.meta["check_url"]] = result
                UrlCheckHelper.set_invalid(result)
                raise IgnoreRequest()
            else:
                pass
        #elif response.status == 200:
        #    pass
        #else:
        #    log.msg(u"未预期的response.status: %s when deal %s" % (response.status, response.url), level=log.WARNING)
        pass

    @staticmethod
    def process_request(request, spider):
        #print u"Request url = %s" % request.url
        pass