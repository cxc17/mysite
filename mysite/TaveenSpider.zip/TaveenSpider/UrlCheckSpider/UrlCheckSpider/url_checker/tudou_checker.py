#coding:utf-8
__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2015.01.12"

from scrapy.http import Request
from scrapy.selector import Selector
from scrapy.exceptions import IgnoreRequest
from scrapy.spider import log
import traceback
import json
import re

from ..utils.url_check_helper import UrlCheckHelper


class tudouChecker(object):

    tudou_vcode_pattern = re.compile(ur"vcode: '(.+?)'")

    @staticmethod
    def process_parse(response):
        request_list = []
        item_list = []

        try:
            if response.url.startswith(u"http://www.tudou.com/"):
                selector = Selector(response)
                script_txt = u"".join(selector.xpath(u"//script//text()").extract())
                matcher = tudouChecker.tudou_vcode_pattern.search(script_txt)
                if matcher:
                    vcode = matcher.group(1)
                    url = u"http://v.youku.com/player/getPlayList/VideoIDS/%s/timezone/+08/version/5/source/out/Sc/2" \
                          % vcode
                    request_list.append({"url": url,
                                         "meta": {"check_url": response.meta.get("check_url", "")},
                                         "dont_filter": True})
            elif response.url.startswith(u"http://v.youku.com/player/getPlayList/VideoIDS"):
                # 下面这段代码跟youkuChecker中的代码相同，当youkuChecker中的代码更改时，此处代码也要随之更改.
                json_obj = json.loads(response.body)
                if len(json_obj["data"]) == 0:
                    log.msg(u"WARNING: data标签下没有内容(%s) -->>> %s" % (response.url, json_obj["data"]))
                    return request_list, item_list
                text = json_obj["data"][0].get("error", "")
                if len(text) > 0:
                    text = text.replace(u"\n", "").replace(u"\r", "")
                    print u"★%s★ Invalid url %s (description: %s)" \
                          % (response.meta.get("display_mark", u""),
                             response.meta["check_url"],
                             text)
                    result = {"check_url": response.meta["check_url"],
                              "result": u"invalid",
                              "description": text}
                    UrlCheckHelper.set_invalid(result)
            pass
        except Exception, err:
            print u"%s Error when processing %s" % (err.message, response.url)
            log.msg(traceback.format_exc(), level=log.ERROR)

        return request_list, item_list

    @staticmethod
    def process_response(request, response, spider):
        if response.status == 302:
            if u"www.tudou.com/error.php?code=404" in response.headers.get("Location", u""):
                print u"★%s★ Invalid url %s (description: 302 to 404 页面不存在; to: %s)" \
                      % (request.meta.get("display_mark", u""),
                         request.meta["check_url"],
                         response.headers.get("Location", ""))
                result = {"check_url": request.meta["check_url"],
                          "result": u"invalid",
                          "description": u"页面不存在(302 to 404)"}
                UrlCheckHelper.set_invalid(result)
                raise IgnoreRequest()
        pass

    @staticmethod
    def process_request(request, spider):
        #print u"Request url = %s" % request.url
        pass