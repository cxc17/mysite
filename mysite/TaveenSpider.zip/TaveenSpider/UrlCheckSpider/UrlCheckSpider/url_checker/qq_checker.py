#coding:utf-8
__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.12.23"

from scrapy.http import Request
from scrapy.selector import Selector
from scrapy.exceptions import IgnoreRequest
from scrapy.spider import log
import traceback
import json
import re

from ..utils.url_check_helper import UrlCheckHelper


class qqChecker(object):

    @staticmethod
    def process_parse(response):
        request_list = []
        item_list = []

        try:
            pass
        except Exception, err:
            print u"%s Error when processing %s" % (err.message, response.url)
            log.msg(traceback.format_exc(), level=log.ERROR)

        return request_list, item_list

    @staticmethod
    def process_response(request, response, spider):
        selector = Selector(response)
        txt = "".join(selector.xpath(u"//div[@class='mod_error_message']//text()").extract())
        if u"很抱歉，" in txt:
            print u"★%s★ Invalid url %s (description: %s but invalid: 页面不存在或链接错误)" \
                  % (request.meta.get("display_mark", u""),
                     request.meta["check_url"],
                     response.status)
            result = {"check_url": request.meta["check_url"],
                      "result": u"invalid",
                      "description": u"%s but invalid: 页面不存在或链接错误" % response.status}
            UrlCheckHelper.set_invalid(result)
            raise IgnoreRequest()
        pass

    @staticmethod
    def process_request(request, spider):
        #print u"Request url = %s" % request.url
        pass