# coding=utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.12.23"

from scrapy.spider import log
from scrapy import signals
from math import ceil
import traceback
import datetime

from TaveenUtil.SpiderConfig import SpiderConfig
from TaveenUtil.Global import Global
from TaveenUtil.Util import SqlUtil
from TaveenUtil.Constants import *
from ..utils.url_check_helper import UrlCheckHelper


class ShutdownExt(object):
    """爬虫关闭时的extension组件."""

    # scrapy_stats数据(即爬虫结束时dump到日志最后的那段键值对结构).
    stats = None

    def __init__(self):
        pass

    @classmethod
    def from_crawler(cls, crawler):
        ext = cls()
        ext.stats = crawler.stats
        crawler.signals.connect(ext.spider_closed, signal=signals.spider_closed)
        return ext

    def spider_closed(self, spider):
        print u"%sSpider Closed Extension%s" % (u"*"*50, u"*"*50)
        ShutdownExt.when_spider_closed()
        pass

    @staticmethod
    def when_spider_closed():
        # 将check结果为valid-->>>invalid的链接写入临时数据表.
        #for sql in UrlCheckHelper.SQL_LIST:
        #    #print sql
        #    Global.DbOperator_VideoSpider.update(sql)
        for key in UrlCheckHelper.INVALID_DATA:
            if key not in UrlCheckHelper.ORIGINAL_DATA:
                log.msg(u"%s not in UrlCheckHelper.ORIGINAL_DATA" % key, level=log.ERROR)
            item = UrlCheckHelper.INVALID_DATA[key]
            if UrlCheckHelper.ORIGINAL_DATA[key]["valid"] == u"valid":
                sql = UrlCheckHelper.sql_insert_stat_url_check_tmp(item)
                Global.DbOperator_VideoSpider.update(sql)
            else:
                log.msg(u"%s from invalid -->>> invalid, skip." % key, level=log.INFO)
        # 将所有check结果不为invalid的链接进行检查，.
        for key in UrlCheckHelper.ORIGINAL_DATA:
            item = UrlCheckHelper.ORIGINAL_DATA[key]
            if item["url"] in UrlCheckHelper.INVALID_DATA:
                continue
            original_result = UrlCheckHelper.ORIGINAL_DATA[item["url"]]["valid"]
            if original_result == u"invalid":
                data = {"check_url": item["url"],
                        "result": u"valid",
                        "description": u""}
                sql = UrlCheckHelper.sql_insert_stat_url_check_tmp(data)
                Global.DbOperator_VideoSpider.update(sql)

        # -------------------------------------------------------------------------
        # 当检测次数小于最大检测次数时，启动下一次检测爬虫;
        # 当检测次数(爬虫执行次数)等于最大检测次数，或检测次数达到某个值时，进行最终结果检验和统计.
        check_times = SpiderConfig.get_config("check_times")
        if check_times < UrlCheckHelper.MAX_CHECK_TIME:
            import os
            print os.getcwd()
            command = u"""python url_check_starter.py %s %s "%s" """ \
                      % (SpiderConfig.get_website(), SpiderConfig.get_config("check_times")+1, Global.ProgramStartTime)
            print command
            os.system(command)
        else:
            # 统计最终结果.
            UrlCheckHelper.calculate_result()
            pass
        pass