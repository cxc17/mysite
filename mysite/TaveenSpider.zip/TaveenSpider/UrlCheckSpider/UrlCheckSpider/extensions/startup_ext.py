# coding=utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.12.23"

from scrapy import signals

from TaveenUtil.SpiderConfig import SpiderConfig
from TaveenUtil.Global import Global
from TaveenUtil.Constants import *

from scrapy.spider import log
import traceback


class StartupExt(object):
    """爬虫启动时的extension组件."""
    def __init__(self):
        pass

    @classmethod
    def from_crawler(cls, crawler):
        ext = cls()
        crawler.signals.connect(ext.spider_opened, signal=signals.spider_opened)
        return ext

    def spider_opened(self, spider):
        print "*"*50 + "Spider Opened Extension" + "*"*50
        pass

