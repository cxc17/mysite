#coding:utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.12.23"

from TaveenUtil.SpiderConfig import SpiderConfig


class UrlCheckMiddleWare(object):

    def process_response(self, request, response, spider):
        print u"★%s★ Processing %s" % (request.meta.get("display_mark", u""), response.url)
        website = SpiderConfig.get_website()
        command = u"from ..url_checker.%s_checker import %sChecker" % (website, website)
        class_name = u"%sChecker" % website
        exec command
        obj = eval(u"%s.process_response(request, response, spider)" % class_name)
        if obj is not None:
            return obj
        return response

    def process_request(self, request, spider):
        website = SpiderConfig.get_website()
        command = u"from ..url_checker.%s_checker import %sChecker" % (website, website)
        class_name = u"%sChecker" % website
        exec command
        obj = eval(u"%s.process_request(request, spider)" % class_name)
        if obj is not None:
            return obj
        return None