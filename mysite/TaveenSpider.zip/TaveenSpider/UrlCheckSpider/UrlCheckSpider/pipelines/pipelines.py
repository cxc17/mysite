#coding:utf-8
__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.12.23"

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html

from scrapy.spider import log
import traceback
import datetime

from TaveenUtil.SpiderConfig import SpiderConfig
from TaveenUtil.Constants import PageType
from TaveenUtil.Global import Global


class UrlCheckPipeline(object):
    """视频信息(VideoInfo)写入到数据库的管道类."""

    def process_item(self, item, spider):
        pass