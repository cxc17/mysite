#coding:utf-8

import datetime


if __name__ == '__main__':
    from TaveenUtil.DbOperator import *
    db_config = DbConfig(host="210.72.229.135",
                         port=3307,
                         db="videoBasic",
                         user="Guokai.Huang",
                         pwd="huangguokai")
    db_operator = DbOperator(db_config=db_config)
    db_operator.auto_close = False

    websites = ["youku", "tudou", "qiyi", "letv", "sohu", "qq", "v56", "pps", "pptv"]
    date_today = datetime.datetime.now().strftime('%Y-%m-%d')  # %Y-%m-%d %H:%M:%S
    for website in websites:  # 处理每家网站.
        sql = u"select title, albumuri, year, length, curEpisode from %s_album where updateTime > '%s'" \
              % (website, date_today)
        #print sql
        result = db_operator.query(sql)
        total_count = len(result)
        print u"-"*100
        print u"%s has %s new albums" % (website, total_count)
        print u"-"*100
        for row in result:  # 处理每条视频，看是否真的是新增的视频.
            sql = u"select video_name, url, no, year from %s_url where album_id = '%s' order by no desc" % (website, row["albumuri"])
            print sql
            ep_result = db_operator.query(sql)
            ep_count = len(ep_result)
            for ep_row in ep_result:  #
                pass
            for field in row:
                print u"%s |-->>>| %s" % (field.ljust(10), row[field])