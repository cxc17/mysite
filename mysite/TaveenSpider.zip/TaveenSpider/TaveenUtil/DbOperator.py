# coding=utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2013.11.23"

from DbConfig import DbConfig

import threading
import traceback
import MySQLdb
import MySQLdb.connections
import logging
import types


class DbOperator(object):
    """DbOperator类封装了常用的数据库操作。

    主要功能包括：
        query：实现了基本的数据库查询操作，返回List<Dict>结构的数据集合。
        update：实现了基本的数据库更新操作，包括增、删、改。该函数只支持单条语句的数据库更新操作。
        batch_update：批量实现了基本的数据库更新操作，包括增、删、改。
        update_many：批量实现了基本的数据库更新操作，包括增、删、改。

    Attribute:
        db_config: DbConfig类型，数据库连接参数对象实例。该实例中包含了数据库连接信息。

    @attention:
        该类使用全局锁机制实现线程间的同步操作，类中的操作是线程安全的。但需要说明的是，该类的设计初衷并不是使用全局锁，
        而是希望能锁定当前的DbOperator对象，以实现不用线程对同一个对象实例的方法进行调用时是同步的，
        而不同线程对不同DbOperator对象实例的方法进行调用时则无需同步。由于当前对Python语言的相关机制还没有更深入的了解，
        故暂时采用全局锁机制来实现所有线程、所有DbOperator对象之间的同步。

    @author: HuangGK
    Date: 2013.11.23
    """
    db_operation_lock = threading.Lock()

    __conn = None
    __cur = None
    __db_config = None

    auto_close = True

    def __init__(self, db_config=None):
        """构造函数，初始化DbOperator类的新实例。

        @param db_config: DbConfig类型，为数据库参数配置对象。
                        db_config默认值为None，当db_config为None时相当于无参构造函数。
        """
        if db_config is not None:
            self.set_db_config(db_config)
        else:
            self.set_db_config(None)

    def __del__(self):
        try:
            self.close()
        except Exception, err:
            logging.error("Error: Error occurred when deleting DbOperator instance.\n    %s." % err.message)
            raise err

    def __connect(self):
        """建立数据库连接。"""
        try:
            if isinstance(self.__cur, MySQLdb.cursors.Cursor) or \
                    isinstance(self.__conn, MySQLdb.connections.Connection):
                return
            if self.__db_config.db_charset is None:
                self.__db_config.db_charset = "utf8"
            self.__conn = MySQLdb.connect(host=self.__db_config.db_host, port=self.__db_config.db_port,
                                          db=self.__db_config.db_name, user=self.__db_config.db_user,
                                          passwd=self.__db_config.db_password, charset=self.__db_config.db_charset)
            # print "INFO: Connect to database successfully."
        except Exception, err:
            msg = "Error: Failed to Connect to database:\n    %s.\nParameters: host = %s, port = %s, db = %s, " \
                  "user = %s, pwd  = %s, charset = %s\nMake sure that all parameters have been set correctly." \
                  % (err.message, self.__db_config.db_host, self.__db_config.db_port,  self.__db_config.db_name,
                     self.__db_config.db_user, self.__db_config.db_password, self.__db_config.db_charset)
            logging.error(msg)
            traceback.print_exc()
            raise err

    def close(self):
        """关闭数据库连接。"""
        try:
            if isinstance(self.__cur, MySQLdb.cursors.Cursor):
                self.__cur.close()
        except Exception, err:
            print "Error: Error occurred when trying to close database:\n    %s." % err.message
        finally:
            self.__cur = None

        try:
            if isinstance(self.__conn, MySQLdb.connections.Connection):
                self.__conn.close()
                # print "INFO: Database connection closed."
        except Exception, err:
            logging.error("Error: Error occurred when trying to close database:\n    %s." % err.message)
            traceback.print_exc()
        finally:
            self.__conn = None

    def query(self, sql):
        """对数据库执行指定语句的查询操作。

        @param sql: 字符串类型，需要执行的查询操作的SQL语句。
        @return: 返回List[Dict{}]结构的的数据集合。
                  该函数返回的对象是一个列表list，list中的每个元素是一个字典dict，
                  这两种数据结构的嵌套模拟了数据库关系表的二维结构，且list中的每个dict使用列名作为键进行访问。
        """
        try:
            if not isinstance(sql, types.StringTypes) and not isinstance(sql, types.UnicodeType):
                raise ValueError("Invalid parameter \"sql\" which must be string type or unicode type.")

            DbOperator.db_operation_lock.acquire()

            self.__connect()
            self.__cur = self.__conn.cursor()
            self.__cur.execute(sql)
            index = self.__cur.description
            result_list = []
            while True:
                row_raw = self.__cur.fetchone()
                if row_raw is None:
                    break
                row_dict = {}
                for i in xrange(len(index)):
                    row_dict[index[i][0]] = row_raw[i]
                result_list.append(row_dict)

            return result_list
        except Exception, err:
            raise err
        finally:
            if self.auto_close is True:
                self.close()
            DbOperator.db_operation_lock.release()

    def update(self, sql):
        """对数据库进行指定语句的更新操作。

        更新操作包括insert、update、delete；
        注意，该函数只能进行单条SQL语句的操作。

        @param sql: 字符串类型，需要执行的更新操作(insert、update、delete)的SQL语句字符串。
        @return: 返回受影响的行数。
        """
        try:
            if not isinstance(sql, types.StringTypes) and not isinstance(sql, types.UnicodeType):
                raise ValueError("Invalid parameter \"sql\" which must be string type or unicode type.")

            DbOperator.db_operation_lock.acquire()

            self.__connect()
            self.__cur = self.__conn.cursor()
            line_cnt = self.__cur.execute(sql)
            self.__conn.commit()                 # 没有commit调用就无法将更新语句写入数据库中。

            return line_cnt
        except Exception, err:
            self.__conn.rollback()               # 数据库操作失败时回滚事务。
            raise err
        finally:
            if self.auto_close is True:
                self.close()
            DbOperator.db_operation_lock.release()

    def batch_update(self, sql_list):
        """批量执行数据库更新操作。

        该函数使用"伪批量操作"的形式实现批量更新，其方式是：
            首先关闭自动提交事务；
            然后将每条SQL语句通过调用execute函数依次执行；
            最后整体提交事务。

        @param sql_list: 字符串类型，需要执行的进行更新操作的SQL语句列表，列表中的每个元素必须是一个SQL语句字符串。
        @return: 返回受影响的总行数。
        """
        current_sql = ""
        try:
            if not isinstance(sql_list, types.ListType):
                raise ValueError("Invalid parameter \"sql_list\" which must be list type with string type "
                                 "or unicode type as it's member.")
            DbOperator.db_operation_lock.acquire()

            self.__connect()
            self.__conn.autocommit(False)
            self.__cur = self.__conn.cursor()
            line_cnt = 0
            for sql in sql_list:
                current_sql = sql
                tmp_cnt = self.__cur.execute(sql)
                if tmp_cnt > 0:
                    line_cnt += tmp_cnt
            self.__conn.commit()                 # 没有commit调用就无法将更新语句写入数据库中。

            return line_cnt
        except Exception, err:
            print "Error: Error occurred when batching update, now roll back.\n    %s." % err.message
            print "SQL = " + current_sql
            self.__conn.rollback()               # 数据库操作失败时回滚事务。
            raise err
        finally:
            self.__conn.autocommit(True)
            if self.auto_close is True:
                self.close()
            DbOperator.db_operation_lock.release()

    def update_many(self, sql_template, value_list):
        """批量执行数据库更新操作。

        该函数使用python中MySQLdb模块的executemany函数实现批量数据库更新操作。
            但是需要注意的是，在给executemany函数提供参数时要小心，使用不熟练可能导致写入数据库的数据多出来引号等问题。

        @param sql_template: 字符串类型，数据库更新操作的SQL语句字符串模板，其中需要填值的地方使用占位符标记。
        @param value_list: 列表类型，为数据库更新的SQL语句模板提供具体值的列表list对象，该list中的每个元素为tuple对象。
        @return: 返回受影响的总行数。
        """
        try:
            if not isinstance(sql_template, types.UnicodeType):
                raise ValueError("Invalid parameter \"sql_template\" which must be string type or unicode type.")
            if not isinstance(value_list, types.ListType):
                raise ValueError("Invalid parameter \"value_list\" which must be list type with tuple type as it's "
                                 "member.")
            DbOperator.db_operation_lock.acquire()

            self.__connect()
            self.__cur = self.__conn.cursor()
            line_cnt = self.__cur.executemany(sql_template, value_list)
            self.__conn.commit()                 # 没有commit调用就无法将更新语句写入数据库中。

            return line_cnt
        except Exception, err:
            print "Error: Error occurred when updating many, now roll back.\n    %s." % err.message
            self.__conn.rollback()               # 数据库操作失败时回滚事务。
            raise err
        finally:
            if self.auto_close is True:
                self.close()
                DbOperator.db_operation_lock.release()

    def get_db_config(self):
        """__db_config的对外get接口。"""
        return self.__db_config

    def set_db_config(self, db_config):
        """__db_config的对外set接口。"""
        if not isinstance(db_config, DbConfig) or db_config.db_host is None or db_config.db_port is None \
                or db_config.db_name is None or db_config.db_user is None or db_config.db_password is None:
            raise ValueError("Invalid parameters. make sure that every attribute has been set correctly"
                             "(any parameter won't be NoneType). ")
        self.__db_config = db_config

if __name__ == '__main__':
    print "DbOperator.py"