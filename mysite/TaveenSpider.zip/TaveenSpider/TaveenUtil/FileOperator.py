# coding=utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2013.11.23"

import os


class FileOperator(object):
    """该类封装了常用的文件操作。

    该类中的所有函数均为静态函数。
    提供常见的创建文件、读文件、写文件、删除文件、判断文件是否存在等操作。
    该类只能操作本地硬盘的文件，不能操作远程文件。

    该类主要封装的功能包括：
        write_all_text：将指定的文本全部写入指定的文件中。如果文件或目录不存在则会自动创建文件或目录。
        read_all_text：读取指定路径的文本文件中的所有文本内容。
        exist_file：判断指定的文件路径是否存在。
        create_file：创建指定路径的文件。注意，参数只能是一个文件的路径，而不能是一个目录。
        delete_file：删除指定文件路径的文件。

    @author: HuangGK
    Date: 2013.11.23
    """

    @staticmethod
    def write_all_text(file_path, content, encoding=None, is_append=True):
        """将指定的文本全部写入指定的文件中。如果文件或目录不存在则会自动创建文件或目录。

        @param file_path: 需要写入的文件路径。注意，必须是文件路径，而不能是文件夹，否则会抛出异常。
        @param content: 需要写入文件中的文本内容。
        @param is_append: 标记是否是向文件中追加文本。True表示追加文本，False表示覆盖写入。
        @return: 返回写入是否成功。
        """
        #try:
        # 校验文件目录是否存在，并保证路径确实是一个文件而不是文件夹，如果不存在则创建，创建失败时会抛出异常。
        _filename = os.path.basename(file_path)
        if _filename is None or len(_filename) == 0:
            raise ValueError("Invalid parameter: param file_path must be a file path rather than a dir.")
        _dir = os.path.dirname(file_path)
        if _dir is not None and len(_dir) > 0 and not os.path.exists(_dir):
            os.makedirs(_dir)

        mode = is_append is True and 'a' or 'w'
        _f = open(name=file_path, mode=mode)
        if encoding is None:
            _f.write(content)
        else:
            _f.write(content.encode(encoding))

        return True
        #except Exception, err:
        #    print "Error: Error occurred when writing string to file: %s\n    %s." % (file_path, err.message)
        #    #traceback.print_stack()
        #    raise err
        #finally:
        #    if _f is not None and not _f.closed:
        #        _f.close()

    @staticmethod
    def read_all_text(file_path, encoding=None):
        """读取指定路径的文本文件中的所有文本内容。

        @param file_path: 需要读取的文件的路径。注意，必须是文件路径，而不能是文件夹，否则会抛出异常。
        @param encoding: 读取文件内容时采用的编码.
        @return: 返回读取到的文本内容(字符串)。
        """
        try:
            # 校验文件是否存在。
            if not os.path.exists(file_path) or not os.path.isfile(file_path):
                raise ValueError("Invalid parameter: file path \"" + file_path + "\" does not exist"
                                                                                 "(must be a file path).")

            _f = open(name=file_path, mode='r')
            line = _f.readline()
            text = ""
            while line:
                if encoding is None:
                    text += line
                else:
                    text += line.decode(encoding, 'ignore')
                line = _f.readline()
            return text
        except Exception, err:
            print "Error: Error occurred when reading file: %s\n    %s." % (file_path, err.message)
        finally:
            if _f is not None and not _f.closed:
                _f.close()

    @staticmethod
    def exist_file(file_path):
        """判断指定路径的文件是否存在。

        @param file_path: 需要判断存在性的文件路径。注意，必须是文件路径，如果是文件夹会返回False。
        @return: 返回文件是否存在的bool值。
        """
        try:
            if not os.path.exists(file_path) or not os.path.isfile(file_path):
                return False
            else:
                return True
        except Exception, err:
            print "Error: Error occurred when checking if file exists: %s\n    %s." % (file_path, err.message)

    @staticmethod
    def create_file(file_path, override_if_exists=False):
        """创建指定路径的文件。

        如果文件所属的目录(文件夹)不存在，则函数会自动创建父级目录；
            如果文件已经存在，则根据override_if_exists判断是否删除现有的文件并创建新文件；
            如果文件不存在，则会创建文件；
            如果创建目录(文件夹)或者文件发生错误(比如文件路径是非法路径)，则会抛出异常。

        @param file_path: 需要创建的文件路径。注意，必须是文件路径，而不是文件夹，否则文件创建不成功。
        @param override_if_exists: 标记当需要创建的文件已经存在是，是否覆盖已有的文件。
        @return: 返回创建文件是否成功。
        """
        try:
            # 校验文件目录是否存在，如果不存在则创建，创建失败时会抛出异常。
            _dir = os.path.dirname(file_path)
            _filename = os.path.basename(file_path)
            if _filename is None or len(_filename) == 0:
                raise ValueError("Invalid parameter: param file_path must be a file path rather then a dir.")
            if _dir is not None and len(_dir) > 0 and not os.path.exists(_dir):
                os.makedirs(_dir)
            if os.path.exists(file_path):
                if override_if_exists is True:
                    os.remove(file_path)
                else:
                    return False
            _f = open(file_path, mode='w')
            _f.close()
            return True
        except Exception, err:
            print "Error: Error occurred when creating file: %s\n    %s." % (file_path, err.message)
        return False

    @staticmethod
    def delete_file(file_path):
        """删除指定路径的文件。

        @param file_path: 需要删除的文件路径。注意，必须是文件路径，而不是文件夹，否则不作删除处理。
        @return: 返回是否成功删除文件。
        """
        try:
            if os.path.exists(file_path) and os.path.isfile(file_path):
                os.remove(file_path)
                return True
        except Exception, err:
            print "Error: Error occurred when deleting file: %s\n    %s." % (file_path, err.message)
        return False

if __name__ == "__main__":
    print "VideoCrawler.Util.FileOperator.py"