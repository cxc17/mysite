# coding=utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.08.21"

from TaveenUtil.SpiderConfig import SpiderConfig
from TaveenUtil.DbOperator import DbOperator
from TaveenUtil.DbConfig import DbConfig
from TaveenUtil.Util import *

import datetime


class Global(object):
    """[静态类]系统全局的对象存储容器，包含全局范围内会被用到的对象.

    """

    os_name = OSUtil.get_os_name()                     # 操作系统名.

    ip = OSUtil.get_localhost_ip()                     # 本机ip地址.

    ProgramExecutionStamp = datetime.datetime.now()    # 程序执行的时间戳(启动时间).

    ProgramStartTime = ProgramExecutionStamp           # 程序启动时间.
    ProgramStartTimeStr = u"%s" % ProgramStartTime     # 程序启动时间(字符串格式).
    ProgramFinishTime = None                           # 程序完成时间(需要在程序完成时设置该变量).
    ProgramFinishTimeStr = ""                          # 程序完成时间字符串(需要在程序完成时设置该变量).
    ProgramUsedTime = -1                               # 程序执行所用时间(需要在程序结束时设置该变量).

    DbConfig_VideoBasic = None                         # VideoBasic数据库配置对象(需要调用Global.initialize函数初始化).
    # DbConfig_VideoStat = None                          # VideoStat数据库配置对象(需要调用Global.initialize函数初始化).
    DbConfig_VideoSpider = None                        # VideoSpider数据库配置对象(需要调用Global.initialize函数初始化).

    DbOperator_VideoBasic = None                       # VideoBasic数据库操作对象(需要调用Global.initialize函数初始化).
    # DbOperator_VideoStat = None                        # VideoStat数据库操作对象(需要调用Global.initialize函数初始化).
    DbOperator_VideoSpider = None                      # VideoSpider数据库操作对象(需要调用Global.initialize函数初始化).

    @staticmethod
    def initialize():
        """初始化Global中的各种全局对象."""

        if Global.DbConfig_VideoBasic is None:
            dict_obj = SpiderConfig.get_db_config_video_basic()
            Global.DbConfig_VideoBasic = DbConfig(host=dict_obj["Host"],
                                                  port=int(dict_obj["Port"]),
                                                  db=dict_obj["DbName"],
                                                  user=dict_obj["UserName"],
                                                  pwd=dict_obj["Password"])
            Global.DbOperator_VideoBasic = DbOperator(db_config=Global.DbConfig_VideoBasic)
        # if Global.DbConfig_VideoStat is None:
        #    dict_obj = SpiderConfig.get_db_config_video_stat()
        #    Global.DbConfig_VideoStat = DbConfig(host=dict_obj["Host"],
        #                                         port=int(dict_obj["Port"]),
        #                                         db=dict_obj["DbName"],
        #                                         user=dict_obj["UserName"],
        #                                         pwd=dict_obj["Password"])
        #    Global.DbOperator_VideoStat = DbOperator(db_config=Global.DbConfig_VideoStat)
        if Global.DbConfig_VideoSpider is None:
            dict_obj = SpiderConfig.get_db_config_video_spider()
            Global.DbConfig_VideoSpider = DbConfig(host=dict_obj["Host"],
                                                   port=int(dict_obj["Port"]),
                                                   db=dict_obj["DbName"],
                                                   user=dict_obj["UserName"],
                                                   pwd=dict_obj["Password"])
            Global.DbOperator_VideoSpider = DbOperator(db_config=Global.DbConfig_VideoSpider)

        pass
