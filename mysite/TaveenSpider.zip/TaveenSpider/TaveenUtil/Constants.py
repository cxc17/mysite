#coding:utf-8

"""
该文件中存放常用的全局常量.
"""

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.08.18"


# 种子爬虫的名称.
SeedsSpiderName = u"SeedsSpider"

# 页面爬虫的名称.
PageSpiderName = u"PageSpider"

# category的英文名.
CategoryNames = [u"tv", u"movie", u"variety", u"animation"]

# category对应的中文名.
CategoryNames_CH = [u"电视剧", u"电影", u"综艺", u"动漫"]

# 专辑信息对应的字段(与数据库中xxx_album表一致).
AlbumDataField = ["video_name", "category", "image", "albumuri", "actor", "director", "drama", "type",
                  "region", "year", "pubdate", "length", "curEpisode", "valid", "isEnd", "public_area"]

# 分集页信息对应的字段(与数据库中xxx_url表一致).
EpisodeDataField = ["video_name", "category", "year", "no", "url", "director", "actor", "isValidURL",
                    "guests", "album_id"]

# 种子页面抽取出的信息字段(包括一部分数据库中的视频信息字段，还有一部分其他字段).
SeedsDataFields = ["page_count", "video_url", "title", "quality", "image", "pay",
                   "length", "curEpisode", "year", "actor", "director", "screenwriter",
                   "drama", "type", "region", "pubdate", "dayviews", "views", "rate", "publish_area"]


class PageType(object):
    """用于表示页面类型的类.

    目前预设的页面类型有: 专辑页、分集页、分集页中间页面、演员页面、演员页、演员页中间页面.
    """

    ALBUM_PAGE = "ALBUM_PAGE"
    ALBUM_MEDIUM_PAGE = "ALBUM_MEDIUM_PAGE"
    EPISODE_PAGE = "EPISODE_PAGE"
    EPISODE_MEDIUM_PAGE = "EPISODE_MEDIUM_PAGE"
    ACTOR_PAGE = "ACTOR_PAGE"
    ACTOR_MEDIUM_PAGE = "ACTOR_MEDIUM_PAGE"
    UNKNOWN_PAGE = ""

    # 页面类型的名称列表(这个字段多用来方便遍历之类的行为，并不是必需的).
    PageTypeNames = [u"ALBUM_PAGE", u"ALBUM_MEDIUM_PAGE", u"EPISODE_PAGE", u"EPISODE_MEDIUM_PAGE", u"ACTOR_PAGE", u"ACTOR_MEDIUM_PAGE"]