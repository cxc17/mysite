# coding=utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2013.11.23"

import traceback


class DbConfig(object):
    """数据库连接配置类。该类的每个对象都包含有一套数据库连接参数。

    Attribute:
        db_host: 数据库所在的host地址。
        db_port: 数据库连接端口号。
        db_name: 数据库名称。
        db_user: 数据库登录用户名。
        db_password: 数据库登录密码。
        db_charset: 数据库所使用的字符集。

    @author: HuangGK
    Date: 2013.11.23.
    """

    db_host = None
    db_port = None
    db_name = None
    db_user = None
    db_password = None
    db_charset = "utf8"

    def __init__(self, host=None, port=None, db=None, user=None, pwd=None, charset='utf8'):
        """构造函数，初始化DbConfig类的新实例。

        @param host: 数据库所在的host地址。
        @param port: 数据库连接端口号。必须为整型。
        @param db: 数据库名称。
        @param user: 数据库登录用户名。
        @param pwd: 数据库登录密码。
        @param charset: 数据库所使用的字符集。默认为utf-8.

        @attention: host、port、db、user、pwd默认参数全为None，
                    当host、port、db、user、pwd全为None时，相当于类的无参构造函数。
        """
        try:
            self.db_host = host
            if port is not None:
                self.db_port = int(port)
            else:
                self.db_port = None
            self.db_name = db
            self.db_user = user
            self.db_password = pwd
            self.db_charset = charset
        except Exception, err:
            print "Error: Error occurred when initializing DbConfig instance. Please check your parameters." \
                  "\n    %s" % err.message
            traceback.print_exc()
            raise err


if __name__ == "__main__":
    print "DbConfig.py"