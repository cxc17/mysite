# coding=utf-8

"""
该文件中各种用途的工具类.
"""

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.08.21"


from random import Random
import platform
import socket
import time
import os
import re


class SqlUtil(object):
    """与SQL语句相关的工具类.

    """

    @staticmethod
    def sql_field_filter(string):
        """拼接SQL语句时对其中的一些特殊字符作相应的转义."""
        return string.replace("\\", "\\\\").replace("'", "\\'").replace("\"", "\\\"").replace("(", "\\(")\
            .replace(")", "\\)").replace(",", "\\,")  # .replace("\n", "").replace("\t", "")

    @staticmethod
    def format_field(value, data_type="str"):
        """拼接SQL语句时，对字段进行格式化.

        @param value: 需要被格式化的字段内容.
        @param data_type: 格式化之后的数据类型.
                          需要注意的是，当data_type为str或unicode时，格式化后的字段内容开头和结尾会自动加引号.
        """
        if value is None:
            return u"null"
        data_type = data_type.lower()
        if data_type == u"bool":                              # 处理bool类型.
            if isinstance(value, bool):
                return value is True and 1 or 0
            value = (u"%s" % value).strip().lower()
            if value == u"1" or value == u"true":
                return 1
            elif value == u"0" or value == u"false":
                return 0
            else:
                raise ValueError(u"Unexpected value! Can not convert %s to bool!" % value)
        elif data_type == u"int":                             # 处理int类型.
            if isinstance(value, int):
                return value
            value = (u"%s" % value).strip()
            if re.match(ur"\d+", value):
                return int(float(value))
            else:
                raise ValueError(u"Unexpected value! Can not convert %s to int!" % value)
        elif data_type == u"float":                           # 处理float类型.
            if isinstance(value, float):
                return value
            if re.match(ur"(?:\d+(\.\d+)*)|(?:\.\d+)", u"%s" % value):
                return float(value)
            else:
                raise ValueError(u"Unexpected value! Can not convert %s to float!" % value)
        elif data_type == u"str" or data_type == u"unicode":  # 处理str或unicode类型.
            return u"'%s'" % SqlUtil.sql_field_filter(u"%s" % value)
        else:
            raise ValueError(u"Unexpected parameter data_type: %s!" % data_type)


class DatetimeUtil(object):
    """与时间相关的工具类.

    """

    @staticmethod
    def get_datetime_now_str():
        """返回当前日期和时间的 yyyy-MM-dd HH:mm:ss 格式的字符串。"""
        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

    @staticmethod
    def get_date_now_str():
        """返回当前日期的 yyyy-MM-dd 格式的字符串。"""
        return time.strftime("%Y-%m-%d", time.localtime())


class RegexUtil(object):
    """与正则表达式相关的工具类.

    """
    pass


class RandomUtil(object):
    """与随机数相关的工具类.

    """

    @staticmethod
    def random_str(random_length=8, has_upper_letter=True, has_lower_letter=True, has_number=True):
        """生成一段随机字符串.

        @param random_length: 随机字符串的长度.
        @param has_upper_letter: 随机字符串是否包含大写字母.
        @param has_lower_letter: 随机字符串是否包含小写字母.
        @param has_number: 随机字符串是否包含数字.
        """
        value = ""
        chars = ""
        if has_upper_letter is True:
            chars += "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        if has_lower_letter is True:
            chars += "abcdefghijklmnopqrstuvwxyz"
        if has_number is True:
            chars += "0123456789"
        length = len(chars) - 1
        random = Random()
        for i in range(random_length):
            value += chars[random.randint(0, length)]
        return value


class OSUtil(object):
    """与操作系统信息/本机信息相关的工具类.

    """

    @staticmethod
    def get_os_name():
        """获取本机的操作系统名."""
        return platform.system()

    @staticmethod
    def get_localhost_ip():
        """获取本机的ip地址."""
        os_name = OSUtil.get_os_name()
        if os_name == u"Windows":
            ip = socket.gethostbyname(socket.gethostname())
            return u"".join(ip).strip()
        elif os_name == u"Linux":
            ip = os.popen(u"/sbin/ifconfig | grep 'inet addr' | awk '{print $2}'").read()
            ip = ip[ip.find(':')+1:ip.find('\n')]
            return u"".join(ip).strip()
        else:
            return None