#coding:utf-8


from email.mime.text import MIMEText
import smtplib
import re

__email_pattern = re.compile(ur"^([a-z](?:[a-z0-9]*[-_]?[a-z0-9]+)*)"
                             ur"@((?:[a-z0-9]*[-_]?[a-z0-9]+)+[\.][a-z]{2,3}(?:[\.][a-z]{2})?)$")


def send_mail(from_user_address, from_password, display_name, mail_host, to_list, subject, content, charset="utf-8"):
    """发送邮件的函数(支持html邮件正文).

    @param from_user_address: 发件人邮箱(完整邮箱地址).
    @param from_password: 发件人邮箱密码.
    @param display_name: 发件人发出的邮件显示的名字.
    @param mail_host: 邮箱服务器地址.
    @param to_list: 收件人邮箱地址列表.
    @param subject: 邮件主题.
    @param content: 邮件正文.
    @param charset: 邮件正文采用的编码.默认为utf-8.
    """

    matcher = __email_pattern.search(from_user_address)
    if matcher:
        user_name = matcher.group(1)
        postfix = matcher.group(2)
    else:
        raise ValueError(u"%s不是有效的邮箱地址，请填写完整的邮箱地址." % from_user_address)
    assert len(to_list) > 0

    me = u"%s<%s@%s>" % (display_name, user_name, postfix)
    msg = MIMEText(content, _subtype='html', _charset=charset)    # 创建一个实例，这里设置为html格式邮件
    msg['Subject'] = subject    # 设置主题
    msg['From'] = me
    msg['To'] = ";".join(to_list)
    try:
        s = smtplib.SMTP()
        s.connect(mail_host)                      # 连接smtp服务器
        s.login(user_name, from_password)         # 登陆服务器
        s.sendmail(me, to_list, msg.as_string())  # 发送邮件
        s.close()
        return True
    except Exception, err:
        print err
        return False


def send_mail_from_163host(from_user_address, from_password, display_name, to_list, subject, content, charset="utf-8"):
    return send_mail(from_user_address,
                     from_password,
                     display_name,
                     "smtp.163.com",
                     to_list,
                     subject,
                     content,
                     charset)
    pass


if __name__ == '__main__':
    mail_to_list = ["hgk-0506@163.com"]
    if send_mail("hgk-0506@163.com",
                 "**********",
                 "HGK",
                 "smtp.163.com",
                 mail_to_list,
                 "hello",
                 "<a href='http://www.changu.net'>小五义</a>"):
        print "发送成功"
    else:
        print "发送失败"
