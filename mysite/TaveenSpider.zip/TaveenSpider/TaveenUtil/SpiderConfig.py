# coding=utf-8

__version__ = '1.0'
__author__ = 'HuangGK'
__date__ = "2014.08.18"


from TaveenUtil.Constants import *

import json


class SpiderConfig(object):
    """[静态类]全局配置文件读取类.

    该类会从config文件夹中读取 spider.conf 配置文件和 debug.conf 配置文件中的内容.
    """
    # 计算配置文件的路径，并加载配置文件.
    base_path = u"/config/"
    from TaveenUtil.FileOperator import FileOperator
    if FileOperator.exist_file(u"..%sspider.conf" % base_path):
        base_path = u"..%s" % base_path
        pass
    else:
        import os
        path = os.getcwd().replace(u"\\", u"/")
        base_path = u"%sTaveenSpider/%s" % (path[:path.rindex(base_path.replace(u"config/", u""))], base_path)
        print base_path
    __debug_config = json.load(open(u"%sdebug.conf" % base_path))
    __spider_config = json.load(open(u"%sspider.conf" % base_path))

    @staticmethod
    def get_config(key):
        """获取指定key的配置值.

        @param key: 需要查询配置信息的键(字符串).
        """
        if "/" in key:
            config = SpiderConfig.__spider_config
            keys = str(key).split("/")
            for k in keys:
                if k == "":
                    continue
                if k not in config.keys():
                    return None
                config = config[k]
            return config
        elif key in SpiderConfig.__spider_config.keys():
            return SpiderConfig.__spider_config[key]
        else:
            return None

    @staticmethod
    def set_config(key, value):
        """设置指定key的配置值为value.

        @param key: 需要设置配置信息的键(字符串).
        @param value: 需要设置配置信息的值.
        """
        SpiderConfig.__spider_config[key] = value

    @staticmethod
    def get_website():
        """获取当前的website."""
        return SpiderConfig.__spider_config["Website"]

    @staticmethod
    def get_spider_type():
        """获取当前的spider type."""
        return SpiderConfig.__spider_config["SpiderType"]

    @staticmethod
    def get_is_quick_update():
        """获取当前是否为快速更新模式(小循环模式)."""
        value = SpiderConfig.__spider_config["QuickUpdate"]
        return value.lower() == "true" and True or False

    @staticmethod
    def get_if_apply_seeds_filter():
        """获取种子程序执行时是否对索引页面应用筛选器."""
        value = SpiderConfig.__spider_config["ApplySeedsFilter"]
        return value.lower() == "true" and True or False

    @staticmethod
    def get_if_extract_video_from_actor_page():
        """获取页面爬虫执行时是否对演员及其作品的页面进行爬取."""
        value = SpiderConfig.__spider_config["ExtractVideoFromActorPage"]
        value = value.lower() == "true" and True or False
        if SpiderConfig.get_is_quick_update() is True:
            print u"由于Quick Update值为True，所以ExtractVideoFromActorPage被设置为False."
            value = False
        return value

    @staticmethod
    def get_db_config_video_basic():
        """获取VideoBasic数据库的配置对象."""
        return dict(SpiderConfig.__spider_config["DBConfig"]["VideoBasic"])

    @staticmethod
    def get_db_config_video_stat():
        """获取VideoStat数据库的配置对象."""
        return dict(SpiderConfig.__spider_config["DBConfig"]["VideoStat"])

    @staticmethod
    def get_db_config_video_spider():
        """获取VideoStat数据库的配置对象."""
        return dict(SpiderConfig.__spider_config["DBConfig"]["VideoSpider"])

    @staticmethod
    def get_is_debug():
        """获取当前是否为开发人员调试模式."""
        return SpiderConfig.__debug_config["is_debug"] == "True" and True or False

    @staticmethod
    def get_log_level():
        """获取程序执行时输出LOG的LOG级别."""
        if SpiderConfig.get_is_debug():
            return SpiderConfig.__debug_config["debug_log_level"]
        else:
            return SpiderConfig.__spider_config["LogLevel"]

    @staticmethod
    def get_seeds_output_path():
        """获取种子文件的输出路径."""
        directory = SpiderConfig.get_seeds_output_dir()
        return "%s%s_seeds.txt" % (directory, SpiderConfig.get_website())

    @staticmethod
    def get_seeds_output_dir():
        """获取种子文件的输出目录."""
        directory = SpiderConfig.__spider_config["SeedsFilesDir"]
        if not str(directory).strip().endswith(u"/") and \
                not str(directory).strip().endswith(u"\\"):
            directory += "/"
        return directory

    @staticmethod
    def get_log_output_dir():
        """获取程序的LOG输出目录."""
        directory = SpiderConfig.__spider_config["LogsOutputDir"]
        if not str(directory).strip().endswith(u"/") and \
                not str(directory).strip().endswith(u"\\"):
            directory += "/"
        from Global import Global
        return "%s%s/[%s] %s/" % (directory, SpiderConfig.get_website(), SpiderConfig.get_spider_type(),
                                  Global.ProgramStartTimeStr.replace(":", "."))
        #return "%s" % directory

    @staticmethod
    def get_quick_update_max_page_count():
        """获取快速更新(小循环)模式下种子爬虫每个category下最多爬取的页数."""
        return SpiderConfig.get_config("CustomizedConfig/%sConfig/QuickUpdateSeedsConfig/MaxPageCount"
                                       % SpiderConfig.get_website())

    @staticmethod
    def get_download_delay():
        """获取页面的下载延迟(download_delay)."""
        if SpiderConfig.get_spider_type() == SeedsSpiderName:
            download_delay = "SeedsDownloadDelay"
        else:
            download_delay = "PageDownloadDelay"
        return float(SpiderConfig.get_config("CustomizedConfig/%sConfig/%s"
                                             % (SpiderConfig.get_website(), download_delay)))