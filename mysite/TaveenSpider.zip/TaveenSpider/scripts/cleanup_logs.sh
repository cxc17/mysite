﻿#!/bin/bash

PATH=/bin:/sbin:/usr/bin:/usr/sbin
export PATH

log_dir="/home/TaveenSpider_log/logs/tool-program/cleanup_logs/"

if [ ! -d $log_dir ];
then
    mkdir -p $log_dir
fi

cd /home/TaveenSpider/tools/
python /home/TaveenSpider/tools/cleanup_logs.py > "$log_dir""/""cleanup_logs"".log" 2>&1